// cpanel - site_templates/vcard_dev/assets/config.js.tt Copyright(c) 2016 cPanel, Inc.
//                                                          All rights Reserved.
// copyright@cpanel.net                                        http://cpanel.net
// This code is subject to the cPanel license. Unauthorized copying is prohibited

window.cpanel = {
    data: {
        phone: "+6281314225017",
        fax: "",
        email: "ibnusodik049@gmail.com",
        address: "Jl Kh. Wachid Hasyim 312 Tanjunganom Nganjuk",
        social: [
            
            {
                icon: 'facebook',
                link: "https:\/\/facebook.com\/odigawa"
            },
            
            
            {
                icon: 'twitter',
                link: "https:\/\/twitter.com\/Is_Isodik"
            },
            
            
            {
                icon: 'instagram',
                link: "https:\/\/instagram.com\/is01252"
            },
            
            
            
            
        ]
    },
    style: {
        primary: "",
        accent: ""
    },
    slides: [
        {
            prefix: "Aku",
            title: "Ibnu Sodik",
            subtitle: "Web Developer",
            type: 'vcard',
            backgroundImage: "",
            backgroundColor: "",
            color: "",
            buttonText: "Hubungi Saya",
            buttonLink: "",
            biography: "",
            portraitImage: ""
        }
    ]
};
