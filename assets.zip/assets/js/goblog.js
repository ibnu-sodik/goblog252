const flashData = $('.flash-data-sukses').data('flashdata');
const flashDataError = $('.flash-data-error').data('flashdata');
if (flashData) {

	$.toast({
		heading : 'Selamat.!',
		text : flashData,
		icon: 'success', 
		showHideTransition: 'slide', 
		// allowToastClose: true,
		hideAfter: 5000, 
		stack: 3, 
		position: 'bottom-center', 
		textAlign: 'left',  
		loader: true,  
		loaderBg: '#fff'
	})
	// Command: toastr["success"](flashData, "Berhasil.!")

	// toastr.options = {
	// 	"closeButton": true,
	// 	"debug": false,
	// 	"newestOnTop": true,
	// 	"progressBar": true,
	// 	"positionClass": "toast-bottom-left",
	// 	"preventDuplicates": false,
	// 	"onclick": null,
	// 	"showDuration": "300",
	// 	"hideDuration": "1000",
	// 	"timeOut": "5000",
	// 	"extendedTimeOut": "1000",
	// 	"showEasing": "easeOutBounce",
	// 	"hideEasing": "easeInBack",
	// 	"showMethod": "showDuration",
	// 	"hideMethod": "hideDuration"
	// }

}

// error
if (flashDataError) {

	$.toast({
		heading 			: 'Oops.!',
		text 				: flashDataError,
		icon				: 'error', 
		showHideTransition: 'slide', 
		// allowToastClose: true,
		hideAfter: 5000, 
		stack: 3, 
		position: 'bottom-center', 
		textAlign: 'left',  
		loader: true,  
		loaderBg: '#fff'
	});

}