<?php
defined('BASEPATH') OR exit('No direct script access allowed');
/**
 * Blog
 */
class Blog extends CI_Controller
{
	function __construct()
	{
		parent::__construct();
		$this->load->library('user_agent');
		$this->load->model('Blog_model', 'blog_model');
		$this->load->model('Visitor_model', 'visitor_model');
		$this->load->model('Site_model', 'site_model');
		$this->load->model('Home_model', 'home_model');
		$this->visitor_model->hitung_visitor();
		$this->load->helper('text');
	}

	function index()
	{
		$site = $this->site_model->get_site_data()->row_array();
		// pagination
		$jumlah = $this->blog_model->get_blogs();
		$page = $this->uri->segment(3);
		if (!$page) {
			$mati = 0;
		}else{
			$mati = $page;
		}
		$limit = $site['limit_post'];
		$offset = $mati > 0 ? (($mati - 1) * $limit) : $mati;
		$config['base_url'] = base_url().'blog/page/';		
		$config['total_rows'] = $jumlah->num_rows();
		$config['per_page'] = $limit;
		$config['uri_segment'] = 3;
		$config['use_page_numbers']=TRUE;
		// $config['num_links'] = 3;

		$config['full_tag_open'] = '<div class="row"><div class="col-md-12"><nav aria-label="Page navigation"><ul class="pagination justify-content-start">';
		$config['full_tag_close'] = '</ul></nav></div></div></div>';
		$config['num_tag_open'] = '<li class="page-item"><span class="page-link">';
		$config['num_tag_close'] = '</li>';
		$config['cur_tag_open'] = '<li class="page-item"><a href="javascript:void(0)" class="page-link bg-active">';
		$config['cur_tag_close'] = '</a></li>';
		$config['prev_tag_open'] = '<li class="page-item"><span class="page-link">';
		$config['prev_tag_close'] = '</li>';
		$config['next_tag_open'] = '<li class="page-item"><span class="page-link">';
		$config['next_tag_close'] = '</span></li>';
		$config['last_tag_open'] = '<li class="page-item"><span class="page-link">';
		$config['last_tag_close'] = '</li>';
		$config['first_tag_open'] = '<li class="page-item"><span class="page-link">';
		$config['first_tag_close'] = '</li>';

		$config['prev_link'] = 'Prev';
		$config['next_link'] = 'Next';
		$config['last_link'] = 'Last';
		$config['first_link'] = 'First';

		$this->pagination->initialize($config);

		$data['pagination'] = $this->pagination->create_links();
		$data['blog'] = $this->blog_model->get_blog_perpage($offset,$limit);
		
		$data['judul'] = "Blogs";
		$data['font_awesome']		= "fa fa-rss bg-orange";
		if (empty($this->uri->segment(3))) {
			$next_page = 2;
			$data['canonical'] = site_url('blog');
			$data['url'] = site_url('blog');
			$data['url_prev'] = "";
		}elseif ($this->uri->segment(3)=='1') {
			$next_page = 2;
			$data['canonical'] = site_url('blog');
			$data['url'] = site_url('blog');
			$data['url_prev'] = site_url('blog');
		}elseif ($this->uri->segment(3)=='2') {
			$next_page = $this->uri->segment(3)+1;
			$data['canonical'] = site_url('blog/page/'.$this->uri->segment(3));
			$data['url'] = site_url('blog/page/'.$this->uri->segment(3));
			$data['url_prev'] = site_url('blog');
		}else{
			$next_page = $this->uri->segment(3)+1;
			$prev_page = $this->uri->segment(3)-1;
			$data['canonical'] = site_url('blog/page/'.$this->uri->segment(3));
			$data['url'] = site_url('blog/page/'.$this->uri->segment(3));
			$data['url_prev'] = site_url('blog/page/'.$prev_page);
		}
		$data['url_next'] = site_url('blog/page/'.$next_page);

		$data['site_name'] = $site['site_name'];
		$data['site_title'] = $site['site_title'];
		$data['site_keywords'] = $site['site_keywords'];
		$data['site_author'] = $site['site_author'];
		$data['site_description'] = $site['site_description'];
		$data['site_logo_big'] = $site['site_logo_big'];
		$data['site_logo_footer'] = $site['site_logo_footer'];
		$data['site_logo_header'] = $site['site_logo_header'];
		$data['site_favicon'] = $site['site_favicon'];
		$data['popular_categories'] = $this->home_model->get_popular_categories();		
		$site_id = $site['site_id'];
		$data['sosmed_web'] = $this->site_model->get_sosmed_by_own($site_id);
		$data['title'] = "Blog";

		$this->template->load('template', 'blog_view', $data);
	}

	function halaman($slug)
	{
		$query = $this->blog_model->get_halaman_by_slug($slug);
		if ($query->num_rows() > 0) {
			$value = $query->row_array();
			$id_halaman = $value['id_halaman'];
			$data['url'] = site_url('pages/'.$value['slug_halaman']);
			$data['canonical'] = site_url('pages/'.$value['slug_halaman']);
			$data['title'] = $value['nama_halaman'];
			$data['judul'] = $value['nama_halaman'];
			$data['konten'] = $value['konten_halaman'];

			$site = $this->site_model->get_site_data()->row_array();
			$data['site_title'] = $site['site_title'];
			$data['site_name'] = $site['site_name'];
			$data['site_keywords'] = $site['site_keywords'];
			$data['site_author'] = $site['site_author'];
			$data['site_description'] = $site['site_description'];
			$data['site_favicon'] = $site['site_favicon'];
			$data['site_logo_header'] = $site['site_logo_header'];
			$data['site_logo_footer'] = $site['site_logo_footer'];
			$site_id = $site['site_id'];
			$data['popular_categories'] = $this->home_model->get_popular_categories();		
			$data['sosmed_web'] = $this->site_model->get_sosmed_by_own($site_id);

			$this->template->load('template', 'detail_hal_view', $data);
		}

	}

	function detail($slug)
	{
		$query = $this->blog_model->get_post_by_slug($slug);
		if ($query->num_rows() > 0) {
			$value = $query->row_array();
			$post_id = $value['post_id'];
			$data['url'] = site_url('blog/'.$value['post_slug']);
			$data['canonical'] = site_url('blog/'.$value['post_slug']);
			$data['title'] = $value['post_title'];
			$data['judul'] = $value['post_title'];
			if (empty($value['post_description'])) {
				$data['description'] = strip_tags(word_limiter($value['post_contents'], 25));
			}else{
				$data['description'] = strip_tags(word_limiter($value['post_description']), 25);
			}

			$data['id_user'] = $value['post_user_id'];
			$data['gambar'] = $value['post_image'];
			$data['slug'] = $value['post_slug'];
			$data['konten'] = $value['post_contents'];
			$data['views'] = $value['post_views'];
			$data['comment'] = $value['comment_total'];
			$data['author'] = $value['full_name'];
			$data['user_info'] = $value['user_info'];
			$data['author_foto'] = $value['foto'];
			$data['category'] = $value['category_name'];
			$data['category_slug'] = $value['category_slug'];
			$data['date'] = $value['post_date'];
			$data['tags'] = $value['post_tags'];
			$data['post_id'] = $post_id;
			$data['sosmed_author'] = $this->site_model->get_sosmed_by_author($value['post_user_id']);
			$category_id = $value['category_id'];
			$this->blog_model->hitung_views($post_id);
			$site = $this->site_model->get_site_data()->row_array();
			$data['popular_posts'] = $this->home_model->get_popular_posts($site['limit_popular_post']);
			$data['recent_views'] = $this->home_model->get_recent_views($site['limit_recent_views']);
			
			$data['related_post'] = $this->blog_model->get_related_post($category_id, $post_id);
			$data['prev_post'] = $this->blog_model->get_prev_post($post_id, $value['category_name']);
			$data['next_post'] = $this->blog_model->get_next_post($post_id, $value['category_name']);
			$data['popular_categories'] = $this->home_model->get_popular_categories();
			$data['lihat_komentar'] = $this->blog_model->lihat_komentar($post_id);

			$data['site_title'] = $site['site_title'];
			$data['site_name'] = $site['site_name'];
			$data['site_keywords'] = $site['site_keywords'];
			$data['site_author'] = $site['site_author'];
			$data['site_description'] = $site['site_description'];
			$data['site_favicon'] = $site['site_favicon'];
			$data['site_logo_header'] = $site['site_logo_header'];
			$data['site_logo_footer'] = $site['site_logo_footer'];
			$site_id = $site['site_id'];
			$data['sosmed_web'] = $this->site_model->get_sosmed_by_own($site_id);

			$this->template->load('template', 'detail_view', $data);
		}else{
			redirect('blog');
		}
	}

	function preview($slug)
	{
		$query = $this->blog_model->get_post_preview_by_slug($slug);
		if ($query->num_rows() > 0) {
			$value = $query->row_array();
			$post_id = $value['post_id'];

			$data['title'] = $value['post_title'];
			$data['judul'] = $value['post_title'];
			if (empty($value['post_description'])) {
				$data['post_description'] = strip_tags(word_limiter($value['post_description'], 25));
			}else{
				$data['description'] = strip_tags(word_limiter($value['post_description']), 25);
			}

			$data['id_user'] = $value['post_user_id'];
			$data['gambar'] = $value['post_image'];
			$data['slug'] = $value['post_slug'];
			$data['konten'] = $value['post_contents'];
			$data['views'] = $value['post_views'];
			$data['comment'] = $value['comment_total'];
			$data['author'] = $value['full_name'];
			$data['user_info'] = $value['user_info'];
			$data['author_foto'] = $value['foto'];
			$data['category'] = $value['category_name'];
			$data['category_slug'] = $value['category_slug'];
			$data['date'] = $value['post_date'];
			$data['tags'] = $value['post_tags'];
			$data['post_id'] = $post_id;
			$data['sosmed_author'] = $this->site_model->get_sosmed_by_author($value['post_user_id']);
			$category_id = $value['category_id'];

			$site = $this->site_model->get_site_data()->row_array();
			$data['popular_posts'] = $this->home_model->get_popular_posts($site['limit_popular_post']);
			$data['recent_views'] = $this->home_model->get_recent_views($site['limit_recent_views']);
			
			$data['related_post'] = $this->blog_model->get_related_post($category_id, $post_id);
			$data['prev_post'] = $this->blog_model->get_prev_post($post_id, $value['category_name']);
			$data['next_post'] = $this->blog_model->get_next_post($post_id, $value['category_name']);
			$data['popular_categories'] = $this->home_model->get_popular_categories();
			$data['lihat_komentar'] = $this->blog_model->lihat_komentar($post_id);

			
			$data['url'] = site_url('preview/'.$value['post_slug']);
			$data['canonical'] = site_url('preview/'.$value['post_slug']);
			$data['site_title'] = $site['site_title'];
			$data['site_name'] = $site['site_name'];
			$data['site_keywords'] = $site['site_keywords'];
			$data['site_author'] = $site['site_author'];
			$data['site_description'] = $site['site_description'];
			$data['site_favicon'] = $site['site_favicon'];
			$data['site_logo_header'] = $site['site_logo_header'];
			$data['site_logo_footer'] = $site['site_logo_footer'];
			$site_id = $site['site_id'];
			$data['sosmed_web'] = $this->site_model->get_sosmed_by_own($site_id);

			$this->template->load('template', 'detail_view', $data);
		}else{
			redirect('blog');
		}
	}

	// Komentar
	function submit_balasan()
	{
		$submit = $this->input->post('submit', TRUE);
		$slug = $this->input->post('slug', TRUE);
		if (isset($submit)) {
			$this->form_validation->set_rules('co_pid', 'Post Id Komentar', 'required|htmlspecialchars');
			$this->form_validation->set_rules('co_id', 'Id Komentar', 'required|htmlspecialchars');
			$this->form_validation->set_rules('nama', 'Nama', 'required|min_length[3]|max_length[50]');
			$this->form_validation->set_rules('email', 'Email', 'required|valid_email');
			$this->form_validation->set_rules('website', 'Website', 'trim');
			$this->form_validation->set_rules('balasan', 'Balasan', 'required');

			if ($this->form_validation->run() == FALSE) {
				$text = 'Balasan Tidak Terkirim.!';
				$this->session->set_flashdata('pesan_error', $text);
				redirect('blog/'.$slug);
			} else {
				$co_pid = $this->input->post('co_pid', TRUE);
				$co_id = $this->input->post('co_id', TRUE);
				$nama = $this->input->post('nama', TRUE);
				$email = $this->input->post('email', TRUE);
				$website = $this->input->post('website', TRUE);
				$balasan = $this->input->post('balasan', TRUE);

				$this->blog_model->simpan_balasan($co_pid, $co_id, $nama, $email, $website, $balasan);
				$text = 'Balasan Terkirim.! <b>Mohon Tunggu Untuk Moderasi.!</b>';
				$this->session->set_flashdata('pesan_sukses', $text);
				redirect('blog/'.$slug);
			}
		}
	}

	// Komentar
	function submit_komentar()
	{
		$submit = $this->input->post('submit', TRUE);
		$slug = $this->input->post('slug', TRUE);
		if (isset($submit)) {
			$this->form_validation->set_rules('co_pid', 'Post Id Komentar', 'required|htmlspecialchars');
			$this->form_validation->set_rules('nama', 'Nama', 'required|min_length[3]|max_length[50]');
			$this->form_validation->set_rules('email', 'Email', 'required|valid_email');
			$this->form_validation->set_rules('website', 'Website', 'trim');
			$this->form_validation->set_rules('komentar', 'Komentar', 'required');

			if ($this->form_validation->run() == FALSE) {
				$text = 'Komentar Tidak Terkirim.!';
				$this->session->set_flashdata('pesan_error', $text);
				redirect('blog/'.$slug);
			} else {
				$co_pid = $this->input->post('co_pid', TRUE);
				$nama = $this->input->post('nama', TRUE);
				$email = $this->input->post('email', TRUE);
				$website = $this->input->post('website', TRUE);
				$komentar = $this->input->post('komentar', TRUE);

				$this->blog_model->simpan_komentar($co_pid, $nama, $email, $website, $komentar);
				$text = 'Komentar Terkirim.! <b>Mohon Tunggu Untuk Moderasi.!</b>';
				$this->session->set_flashdata('pesan_sukses', $text);
				redirect('blog/'.$slug);
			}
		}
	}

}