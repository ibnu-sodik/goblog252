<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Contact extends CI_Controller {

	function __construct() {
		parent::__construct();
		$this->load->model('Site_model', 'site_model');
		$this->load->model('admin/Pesan_model', 'pesan_model');
		$this->load->model('Home_model', 'home_model');
		$this->load->model('Visitor_model', 'visitor_model');
		$this->visitor_model->hitung_visitor();
		$this->load->library('form_validation');
		$this->load->helper('text');
	}

	function kirim()
	{
		$submit = $this->input->post('submit', TRUE);
		if (isset($submit)) {
			$this->form_validation->set_rules('pengirim', 'Name', 'required|min_length[3]|max_length[50]|htmlspecialchars');
			$this->form_validation->set_rules('email', 'Email', 'required|valid_email');
			$this->form_validation->set_rules('no_hp', 'No Hp', 'max_length[20]');
			$this->form_validation->set_rules('subjek', 'Subjek', 'required|min_length[3]|max_length[100]|htmlspecialchars');
			$this->form_validation->set_rules('pesan', 'Pesan', 'required');

			if ($this->form_validation->run() == FALSE) {
				$text = 'Pesan Tidak Terkirim.!';
				$this->session->set_flashdata('pesan_error', $text);
				redirect('contact');
			} else {
				$pengirim = $this->input->post('pengirim', TRUE);
				$email = $this->input->post('email', TRUE);
				$no_hp = $this->input->post('no_hp', TRUE);
				$subjek = $this->input->post('subjek', TRUE);
				$pesan = $this->input->post('pesan', TRUE);

				$this->pesan_model->simpan_pesan($pengirim, $email, $no_hp, $subjek, $pesan);
				$text = 'Pesan Terkirim.!';
				$this->session->set_flashdata('pesan_sukses', $text);
				redirect('contact');
			}
		}
	}

	function index()
	{
		$site = $this->site_model->get_site_data()->row_array();
		$data['url'] = site_url('contact');
		$data['canonical'] = site_url('contact');
		$data['site_name'] = $site['site_name'];
		$data['site_title'] = $site['site_title'];
		$data['site_keywords'] = $site['site_keywords'];
		$data['site_author'] = $site['site_author'];
		$data['site_description'] = $site['site_description'];
		$data['site_logo_big'] = $site['site_logo_big'];
		$data['site_logo_header'] = $site['site_logo_header'];
		$data['site_logo_footer'] = $site['site_logo_footer'];
		$data['site_favicon'] = $site['site_favicon'];
		$data['konten_kontak'] = $site['konten_kontak'];
		$data['font_awesome']	= "fa fa-envelope bg-orange";
		$data['title']	= "Kontak";
		$data['judul']	= "Kontak";
		$data['popular_categories'] = $this->home_model->get_popular_categories();
		$site_id = $site['site_id'];
		$data['sosmed_web'] = $this->site_model->get_sosmed_by_own($site_id);

		$this->template->load('template', 'contact_view', $data);
	}

}

/* End of file Contact.php */
/* Location: ./application/controllers/Contact.php */ ?>