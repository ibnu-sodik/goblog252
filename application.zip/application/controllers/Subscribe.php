<?php
defined('BASEPATH') OR exit('No direct script access allowed');

/**
 * Subscribe
 */
class Subscribe extends CI_Controller
{
	
	function __construct()
	{
		parent::__construct();
		$this->load->library('user_agent');
		$this->load->model('Subscribe_model', 'subscribe_model');
		$this->load->model('Visitor_model', 'visitor_model');
		$this->visitor_model->hitung_visitor();
		$this->load->helper('text');
	}

	function index()
	{
		$this->load->library('form_validation');
		$url 	= $this->input->post('url', TRUE);
		$this->form_validation->set_rules('email', 'Email', 'required|valid_email');

		if ($this->form_validation->run() == FALSE) {
			$text = 'Email Yang Anda Masukkan Tidak Valid.!';
			$this->session->set_flashdata('pesan_error', $text);
			redirect($url);
		} else {
			$email 	= $this->input->post('email', TRUE);
			$cek_email = $this->subscribe_model->cek_email($email);

			if ($cek_email->num_rows() > 0) {
				$text = 'Anda Sudah Terdaftar Sebagai Pelanggan Kami.!';
				$this->session->set_flashdata('pesan_error', $text);
				redirect($url);
			}else{
				$this->subscribe_model->simpan_subscribe($email);
				$text = 'Anda Terdaftar Sebagai Pelanggan Kami.!';
				$this->session->set_flashdata('pesan_sukses', $text);
				redirect($url);
			}

		}
	}

}