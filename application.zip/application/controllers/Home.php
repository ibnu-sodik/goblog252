<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Home extends CI_Controller 
{

	function __construct() {
		parent::__construct();
		$this->load->library('user_agent');
		$this->load->model('Home_model', 'home_model');
		$this->load->model('Site_model', 'site_model');
		$this->load->model('Visitor_model', 'visitor_model');
		$this->visitor_model->hitung_visitor();
		$this->load->helper('text');
	}

	function index()
	{
		// for ($i=1; $i <=10 ; $i++) { 
		// 	$tambah = $this->visitor_model->tambah_visitor();
		// }
		$site = $this->site_model->get_site_data()->row_array();
		$data['url'] = site_url('home');
		$data['canonical'] = site_url('home');
		$data['site_name'] = $site['site_name'];
		$data['site_title'] = $site['site_title'];
		$data['site_keywords'] = $site['site_keywords'];
		$data['site_author'] = $site['site_author'];
		$data['site_description'] = $site['site_description'];
		$data['site_logo_big'] = $site['site_logo_big'];
		$data['site_logo_header'] = $site['site_logo_header'];
		$data['site_logo_footer'] = $site['site_logo_footer'];
		$data['site_favicon'] = $site['site_favicon'];
		$limit_post = $site['limit_post'];
		$limit_latest_post = $site['limit_latest_post'];
		$limit_popular_post = $site['limit_popular_post'];
		$limit_recent_views = $site['limit_recent_views'];

		$data['post_header'] = $this->home_model->get_post_header();
		$data['post_header2'] = $this->home_model->get_post_header2();
		$data['post_header3'] = $this->home_model->get_post_header3();
		$data['latest_posts'] = $this->home_model->get_latest_posts($limit_latest_post);
		$data['popular_categories'] = $this->home_model->get_popular_categories();
		$data['popular_posts'] = $this->home_model->get_popular_posts($limit_popular_post);
		$data['recent_views'] = $this->home_model->get_recent_views($limit_recent_views);
		$site_id = $site['site_id'];
		$data['sosmed_web'] = $this->site_model->get_sosmed_by_own($site_id);
		
		$this->template->load('template', 'home_view', $data);
	}
}
