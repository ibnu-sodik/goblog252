<?php
/**
 * Category
 */
class Category extends CI_Controller
{
	
	function __construct()
	{
		parent::__construct();
		$this->load->library('user_agent');
		$this->load->model('Category_model', 'category_model');
		$this->load->model('Site_model', 'site_model');
		$this->load->model('Home_model', 'home_model');
		$this->load->model('Visitor_model', 'visitor_model');
		$this->load->model('Site_model', 'Site_model');
		$this->visitor_model->hitung_visitor();
		$this->load->helper('text');
	}

	function index()
	{
		redirect('blog');
	}

	function detail($slug)
	{
		$site = $this->site_model->get_site_data()->row_array();
		$data_cat = $this->category_model->get_post_by_category($slug);
		if ($data_cat->num_rows() > 0) {
			$nilai = $data_cat->row_array();
			$category_id = $nilai['category_id'];
			$category_name = $nilai['category_name'];

			// Pagination
			$jumlah = $data_cat;
			$page = $this->uri->segment(3);
			if (!$page) {
				$mati = 0;
			}else{
				$mati = $page;
			}
			$limit = $site['limit_post'];
			$offset = $mati > 0 ? (($mati - 1) * $limit) : $mati;
			$config['base_url'] = site_url('category/'.$slug.'/');
			$config['total_rows'] = $jumlah->num_rows();
			$config['per_page'] = $limit;
			$config['uri_segment'] = 3;
			$config['use_page_numbers'] = TRUE;

			// Styling
			$config['full_tag_open'] = '<div class="row"><div class="col-md-12"><nav aria-label="Page navigation"><ul class="pagination justify-content-start">';
			$config['full_tag_close'] = '</ul></nav></div></div></div>';
			$config['num_tag_open'] = '<li class="page-item"><span class="page-link">';
			$config['num_tag_close'] = '</li>';
			$config['cur_tag_open'] = '<li class="page-item"><a href="javascript:void(0)" class="page-link bg-active">';
			$config['cur_tag_close'] = '</a></li>';
			$config['prev_tag_open'] = '<li class="page-item"><span class="page-link">';
			$config['prev_tag_close'] = '</li>';
			$config['next_tag_open'] = '<li class="page-item"><span class="page-link">';
			$config['next_tag_close'] = '</span></li>';
			$config['last_tag_open'] = '<li class="page-item"><span class="page-link">';
			$config['last_tag_close'] = '</li>';
			$config['first_tag_open'] = '<li class="page-item"><span class="page-link">';
			$config['first_tag_close'] = '</li>';

			$config['prev_link'] = 'Prev';
			$config['next_link'] = 'Next';
			$config['last_link'] = 'Last';
			$config['first_link'] = 'First';
			$this->pagination->initialize($config);
			$data['pagination'] = $this->pagination->create_links();
			$data['kategori'] = $this->category_model->get_category_post_perpage($limit, $offset, $category_id);

			$data['font_awesome']	= "fa fa-tag bg-orange";
			if ($data_cat->num_rows() > 0) {
				$data['cari'] = $data_cat;
				$data['judul'] = $data_cat->num_rows().' Data Dari Kategori '.$category_name;
				$data['isi'] = $category_name;
			}else{
				$data['cari'] = $data_cat;
				$data['judul'] = '<em>'.$category_name.'</em> Tidak Ditemukan.!';
				$data['isi'] = $category_name;
			}

			$data['url'] = site_url('category/'.$category_name);
			$data['canonical'] = site_url('category/'.$category_name);
			$data['site_name'] = $site['site_name'];
			$data['site_title'] = $site['site_title'];
			$data['site_keywords'] = $site['site_keywords'];
			$data['site_author'] = $site['site_author'];
			$data['site_description'] = $site['site_description'];
			$data['site_logo_big'] = $site['site_logo_big'];
			$data['site_logo_footer'] = $site['site_logo_footer'];
			$data['site_logo_header'] = $site['site_logo_header'];
			$data['site_favicon'] = $site['site_favicon'];
			$site_id = $site['site_id'];
			$data['sosmed_web'] = $this->site_model->get_sosmed_by_own($site_id);

			$data['popular_categories'] = $this->home_model->get_popular_categories();

			$this->template->load('template', 'post_category_view', $data);
		}else{redirect('blog');}
	}
}