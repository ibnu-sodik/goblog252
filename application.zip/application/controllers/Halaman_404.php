<?php 

defined('BASEPATH') OR exit('No direct script access allowed');

class Halaman_404 extends CI_Controller {

	public function __construct() {
		parent::__construct();
    // load base_url
		$this->load->model('Site_model', 'site_model');
		$this->load->helper('url');
	}

	public function index()
	{
		$this->output->set_status_header('404'); 
		$site = $this->site_model->get_site_data()->row_array();
		$data['site_name'] = $site['site_name'];
		$data['site_title'] = $site['site_title'];
		$data['site_keywords'] = $site['site_keywords'];
		$data['site_author'] = $site['site_author'];
		$data['site_description'] = $site['site_description'];
		$data['site_logo_big'] = $site['site_logo_big'];
		$data['site_logo_header'] = $site['site_logo_header'];
		$data['site_logo_footer'] = $site['site_logo_footer'];
		$data['site_favicon'] = $site['site_favicon'];
		$data['title'] = "Halaman Tidak Ditemukan";

		$this->load->view('halaman_404_view', $data);
	}

}

/* End of file Halaman_404.php */
/* Location: ./application/controllers/Halaman_404.php */

?>