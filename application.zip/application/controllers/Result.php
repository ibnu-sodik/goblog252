<?php

/**
 * Result
 */
class Result extends CI_Controller
{
	
	function __construct()
	{
		parent::__construct();
		$this->load->library('user_agent');
		$this->load->model('Site_model', 'site_model');
		$this->load->model('Result_model', 'result_model');
		$this->load->model('Home_model', 'home_model');
		$this->load->model('Visitor_model', 'visitor_model');
		$this->visitor_model->hitung_visitor();
		$this->load->helper('text');
	}

	function index()
	{
		redirect('blog');
	}

	function search()
	{
		$q_cari = strip_tags(htmlspecialchars($this->input->get('search_query', TRUE), ENT_QUOTES));
		$hasil_cari =  $this->result_model->hitung_jumlah_cari($q_cari);

		// pagination
		$site = $this->site_model->get_site_data()->row_array();
		$config = array();
		if ($q_cari) $config['suffix'] = '?' . http_build_query($_GET, '', "&");
		$page = $this->uri->segment(2);
		if (!$page) {
			$mati = 0;
		}else{
			$mati = $page;
		}
		$limit = $site['limit_post'];
		$offset = $mati > 0 ? (($mati - 1) * $limit) : $mati;
		$config['base_url'] = site_url('search');
		$config['first_url'] = $config['base_url'].'?'.http_build_query($_GET);
		$config['total_rows'] = $hasil_cari->num_rows();
		$config['per_page'] = $limit;
		$config['uri_segment'] = 2;
		$config['use_page_numbers'] = TRUE;
		// $config['num_links'] = 4;

		// Styling
		$config['full_tag_open'] = '<div class="row"><div class="col-md-12"><nav aria-label="Page navigation"><ul class="pagination justify-content-start">';
		$config['full_tag_close'] = '</ul></nav></div></div></div>';
		$config['num_tag_open'] = '<li class="page-item"><span class="page-link">';
		$config['num_tag_close'] = '</li>';
		$config['cur_tag_open'] = '<li class="page-item"><a href="javascript:void(0)" class="page-link bg-active">';
		$config['cur_tag_close'] = '</a></li>';
		$config['prev_tag_open'] = '<li class="page-item"><span class="page-link">';
		$config['prev_tag_close'] = '</li>';
		$config['next_tag_open'] = '<li class="page-item"><span class="page-link">';
		$config['next_tag_close'] = '</span></li>';
		$config['last_tag_open'] = '<li class="page-item"><span class="page-link">';
		$config['last_tag_close'] = '</li>';
		$config['first_tag_open'] = '<li class="page-item"><span class="page-link">';
		$config['first_tag_close'] = '</li>';

		$config['prev_link'] = 'Prev';
		$config['next_link'] = 'Next';
		$config['last_link'] = 'Last';
		$config['first_link'] = 'First';
		$this->pagination->initialize($config);

		$data['pencarian'] = $this->result_model->get_pencarian_perpage($limit, $offset, $q_cari);
		$data['pagination'] = $this->pagination->create_links();
		if (empty($this->uri->segment(2))) {
			$next_page = 2;
			$data['canonical'] = site_url('search');
			$data['url_prev'] = "";
		}elseif ($this->uri->segment(2)=='1') {
			$next_page = 2;
			$data['canonical'] = site_url('search/page/'.$this->uri->segment(3));
			$data['url_prev'] = site_url('search');
		}elseif ($this->uri->segment(2)=='2') {
			$next_page = $this->uri->segment(2)+1;
			$data['canonical'] = site_url('search/page/'.$this->uri->segment(2));
			$data['url_prev'] = site_url('search/page/ikilho');
		}else{
			$next_page = $this->uri->segment(2)+1;
			$prev_page = $this->uri->segment(2)-1;
			$data['canonical'] = site_url('search/page/'.$this->uri->segment(2));
			$data['url_prev'] = site_url('search/page/'.$prev_page);
		}
		$data['url_next'] = site_url('search/page/'.$next_page);


		if ($hasil_cari->num_rows() > 0) {
			$data['cari'] = $hasil_cari;
			$data['judul'] = $hasil_cari->num_rows().' Hasil Dari Kata '.$q_cari;
			$data['isi'] = $q_cari;
		}else{
			$data['cari'] = $hasil_cari;
			$data['judul'] = $q_cari.' Tidak Ditemukan.!';
			$data['isi'] = $q_cari;
		}

		$data['font_awesome']	= "fa fa-search bg-orange";

		$data['popular_categories'] = $this->home_model->get_popular_categories();

		$data['url'] = $config['base_url'].'?'.http_build_query($_GET);
		$data['site_name'] = $site['site_name'];
		$data['site_title'] = $site['site_title'];
		$data['site_keywords'] = $site['site_keywords'];
		$data['site_author'] = $site['site_author'];
		$data['site_description'] = $site['site_description'];
		$data['site_logo_big'] = $site['site_logo_big'];
		$data['site_logo_header'] = $site['site_logo_header'];
		$data['site_logo_footer'] = $site['site_logo_footer'];
		$data['site_favicon'] = $site['site_favicon'];
		$site_id = $site['site_id'];
		$data['sosmed_web'] = $this->site_model->get_sosmed_by_own($site_id);
		$this->template->load('template', 'search_blog_view', $data);
	}
}