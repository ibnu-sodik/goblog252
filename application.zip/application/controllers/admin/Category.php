<?php
/**
 * Category
 */
class Category extends CI_Controller
{
	
	function __construct()
	{
		parent::__construct();
		$this->load->model('admin/Category_model', 'category_model');
		$this->load->model('Site_model', 'site_model');
		$this->load->helper('text');
	}

	function update()
	{
		$id = $this->input->post('id_kategori',TRUE);
		$category = strip_tags(htmlspecialchars($this->input->post('category2',TRUE),ENT_QUOTES));
		$string   = preg_replace('/[^a-zA-Z0-9 \&%|{.}=,?!*()"-_+$@;<>\']/', '', $category);
		$trim     = trim($string);
		$slug     = strtolower(str_replace(" ", "-", $trim));
		$this->category_model->_update($id,$category,$slug);
		$text = $category. ' Berhasil Diubah.!';
		$this->session->set_flashdata('toast', $text);
		redirect('admin/category');
	}

	function save()
	{
		$category = strip_tags(htmlspecialchars($this->input->post('category',TRUE),ENT_QUOTES));
		$string   = preg_replace('/[^a-zA-Z0-9 \&%|{.}=,?!*()"-_+$@;<>\']/', '', $category);
		$trim     = trim($string);
		$slug     = strtolower(str_replace(" ", "-", $trim));
		$this->category_model->_insert($category,$slug);
		$text = 'Berhasil Menambah Kategori '.$category;
		$this->session->set_flashdata('toast', $text);
		redirect('admin/category');
	}

	function delete()
	{
		$category_id = $this->uri->segment(4);

		$this->category_model->delete_category($category_id);
		$text = 'Kategori Berhasil Dihapus.!';
		$this->session->set_flashdata('toast', $text);
		redirect('admin/category');
	}

	function index()
	{
		$site = $this->site_model->get_site_data()->row_array();
		$data['site_title'] = $site['site_title'];
		$data['site_name'] = $site['site_name'];
		$data['site_keywords'] = $site['site_keywords'];
		$data['site_favicon'] = $site['site_favicon'];
		$data['site_logo_footer'] = $site['site_logo_footer'];
		$data['site_logo_header'] = $site['site_logo_header'];
		$data['site_author'] = $site['site_author'];
		$data['site_description'] = $site['site_description'];
		$data['menu_category'] = "active-menu";
		$data['title'] = "Kategori";

		$data['data'] = $this->category_model->get_all_category();
		$this->template->load('admin/template', 'admin/category_view', $data);
	}

}