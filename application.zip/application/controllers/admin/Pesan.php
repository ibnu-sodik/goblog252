<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Pesan extends CI_Controller {

	function __construct()
	{
		parent::__construct();
		$this->load->model('Site_model', 'site_model');
		$this->load->model('admin/Pesan_model', 'pesan_model');
		$this->load->helper('text');
	}

	function delete()
	{
		$pesan_id = $this->uri->segment(4);
		$hasil = $this->pesan_model->get_pesan_by_id($pesan_id);
		if ($hasil->num_rows() > 0) {
			$this->pesan_model->_delete($pesan_id);
			$text = 'Pesan Berhasil Dihapus.!';
			$this->session->set_flashdata('toast', $text);
			redirect('admin/pesan');
		}else{
			$text = 'Pesan Yang Anda Maksud Tidak Tersedia.!';
			$this->session->set_flashdata('toast_error', $text);
			redirect('admin/pesan');
		}
	}

	function detail()
	{
		$pesan_id = $this->uri->segment(4);
		$hasil = $this->pesan_model->get_pesan_by_id($pesan_id);
		if ($hasil->num_rows() > 0) {
			$row = $hasil->row_array();

			$site = $this->site_model->get_site_data()->row_array();
			$data['site_title'] = $site['site_title'];
			$data['site_name'] = $site['site_name'];
			$data['site_keywords'] = $site['site_keywords'];
			$data['site_author'] = $site['site_author'];
			$data['site_logo_header'] = $site['site_logo_header'];
			$data['site_logo_footer'] = $site['site_logo_footer'];
			$data['site_description'] = $site['site_description'];
			$data['site_favicon'] = $site['site_favicon'];
			$data['link_kembali'] = site_url('admin/pesan');
			$data['title'] = $row['subjek_pesan'];

			$data['subjek_pesan'] = $row['subjek_pesan'];
			$data['pesan_email'] = $row['pesan_email'];
			$data['no_hp'] = $row['no_hp'];

			date_default_timezone_set('Asia/Jakarta');
			$jam=date("G");
			if( $jam >= 0 && $jam <= 11){
				$sapa = "Selamat Pagi";
			}
			else if( $jam >= 12 && $jam <= 15){
				$sapa = "Selamat Siang";
			}
			else if( $jam >= 16 && $jam <= 18){
				$sapa = "Selamat Sore";
			}
			else if( $jam >= 19 && $jam <= 23){
				$sapa = "Selamat Malam";
			}

			$data['link_balas_wa'] = "https://api.whatsapp.com/send?phone=".$row['no_hp']."&text=".$sapa." ".$row['pesan_dari'];
			$data['isi_pesan'] = $row['isi_pesan'];
			$data['pesan_dari'] = $row['pesan_dari'];
			$data['tgl_kirim'] = $row['tgl_kirim'];

			$this->template->load('admin/template', 'admin/detail_pesan_view', $data);
			$this->pesan_model->read($row['pesan_id']);

		}else{
			$text = 'Pesan Yang Anda Maksud Tidak Tersedia.!';
			$this->session->set_flashdata('toast_error', $text);
			redirect('admin/pesan');
		}

	}

	function unread()
	{
		$pesan_id = $this->uri->segment(4);
		$this->pesan_model->unread($pesan_id);
		redirect('admin/pesan');
	}

	function read()
	{
		$pesan_id = $this->uri->segment(4);
		$this->pesan_model->read($pesan_id);
		redirect('admin/pesan');
	}

	function unstar()
	{
		$pesan_id = $this->uri->segment(4);
		$this->pesan_model->unstar($pesan_id);
		redirect('admin/pesan');
	}

	function star()
	{
		$pesan_id = $this->uri->segment(4);
		$this->pesan_model->star($pesan_id);
		redirect('admin/pesan');
	}

	function index()
	{
		$site = $this->site_model->get_site_data()->row_array();
		$data['site_title'] = $site['site_title'];
		$data['site_name'] = $site['site_name'];
		$data['site_keywords'] = $site['site_keywords'];
		$data['site_author'] = $site['site_author'];
		$data['site_logo_header'] = $site['site_logo_header'];
		$data['site_logo_footer'] = $site['site_logo_footer'];
		$data['site_description'] = $site['site_description'];
		$data['site_favicon'] = $site['site_favicon'];
		$data['pesan'] = $this->pesan_model->get_all_pesan();
		$data['title'] = "Pesan";

		$this->template->load('admin/template', 'admin/pesan_view', $data);
	}

}

/* End of file Pesan.php */
/* Location: ./application/controllers/admin/Pesan.php */ ?>