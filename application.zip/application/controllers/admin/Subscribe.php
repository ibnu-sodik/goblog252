<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Subscribe extends CI_Controller {

	function __construct()
	{
		parent::__construct();
		$this->load->model('Site_model', 'site_model');
		$this->load->model('admin/Subscribe_model', 'subscribe_model');
		$this->load->helper('text');
	}

	function delete()
	{
		$subscribe_id = $this->uri->segment(4);
		$query = $this->subscribe_model->get_subscribers_by_id($subscribe_id);
		$row = $query->row_array();
		$text = 'Email <b><i>'.$row['subscribe_email'].'</i></b> Berhasil Dihapus.!';
		$this->session->set_flashdata('toast', $text);
		$this->subscribe_model->delete($subscribe_id);
		redirect('admin/subscribe');
	}

	function activate()
	{
		$subscribe_id = $this->uri->segment(4);
		$query = $this->subscribe_model->get_subscribers_by_id($subscribe_id);
		$row = $query->row_array();
		$this->subscribe_model->activate($subscribe_id);
		$text = 'Email <b><i>'.$row['subscribe_email'].'</i></b> Berhasil Diaktifkan.!';
		$this->session->set_flashdata('toast', $text);
		redirect('admin/subscribe');
	}

	function decrease()
	{
		$subscribe_id = $this->uri->segment(4);
		$query = $this->subscribe_model->get_subscribers_by_id($subscribe_id);
		$row = $query->row_array();
		// cek
		if ($row['subscribe_rating'] == 0) {			
			$text = $row['subscribe_email'].' Tidak Bisa Diturunkan Lagi.!';
			$this->session->set_flashdata('toast', $text);
			redirect('admin/subscribe');
		}else{
			$this->subscribe_model->decrease_rating($subscribe_id);
			$text = $row['subscribe_email'].' Berhasil Diturunkan.!';
			$this->session->set_flashdata('toast', $text);
			redirect('admin/subscribe');
		}
	}

	function increase()
	{
		$subscribe_id = $this->uri->segment(4);
		$query = $this->subscribe_model->get_subscribers_by_id($subscribe_id);
		$row = $query->row_array();
		$this->subscribe_model->increase_rating($subscribe_id);
		$text = $row['subscribe_email'].' Berhasil Ditingkatkan.!';
		$this->session->set_flashdata('toast', $text);
		redirect('admin/subscribe');
	}

	function index()
	{
		$site = $this->site_model->get_site_data()->row_array();
		$data['site_title'] = $site['site_title'];
		$data['site_name'] = $site['site_name'];
		$data['site_keywords'] = $site['site_keywords'];
		$data['site_author'] = $site['site_author'];
		$data['site_logo_header'] = $site['site_logo_header'];
		$data['site_logo_footer'] = $site['site_logo_footer'];
		$data['site_description'] = $site['site_description'];
		$data['site_favicon'] = $site['site_favicon'];
		$data['title'] = "Pelanggan";
		$data['subscribers'] = $this->subscribe_model->get_subscribers();

		$this->template->load('admin/template', 'admin/subscribe_view', $data);
	}

}

/* End of file Subscribe.php */
/* Location: ./application/controllers/admin/Subscribe.php */ 
?>