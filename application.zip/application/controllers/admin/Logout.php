<?php
/**
 * Logout
 */
class Logout extends CI_Controller
{
	
	function __construct()
	{
		parent::__construct();
		$this->load->library('session');
	}

	function index()
	{
		$pesan = 'Berhasil Logout.!';
		$this->session->set_flashdata('toast', $pesan);
		$this->session->sess_destroy();
		$url = base_url('admin');
		redirect($url);
	}
}