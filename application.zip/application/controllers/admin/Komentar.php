<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Komentar extends CI_Controller {

	function __construct()
	{
		parent::__construct();
		$this->load->model('Site_model', 'site_model');
		$this->load->model('admin/Komentar_model', 'komentar_model');
		$this->load->helper('text');
	}

	function index()
	{
		$site = $this->site_model->get_site_data()->row_array();
		$hitung = $this->db->get_where('tb_comment', array('comment_parent' => '0'));
		$page = $this->uri->segment(4);
		if (!$page) {
			$mati = 0;
		}else{
			$mati = $page;
		}
		$limit = $site['limit_post'];
		$offset = $mati > 0 ? (($mati - 1) * $limit) : $mati;
		$config['base_url'] = base_url('admin/komentar/index/');
		$config['total_rows'] = $hitung->num_rows();
		$config['per_page'] = $limit;
		$config['uri_segment'] = 4;
		$config['use_page_numbers'] = TRUE;
		
		// Styling
		$config['full_tag_open'] = '<div class="row text-center"><div class="col-md-12"><nav aria-label="Page navigation"><ul class="pagination justify-content-center">';
		$config['full_tag_close'] = '</ul></nav></div></div></div>';
		$config['num_tag_open'] = '<li class="page-item"><span class="page-link">';
		$config['num_tag_close'] = '</li>';
		$config['cur_tag_open'] = '<li class="page-item active"><a href="javascript:void(0)" class="page-link">';
		$config['cur_tag_close'] = '</a></li>';
		$config['prev_tag_open'] = '<li class="page-item"><span class="page-link">';
		$config['prev_tag_close'] = '</li>';
		$config['next_tag_open'] = '<li class="page-item"><span class="page-link">';
		$config['next_tag_close'] = '</span></li>';
		$config['last_tag_open'] = '<li class="page-item"><span class="page-link">';
		$config['last_tag_close'] = '</li>';
		$config['first_tag_open'] = '<li class="page-item"><span class="page-link">';
		$config['first_tag_close'] = '</li>';

		$config['prev_link'] = 'Prev';
		$config['next_link'] = 'Next';
		$config['last_link'] = 'Last';
		$config['first_link'] = 'First';
		$this->pagination->initialize($config);
		$data['pagination'] = $this->pagination->create_links();
		$data['komentar'] = $this->komentar_model->get_all_komentar($offset, $limit);

		$data['jumlah_semua'] = $hitung->num_rows();
		$data['jumlah_unpublish'] = $this->db->get_where('tb_comment', array('comment_status' => '0'))->num_rows();

		$data['site_title'] = $site['site_title'];
		$data['site_name'] = $site['site_name'];
		$data['site_keywords'] = $site['site_keywords'];
		$data['site_author'] = $site['site_author'];
		$data['site_logo_header'] = $site['site_logo_header'];
		$data['site_logo_footer'] = $site['site_logo_footer'];
		$data['site_description'] = $site['site_description'];
		$data['site_favicon'] = $site['site_favicon'];
		$data['title'] = "Semua Komentar";

		$this->template->load('admin/template', 'admin/komentar_view', $data);
	}

	function unpublish()
	{
		$site = $this->site_model->get_site_data()->row_array();
		$hitung = $this->db->get_where('tb_comment', array('comment_status' => '0'));
		$page = $this->uri->segment(4);
		if (!$page) {
			$mati = 0;
		}else{
			$mati = $page;
		}
		$limit = $site['limit_post'];
		$offset = $mati > 0 ? (($mati - 1) * $limit) : $mati;
		$config['base_url'] = base_url('admin/komentar/unpublish/');
		$config['total_rows'] = $hitung->num_rows();
		$config['per_page'] = $limit;
		$config['uri_segment'] = 4;
		$config['use_page_numbers'] = TRUE;
		
		// Styling
		$config['full_tag_open'] = '<div class="row text-center"><div class="col-md-12"><nav aria-label="Page navigation"><ul class="pagination justify-content-center">';
		$config['full_tag_close'] = '</ul></nav></div></div></div>';
		$config['num_tag_open'] = '<li class="page-item"><span class="page-link">';
		$config['num_tag_close'] = '</li>';
		$config['cur_tag_open'] = '<li class="page-item active"><a href="javascript:void(0)" class="page-link">';
		$config['cur_tag_close'] = '</a></li>';
		$config['prev_tag_open'] = '<li class="page-item"><span class="page-link">';
		$config['prev_tag_close'] = '</li>';
		$config['next_tag_open'] = '<li class="page-item"><span class="page-link">';
		$config['next_tag_close'] = '</span></li>';
		$config['last_tag_open'] = '<li class="page-item"><span class="page-link">';
		$config['last_tag_close'] = '</li>';
		$config['first_tag_open'] = '<li class="page-item"><span class="page-link">';
		$config['first_tag_close'] = '</li>';

		$config['prev_link'] = 'Prev';
		$config['next_link'] = 'Next';
		$config['last_link'] = 'Last';
		$config['first_link'] = 'First';
		$this->pagination->initialize($config);
		$data['pagination'] = $this->pagination->create_links();
		$data['unpublish'] = $this->komentar_model->get_unpublish_komentar($offset, $limit);

		$data['jumlah_semua'] = $this->db->get_where('tb_comment', array('comment_parent' => '0'))->num_rows();
		$data['jumlah_unpublish'] = $hitung->num_rows();

		$data['site_title'] = $site['site_title'];
		$data['site_name'] = $site['site_name'];
		$data['site_keywords'] = $site['site_keywords'];
		$data['site_author'] = $site['site_author'];
		$data['site_logo_header'] = $site['site_logo_header'];
		$data['site_logo_footer'] = $site['site_logo_footer'];
		$data['site_description'] = $site['site_description'];
		$data['site_favicon'] = $site['site_favicon'];
		$data['title'] = "Moderasi Komentar";

		$this->template->load('admin/template', 'admin/komentar_unpublish_view', $data);
	}

	function balas()
	{
		$comment_id = $this->input->post('comment_id', TRUE);
		$comment_post_id = $this->input->post('comment_post_id', TRUE);
		$contents = $this->input->post('contents', TRUE);
		$web = $this->input->post('web', TRUE);

		$user_id=$this->session->userdata('id');
		$query = $this->db->get_where('tb_user', array('id' => $user_id));
		if ($query->num_rows() > 0) {
			$value = $query->row_array();
			$nama = $value['full_name'];
			$email = $value['email'];
			$this->komentar_model->balas($comment_id, $comment_post_id, $contents, $nama, $email, $web);
			$text = 'Balasan Terkirim.!';
			$this->session->set_flashdata('toast', $text);
			redirect('admin/komentar');
		}else{
			$text = 'Balasan Tidak Terkirim.!';
			$this->session->set_flashdata('toast_error', $text);
			redirect('admin/komentar');
		}
	}

	function hasil()
	{
		$site = $this->site_model->get_site_data()->row_array();
		$cari = htmlspecialchars($this->input->get('cari',TRUE),ENT_QUOTES);

		$limit = $site['limit_post'];
		$query = $this->komentar_model->cari_komentar($cari, $limit);
		if ($query->num_rows() > 0) {
			$page = $this->uri->segment(4);
			if (!$page) {
				$mati = 0;
			}else{
				$mati = $page;
			}
			$offset = $mati > 0 ? (($mati - 1) * $limit) : $mati;
			$config['base_url'] = base_url('admin/komentar/unpublish/');
			$config['total_rows'] = $query->num_rows();
			$config['per_page'] = $limit;
			$config['uri_segment'] = 4;
			$config['use_page_numbers'] = TRUE;

		// Styling
			$config['full_tag_open'] = '<div class="row text-center"><div class="col-md-12"><nav aria-label="Page navigation"><ul class="pagination justify-content-center">';
			$config['full_tag_close'] = '</ul></nav></div></div></div>';
			$config['num_tag_open'] = '<li class="page-item"><span class="page-link">';
			$config['num_tag_close'] = '</li>';
			$config['cur_tag_open'] = '<li class="page-item active"><a href="javascript:void(0)" class="page-link">';
			$config['cur_tag_close'] = '</a></li>';
			$config['prev_tag_open'] = '<li class="page-item"><span class="page-link">';
			$config['prev_tag_close'] = '</li>';
			$config['next_tag_open'] = '<li class="page-item"><span class="page-link">';
			$config['next_tag_close'] = '</span></li>';
			$config['last_tag_open'] = '<li class="page-item"><span class="page-link">';
			$config['last_tag_close'] = '</li>';
			$config['first_tag_open'] = '<li class="page-item"><span class="page-link">';
			$config['first_tag_close'] = '</li>';

			$config['prev_link'] = 'Prev';
			$config['next_link'] = 'Next';
			$config['last_link'] = 'Last';
			$config['first_link'] = 'First';
			$this->pagination->initialize($config);
			$data['pagination'] = $this->pagination->create_links();

			$data['jumlah_semua'] = $query->num_rows();
			$data['jumlah_unpublish'] = $this->db->get_where('tb_comment', array('comment_status' => '0'))->num_rows();$data['komentar'] = $query;

			$data['site_title'] = $site['site_title'];
			$data['site_name'] = $site['site_name'];
			$data['site_keywords'] = $site['site_keywords'];
			$data['site_author'] = $site['site_author'];
			$data['site_logo_header'] = $site['site_logo_header'];
			$data['site_logo_footer'] = $site['site_logo_footer'];
			$data['site_description'] = $site['site_description'];
			$data['site_favicon'] = $site['site_favicon'];
			$data['title'] = "Hasil Pencarian";

			$this->template->load('admin/template', 'admin/komentar_view', $data);
		}else{
			$text = 'Komentar Tidak Ditemukan.!';
			$this->session->set_flashdata('toast_error', $text);
			redirect('admin/komentar');
		}
	}

	function publish()
	{
		$comment_id = $this->uri->segment(4);
		$this->komentar_model->publish($comment_id);
		$text = 'Komentar Berhasil Dipublikasikan.!';
		$this->session->set_flashdata('toast', $text);
		redirect('admin/komentar/unpublish');
	}

	function edit()
	{
		$comment_id = $this->input->post('comment_id', TRUE);
		$contents = $this->input->post('contents', TRUE);
		$web = $this->input->post('web', TRUE);
		$this->komentar_model->edit($comment_id, $contents, $web);
		$text = 'Balasan Berhasil Diedit.!';
		$this->session->set_flashdata('toast', $text);
		redirect('admin/komentar');
	}

	function hapus()
	{
		$comment_id = $this->uri->segment(4);
		$this->komentar_model->hapus($comment_id);
		$text = 'Komentar Berhasil Dihapus.!';
		$this->session->set_flashdata('toast', $text);
		redirect('admin/komentar');
	}

}

/* End of file Komentar.php */
/* Location: ./application/controllers/admin/Komentar.php */ ?>