<?php
/**
 * Users
 */
class Users extends CI_Controller
{
	
	function __construct()
	{
		parent::__construct();
		$this->load->model('admin/Users_model', 'users_model');
		$this->load->model('Site_model', 'site_model');
		$this->load->library('upload');
	}

	function delete_sosmed()
	{
		$sosmed_id = $this->uri->segment(4);
		$query = $this->db->query("SELECT * FROM tb_sosmed WHERE sosmed_id = '$sosmed_id'")->row();
		$own_user_id = $query->own_user_id;

		$this->users_model->delete_sosmed($sosmed_id);
		$text = 'Sosmed Berhasil Dihapus.!';
		$this->session->set_flashdata('toast', $text);
		redirect('admin/users/edit/'.$id);
	}

	function edit_sosmed()
	{
		$own_user_id = sanitize($this->input->post('own_user_id', TRUE));
		$sosmed_id = sanitize($this->input->post('sosmed_id', TRUE));
		$sosmed_name = sanitize($this->input->post('sosmed_name2', TRUE));
		$sosmed_url = sanitize($this->input->post('sosmed_url2', TRUE));
		$sosmed_icon = sanitize($this->input->post('sosmed_icon2', TRUE));
		$query = $this->db->query("SELECT full_name FROM tb_user WHERE id = '$own_user_id'")->row();
		// lakukan
		$this->users_model->update_sosmed($sosmed_name, $sosmed_url, $sosmed_icon, $sosmed_id);
		$text = $sosmed_name.' '.$query->full_name.' Berhasil Diubah.!';
		$this->session->set_flashdata('toast', $text);
		redirect('admin/users/edit/'.$own_user_id);
	}

	function add_sosmed()
	{
		$own_user_id = sanitize($this->input->post('own_user_id', TRUE));
		$sosmed_name = sanitize($this->input->post('sosmed_name', TRUE));
		$sosmed_url = sanitize($this->input->post('sosmed_url', TRUE));
		$sosmed_icon = sanitize($this->input->post('sosmed_icon', TRUE));
		// lakukan
		$data = $this->users_model->get_users_by_id($own_user_id)->row();
		$full_name = $data->full_name;
		$this->users_model->save_sosmed($sosmed_name, $sosmed_url, $sosmed_icon, $own_user_id);
		$text = $sosmed_name.' Berhasil Ditambahkan Ke '.$full_name;
		$this->session->set_flashdata('toast', $text);
		redirect('admin/users/edit/'.$own_user_id);
	}

	function update_password()
	{
		$id = $this->uri->segment(4);
		$password = $this->input->post('password', TRUE);
		$conf_password = $this->input->post('conf_password', TRUE);

		if (strlen($password) < 6) {
			$text = 'Password Harus Terdiri Dari 6 Karakter.!';
			$this->session->set_flashdata('toast_error', $text);
			redirect('admin/users/edit/'.$id);
		}elseif ($conf_password != $password) {
			$text = 'Konfirmasi Password Tidak Sama.!';
			$this->session->set_flashdata('toast_error', $text);
			redirect('admin/users/edit/'.$id);
		}else{
			$new_pass = sha1(md5($password));
			$this->users_model->update_password($id, $new_pass);
			$text = 'Password Berhasil Diupdate.!';
			$this->session->set_flashdata('toast', $text);
			redirect('admin/users/edit/'.$id);			
		}

	}

	function update_user_info()
	{
		$id = $this->uri->segment(4);
		$contents = $this->input->post('contents', TRUE);

		$this->users_model->update_user_info($id, $contents);
		$text = 'Quotes Berhasil Diupdate.!';
		$this->session->set_flashdata('toast', $text);
		redirect('admin/users/edit/'.$id);			
		

	}

	function update_personal()
	{
		$id = $this->uri->segment(4);
		$full_name = $this->input->post('full_name', TRUE);
		$username = $this->input->post('username', TRUE);
		$email = $this->input->post('email', TRUE);
		
		$cek_username = $this->users_model->cek_username($id, $username);
		$cek_email = $this->users_model->cek_email($id, $email);

		if ($cek_username->num_rows() > 0) {
			$text = 'Username <i>'.$username.'</i> Sudah ada. Coba Yang Lain.!';
			$this->session->set_flashdata('toast_error', $text);
			redirect('admin/users/edit/'.$id);
		}elseif ($cek_email->num_rows() > 0) {
			$text = 'Email <i>'.$email.'</i> Sudah ada. Coba Yang Lain.!';
			$this->session->set_flashdata('toast_error', $text);
			redirect('admin/users/edit/'.$id);
		}else{
			$this->users_model->update_personal($id, $full_name, $username, $email);
			$text = 'Profilmu Berhasil Diupdate.!';
			$this->session->set_flashdata('toast', $text);
			redirect('admin/users/edit/'.$id);			
		}
	}

	function update_foto()
	{
		$id = $this->uri->segment(4);
		$user = $this->users_model->get_users_by_id($id)->row();
		$config['upload_path'] = './uploads/images/admin/';
		$config['allowed_types'] = 'jpg|png|jpeg|bmp';
		$config['encrypt_name'] = TRUE;
		
		$this->upload->initialize($config);

		if ($this->upload->do_upload('filefoto')) {
			$img = $this->upload->data();

			$config['image_library'] = 'gd2';
			$config['source_image'] = './uploads/images/admin/'.$img['file_name'];
			$config['create_thumb'] = false;
			$config['maintain_ratio'] = false;
			$config['quality'] = '100%';
			$config['width'] = 1.280;
			$config['height'] = 1.080;
			$config['new_image'] = './uploads/images/admin/'.$img['file_name'];
			$this->load->library('image_lib', $config);
			$this->image_lib->resize();
			$this->_create_thumbs($img['file_name']);
			$foto = $img['file_name'];

			$this->users_model->_upload_foto($id, $foto);
			$text ='Foto '.$user->full_name.' Berhasil Diupload.!';
			$this->session->set_flashdata('toast', $text);
			redirect('admin/users/edit/'.$id);

		}else{
			$text ='Upload Foto Gagal.!';
			$this->session->set_flashdata('toast_error', $text);
			redirect('admin/users/edit/'.$id);
		}
		

	}

	function delete_foto()
	{
		$id = $this->uri->segment(4);
		$data = $this->users_model->get_users_by_id($id)->row();
		$images = "./uploads/images/admin/".$data->foto;
		$thumbs = "./uploads/thumbs/admin/".$data->foto;
		unlink($images);
		unlink($thumbs);

		$this->users_model->_delete_foto($id);
		$text ='Foto Berhasil Dihapus.!';
		$this->session->set_flashdata('toast', $text);
		redirect('admin/users/edit/'.$id);
	}

	function edit()
	{
		$id = $this->uri->segment(4);
		$row = $this->users_model->get_users_by_id($id)->row();
		
		$data['id'] = $row->id;
		$data['full_name'] = $row->full_name;
		$data['username'] = $row->username;
		$data['email'] = $row->email;
		$data['status'] = $row->status;
		$data['user_info'] = $row->user_info;
		$data['foto'] = $row->foto;
		$data['sosmed_author'] = $this->site_model->get_sosmed_by_author($row->id);

		$data['users'] = $this->users_model->get_users();
		$result = $this->site_model->get_site_data()->row_array();
		$data['site_id'] = $result['site_id'];
		$data['site_name'] = $result['site_name'];
		$data['site_title'] = $result['site_title'];
		$data['site_author'] = $result['site_author'];
		$data['site_keywords'] = $result['site_keywords'];
		$data['site_description'] = $result['site_description'];
		$data['site_favicon'] = $result['site_favicon'];
		$data['site_logo_header'] = $result['site_logo_header'];
		$data['link_kembali'] = site_url('admin/users');
		$data['title'] = "Edit User";
		$data['site_logo_footer'] = $result['site_logo_footer'];


		$this->template->load('admin/template', 'admin/users_edit_view', $data);
	}

	function delete()
	{
		$id = $this->uri->segment(4);

		$data = $this->users_model->get_users_by_id($id)->row();
		$images = "./uploads/images/admin/".$data->foto;
		$thumbs = "./uploads/thumbs/admin/".$data->foto;
		unlink($images);
		unlink($thumbs);

		$this->users_model->_delete($id);
		$text ='User Berhasil Dihapus.!';
		$this->session->set_flashdata('toast', $text);
		redirect('admin/users');
	}

	function lock()
	{
		$id = $this->uri->segment(4);
		$this->users_model->lock($id);
		$text ='Status User Terkunci.!';
		$this->session->set_flashdata('toast', $text);
		redirect('admin/users');
	}

	function unlock()
	{
		$id = $this->uri->segment(4);
		$this->users_model->unlock($id);
		$text ='Status User Telah Aktif.!';
		$this->session->set_flashdata('toast', $text);
		redirect('admin/users');
	}

	function index()
	{
		$data['users'] = $this->users_model->get_users();
		$result = $this->site_model->get_site_data()->row_array();
		$data['site_id'] = $result['site_id'];
		$data['site_name'] = $result['site_name'];
		$data['site_title'] = $result['site_title'];
		$data['site_author'] = $result['site_author'];
		$data['site_keywords'] = $result['site_keywords'];
		$data['site_description'] = $result['site_description'];
		$data['site_favicon'] = $result['site_favicon'];
		$data['site_logo_header'] = $result['site_logo_header'];
		$data['title'] = "User";
		$data['site_logo_footer'] = $result['site_logo_footer'];

		$this->template->load('admin/template', 'admin/users_view', $data);
	}

	function _create_thumbs($file_name)
	{
		$config = array(
			array(
				'image_library' => 'GD2',
				'source_image' => './uploads/images/admin/'.$file_name,
				'maintain_ratio' => false,
				'width' => 500,
				'height' => 500,
				'new_image' => './uploads/thumbs/admin/'.$file_name
			)
		);

		$this->load->library('image_lib', $config[0]);
		foreach ($config as $item) {
			$this->image_lib->initialize($item);
			if (!$this->image_lib->resize()) {
				return false;
			}
			$this->image_lib->clear();
		}
	}

}