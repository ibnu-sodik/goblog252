<?php 

/**
 * Menu
 */
class Menu extends CI_Controller
{
	
	function __construct()
	{
		parent::__construct();
		$this->load->model('admin/Menu_model', 'menu_model');
		$this->load->model('admin/Halaman_model', 'halaman_model');
		$this->load->model('admin/Category_model', 'category_model');
		$this->load->model('Site_model', 'site_model');
		$this->load->helper('text');
	}

	function edit_main()
	{
		$id_menu = $this->uri->segment(4);
		$site = $this->site_model->get_site_data()->row_array();
		$data['site_title'] = $site['site_title'];
		$data['site_name'] = $site['site_name'];
		$data['site_keywords'] = $site['site_keywords'];
		$data['site_author'] = $site['site_author'];
		$data['site_logo_header'] = $site['site_logo_header'];
		$data['site_logo_footer'] = $site['site_logo_footer'];
		$data['site_description'] = $site['site_description'];
		$data['site_favicon'] = $site['site_favicon'];
		$data['link_kembali'] = site_url('admin/menu');
		$data['form_location'] = site_url('admin/menu/update/'.$id_menu);
		$data['halaman'] = $this->halaman_model->get_all_halaman();
		$data['kategori'] = $this->category_model->get_all_category();
		$data['data_opt'] = $this->menu_model->get_main_menu();
		$data['title'] = "Edit Menu";
		$data['data'] = $this->menu_model->get_menu_by_id($id_menu);

		$this->template->load('admin/template', 'admin/edit_main_menu_view', $data);
	}

	function edit_second()
	{
		$id_menu = $this->uri->segment(4);
		$site = $this->site_model->get_site_data()->row_array();
		$data['site_title'] = $site['site_title'];
		$data['site_name'] = $site['site_name'];
		$data['site_keywords'] = $site['site_keywords'];
		$data['site_author'] = $site['site_author'];
		$data['site_logo_header'] = $site['site_logo_header'];
		$data['site_logo_footer'] = $site['site_logo_footer'];
		$data['site_description'] = $site['site_description'];
		$data['site_favicon'] = $site['site_favicon'];
		$data['link_kembali'] = site_url('admin/menu');
		$data['form_location'] = site_url('admin/menu/update/'.$id_menu);
		$data['halaman'] = $this->halaman_model->get_all_halaman();
		$data['data_opt'] = $this->menu_model->get_second_menu();
		$data['title'] = "Edit Menu";
		$data['data'] = $this->menu_model->get_menu_by_id($id_menu);

		$this->template->load('admin/template', 'admin/edit_second_menu_view', $data);
	}

	function delete()
	{
		$id_menu = $this->uri->segment(4);
		$this->menu_model->delete_menu($id_menu);
		$text = 'Menu Berhasil Dihapus.!';
		$this->session->set_flashdata('toast', $text);
		redirect('admin/menu');
	}

	function update($id_menu)
	{
		$judul = $this->input->post('judul', true);
		$induk = $this->input->post('induk', true);
		$kategori_menu = $this->input->post('kategori_menu', true);
		$jenis_link = $this->input->post('jenis_link', true);
		$link_halaman = $this->input->post('link_halaman', true);
		$link_kategori = $this->input->post('link_kategori', true);
		$link_url = $this->input->post('link_url', true);
		$urut = $this->input->post('urut', true);
		if ($jenis_link=="halaman") {
			$data_link = 'pages/'.$link_halaman;
		}elseif ($jenis_link=="kategori") {
			$data_link = 'category/'.$link_kategori;
		}else{
			$data_link = $link_url;
		}

		if ($kategori_menu == "main") {
			$str = " Main Menu";
		}elseif ($kategori_menu == "second") {
			$str = "Secondary Menu";
		}else{
			$str = "";
		}

		$this->menu_model->_update($id_menu, $judul, $induk, $kategori_menu, $jenis_link, $urut, $data_link);
		$text = 'Berhasil Mengupdate '.$judul.' Dari '.$str;
		$this->session->set_flashdata('toast', $text);
		redirect('admin/menu');
	}

	function save()
	{
		$judul = $this->input->post('judul', true);
		$induk = $this->input->post('induk', true);
		$kategori_menu = $this->input->post('kategori_menu', true);
		$jenis_link = $this->input->post('jenis_link', true);
		$link_halaman = $this->input->post('link_halaman', true);
		$link_kategori = $this->input->post('link_kategori', true);
		$link_url = $this->input->post('link_url', true);
		$urut = $this->input->post('urut', true);

		if ($jenis_link=="halaman") {
			$data_link = 'pages/'.$link_halaman;
		}elseif ($jenis_link=="kategori") {
			$data_link = 'category/'.$link_kategori;
		}else{
			$data_link = $link_url;
		}

		if ($kategori_menu == "main") {
			$str = " Main Menu";
		}elseif ($kategori_menu == "second") {
			$str = "Secondary Menu";
		}else{
			$str = "";
		}

		$this->menu_model->save($judul, $induk, $kategori_menu, $jenis_link, $urut, $data_link);
		$text = 'Berhasil Menambah '.$judul.' Ke '.$str;
		$this->session->set_flashdata('toast', $text);
		redirect('admin/menu');

		// echo $judul.$induk.$kategori_menu.$jenis_link.$urut.$data_link;die();
	}

	function add_main()
	{
		$site = $this->site_model->get_site_data()->row_array();
		$data['site_title'] = $site['site_title'];
		$data['site_name'] = $site['site_name'];
		$data['site_keywords'] = $site['site_keywords'];
		$data['site_author'] = $site['site_author'];
		$data['site_logo_header'] = $site['site_logo_header'];
		$data['site_logo_footer'] = $site['site_logo_footer'];
		$data['site_description'] = $site['site_description'];
		$data['site_favicon'] = $site['site_favicon'];
		$data['main_menu'] = $this->menu_model->get_main_menu();
		$data['link_kembali'] = site_url('admin/menu');
		$data['form_location'] = site_url('admin/menu/save');
		$data['halaman'] = $this->halaman_model->get_all_halaman();
		$data['title'] = "Tambah Menu";
		$data['kategori'] = $this->category_model->get_all_category();

		$this->template->load('admin/template', 'admin/add_main_menu_view', $data);
	}

	function add_second()
	{
		$site = $this->site_model->get_site_data()->row_array();
		$data['site_title'] = $site['site_title'];
		$data['site_name'] = $site['site_name'];
		$data['site_keywords'] = $site['site_keywords'];
		$data['site_author'] = $site['site_author'];
		$data['site_logo_header'] = $site['site_logo_header'];
		$data['site_logo_footer'] = $site['site_logo_footer'];
		$data['site_description'] = $site['site_description'];
		$data['site_favicon'] = $site['site_favicon'];
		$data['main_menu'] = $this->menu_model->get_second_menu();
		$data['link_kembali'] = site_url('admin/menu');
		$data['form_location'] = site_url('admin/menu/save');
		$data['title'] = "Tambah Menu";
		$data['halaman'] = $this->halaman_model->get_all_halaman();

		$this->template->load('admin/template', 'admin/add_second_menu_view', $data);
	}

	function index()
	{
		$site = $this->site_model->get_site_data()->row_array();
		$data['site_title'] = $site['site_title'];
		$data['site_name'] = $site['site_name'];
		$data['site_keywords'] = $site['site_keywords'];
		$data['site_author'] = $site['site_author'];
		$data['site_logo_header'] = $site['site_logo_header'];
		$data['site_logo_footer'] = $site['site_logo_footer'];
		$data['site_description'] = $site['site_description'];
		$data['site_favicon'] = $site['site_favicon'];
		$data['title'] = "Menu";
		$data['main_menu'] = $this->menu_model->get_main_menu();
		$data['second_menu'] = $this->menu_model->get_second_menu();

		$this->template->load('admin/template', 'admin/menu_view', $data);
	}

}

?>