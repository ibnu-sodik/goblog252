<?php
/**
 * Dashboard
 */
class Dashboard extends CI_Controller
{
	
	function __construct()
	{
		parent::__construct();
		$this->load->model('Site_model', 'site_model');
		$this->load->model('admin/Visitor_model', 'visitor_model');
		$this->load->helper('text');
	}

	function index()
	{
		// visitor
		$data['statistik_visitor'] = $this->visitor_model->statistik_visitor();
		$data['statistik_visitor_per_bulan'] = $this->visitor_model->statistik_visitor_per_bulan();
		$data['statistik_visitor_per_tahun'] = $this->visitor_model->statistik_visitor_per_tahun();
		$statistik_visitor = $this->visitor_model->statistik_visitor();

		foreach ($statistik_visitor as $result) {
			$bulan[] = $result->bulan;
		}
		$data['bulan_ini'] = json_encode($bulan);

		$data['jumlah_pengunjung'] = $this->visitor_model->hitung_semua_visitor();
		$data['jumlah_post_dilihat'] = $this->visitor_model->hitung_post_dilihat();
		$data['jumlah_pelanggan'] = $this->visitor_model->hitung_pelanggan();
		$data['jumlah_artikel'] = $this->visitor_model->hitung_artikel();
		$data['top_lima_artikel'] = $this->visitor_model->top_lima_artikel();
		
		$data['total_visitor'] = $this->visitor_model->hitung_total_visitor();		

		$data['statistik_browser'] = $this->visitor_model->statistik_browser();

		$site = $this->site_model->get_site_data()->row_array();
		$data['site_title'] = $site['site_title'];
		$data['site_name'] = $site['site_name'];
		$data['site_keywords'] = $site['site_keywords'];
		$data['site_author'] = $site['site_author'];
		$data['site_logo_header'] = $site['site_logo_header'];
		$data['site_logo_footer'] = $site['site_logo_footer'];
		$data['site_description'] = $site['site_description'];
		$data['site_favicon'] = $site['site_favicon'];
		$data['title'] = "Dashboard";

		$this->template->load('admin/template', 'admin/dashboard_view', $data);
	}
}