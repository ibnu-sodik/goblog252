<?php 
/**
 * Post
 */
class Post extends CI_Controller
{
	
	function __construct()
	{
		parent::__construct();
		if ($this->session->userdata('logged_in') != TRUE) {
			$url = base_url('admin');
			redirect($url);
		}
		$this->load->model('Site_model', 'site_model');
		$this->load->model('admin/Post_model', 'post_model');
		$this->load->model('admin/Tag_model', 'tag_model');
		$this->load->model('admin/Category_model', 'category_model');
		$this->load->library('upload');
		$this->load->helper('text');
	}

	function posting()
	{
		$post_id = (int)$this->uri->segment(4);
		$data = $this->post_model->get_post_by_id($post_id)->row_array();

		$this->post_model->posting($post_id);
		$title = $data['post_title'];
		$text = $title.' Berhasil Dipublish.!';
		$this->session->set_flashdata('toast', $text);
		redirect('admin/post/draft');
	}

	function unpost()
	{
		$post_id = (int)$this->uri->segment(4);
		$data = $this->post_model->get_post_by_id($post_id)->row_array();

		$this->post_model->unpost($post_id);
		$title = $data['post_title'];
		$text = $title.' Berhasil Diarsipkan.!';
		$this->session->set_flashdata('toast', $text);
		redirect('admin/post');
	}

	function update()
	{
		error_reporting(0);
		$config['upload_path'] = './uploads/images/';
		$config['allowed_types'] = 'gif|jpg|png|jpeg|bmp';
		$config['encrypt_name'] = TRUE;
		
		$this->upload->initialize($config);

		if (!empty($_FILES['filefoto']['name'])) {
			if ($this->upload->do_upload('filefoto')) {
				$img = $this->upload->data();

				$config['image_library'] = 'gd2';
				$config['source_image'] = './uploads/images/'.$img['file_name'];
				$config['create_thumb'] = false;
				$config['maintain_ratio'] = false;
				$config['quality'] = '100%';
				$config['width'] = 800;
				$config['height'] = 460;
				$config['new_image'] = './uploads/images/'.$img['file_name'];
				$this->load->library('image_lib', $config);
				$this->image_lib->resize();
				$this->_create_thumbs($img['file_name']);
				$this->_create_thumbs_2($img['file_name']);

				$image = $img['file_name'];
				$id 	  = $this->input->post('post_id',TRUE);
				$title = strip_tags(htmlspecialchars($this->input->post('title', true), ENT_QUOTES));
				$contents = $this->input->post('contents');
				$category = $this->input->post('category', true);
				$preslug = strip_tags(htmlspecialchars($this->input->post('slug', true), ENT_QUOTES));
				$string   = preg_replace('/[^a-zA-Z0-9 \&%|{.}=,?!*()"-_+$@;<>\']/', '', $preslug);
				$trim = trim($string);
				$praslug = strtolower(str_replace(" ", "-", $trim));
				$query = $this->db->get_where('tb_post', array('post_slug'=>$praslug));

				if ($query->num_rows() > 1) {
					$unique_string = rand();
					$slug = $praslug.'-'.$unique_string;
				}else{
					$slug = $praslug;
				}

				$xtags[] = $this->input->post('tag');
				foreach ($xtags as $tag) {
					$tags = @implode(",", $tag);
				}

				$description = htmlspecialchars($this->input->post('description', true));

				$data = $this->post_model->get_file_by_id($id)->row();
				$images = "./uploads/images/".$data->post_image;
				$thumbs = "./uploads/thumbs/".$data->post_image;
				unlink($images);
				unlink($thumbs);

				$this->post_model->_update($id, $title, $contents, $category, $slug, $image, $tags, $description);
				$text = $title.' Berhasil Diubah.!';
				$this->session->set_flashdata('toast', $text);
				redirect('admin/post/draft');
			} else{
				redirect('admin/post/draft');
			}
		} else {
			$id 	  = $this->input->post('post_id',TRUE);
			$title = strip_tags(htmlspecialchars($this->input->post('title', true), ENT_QUOTES));
			$contents = $this->input->post('contents');
			$category = $this->input->post('category', true);
			$preslug = strip_tags(htmlspecialchars($this->input->post('slug', true), ENT_QUOTES));
			$string   = preg_replace('/[^a-zA-Z0-9 \&%|{.}=,?!*()"-_+$@;<>\']/', '', $preslug);
			$trim = trim($string);
			$praslug = strtolower(str_replace(" ", "-", $trim));
			$query = $this->db->get_where('tb_post', array('post_slug'=>$praslug));
			if ($query->num_rows() > 1) {
				$unique_string = rand();
				$slug = $praslug.'-'.$unique_string;
			}else{
				$slug = $praslug;
			}

			$xtags[] = $this->input->post('tag');
			foreach ($xtags as $tag) {
				$tags = @implode(",", $tag);
			}
			$description = htmlspecialchars($this->input->post('description', true));

			$this->post_model->_update_no_image($id, $title, $contents, $category, $slug, $tags, $description);
			$text = $title.' Berhasil Diubah.!';
			$this->session->set_flashdata('toast', $text);
			redirect('admin/post/draft');
		}

	}

	function edit()
	{
		$post_id = $this->uri->segment(4);
		$site = $this->site_model->get_site_data()->row_array();
		$data['site_title'] = $site['site_title'];
		$data['site_name'] = $site['site_name'];
		$data['site_keywords'] = $site['site_keywords'];
		$data['site_author'] = $site['site_author'];
		$data['site_description'] = $site['site_description'];
		$data['site_favicon'] = $site['site_favicon'];
		$data['link_kembali'] 	= site_url('admin/post/draft');
		$data['title'] = "Edit Artikel";

		$data['tag'] = $this->tag_model->get_all_tag();
		$data['category'] = $this->category_model->get_all_category();
		$data['data'] = $this->post_model->get_post_by_id($post_id);
		$this->template->load('admin/template', 'admin/edit_post_view', $data);
	}

	function delete()
	{
		$post_id = $this->uri->segment(4);

		$data = $this->post_model->get_file_by_id($post_id)->row();
		$images = "./uploads/images/".$data->post_image;
		$thumbs = "./uploads/thumbs/600x500/".$data->post_image;
		$thumbs2 = "./uploads/thumbs/394x449/".$data->post_image;
		unlink($images);
		unlink($thumbs);
		unlink($thumbs2);
		$this->post_model->delete_post($post_id);
		$text = 'Berhasil Menghapus Data Artikel.!';
		$this->session->set_flashdata('toast', $text);
		redirect('admin/post');
	}

	function publish()
	{
		$config['upload_path'] = './uploads/images/';
		$config['allowed_types'] = 'gif|jpg|png|jpeg|bmp';
		$config['encrypt_name'] = TRUE;
		
		$this->upload->initialize($config);

		if (!empty($_FILES['filefoto']['name'])) {
			if ($this->upload->do_upload('filefoto')) {
				$img = $this->upload->data();

				$config['image_library'] = 'gd2';
				$config['source_image'] = './uploads/images/'.$img['file_name'];
				$config['create_thumb'] = false;
				$config['maintain_ratio'] = false;
				$config['quality'] = '100%';
				$config['width'] = 800;
				$config['height'] = 460;
				$config['new_image'] = './uploads/images/'.$img['file_name'];
				$this->load->library('image_lib', $config);
				$this->image_lib->resize();
				$this->_create_thumbs($img['file_name']);
				$this->_create_thumbs_2($img['file_name']);

				$image = $img['file_name'];
				$title = strip_tags(htmlspecialchars($this->input->post('title', true), ENT_QUOTES));
				$contents = $this->input->post('contents');
				$category = $this->input->post('category', true);
				$preslug = strip_tags(htmlspecialchars($this->input->post('slug', true), ENT_QUOTES));
				$string   = preg_replace('/[^a-zA-Z0-9 \&%|{.}=,?!*()"-_+$@;<>\']/', '', $preslug);
				$trim = trim($string);
				$praslug = strtolower(str_replace(" ", "-", $trim));
				$query = $this->db->get_where('tb_post', array('post_slug'=>$praslug));

				if ($query->num_rows() > 0) {
					$unique_string = rand();
					$slug = $praslug.'-'.$unique_string;
				}else{
					$slug = $praslug;
				}

				$xtags[] = $this->input->post('tag');
				foreach ($xtags as $tag) {
					$tags = @implode(",", $tag);
				}

				$description = htmlspecialchars($this->input->post('description', true));

				$this->post_model->save_post($title, $contents, $category, $slug, $image, $tags, $description);
				$text = $title.' Berhasil Dipublish.!';
				$this->session->set_flashdata('toast', $text);
				redirect('admin/post/draft');
			} else{
				redirect('admin/post/draft');
			}
		} else {
			redirect('admin/post');
		}

	}

	function add()
	{
		$site = $this->site_model->get_site_data()->row_array();
		$data['site_title'] = $site['site_title'];
		$data['site_name'] = $site['site_name'];
		$data['site_keywords'] = $site['site_keywords'];
		$data['site_author'] = $site['site_author'];
		$data['site_description'] = $site['site_description'];
		$data['site_favicon'] = $site['site_favicon'];
		$data['link_kembali'] 	= site_url('admin/post');
		$data['title'] = "Tambah Artikel";
		
		$data['tag'] = $this->tag_model->get_all_tag();
		$data['category'] = $this->category_model->get_all_category();
		$this->template->load('admin/template', 'admin/add_post_view', $data);
	}

	function draft()
	{
		$site = $this->site_model->get_site_data()->row_array();
		$data['site_title'] = $site['site_title'];
		$data['site_name'] = $site['site_name'];
		$data['site_keywords'] = $site['site_keywords'];
		$data['site_author'] = $site['site_author'];
		$data['site_description'] = $site['site_description'];
		$data['title'] = "Artikel";
		$data['site_favicon'] = $site['site_favicon'];

		$data['data'] = $this->post_model->get_draft_post();
		$data['jumlah_draft'] = $this->db->get_where('tb_post', array('post_published' => 0))->num_rows();

		$this->template->load('admin/template', 'admin/post_draft_view', $data);
	}

	function index()
	{
		$site = $this->site_model->get_site_data()->row_array();
		$data['site_title'] = $site['site_title'];
		$data['site_name'] = $site['site_name'];
		$data['site_keywords'] = $site['site_keywords'];
		$data['site_author'] = $site['site_author'];
		$data['site_description'] = $site['site_description'];
		$data['title'] = "Artikel";
		$data['site_favicon'] = $site['site_favicon'];

		$data['data'] = $this->post_model->get_all_post();
		$data['jumlah_draft'] = $this->db->get_where('tb_post', array('post_published' => 0))->num_rows();

		$this->template->load('admin/template', 'admin/post_view', $data);
	}

	function upload_image()
	{
		if (isset($_FILES['file']['name'])) {
			$config['upload_path'] = './uploads/images/';
			$config['allowed_types'] = 'gif|jpg|png|jpeg|bmp';
			$this->upload->initialize($config);
			if (!$this->upload->do_upload('file')) {
				$this->upload->display_errors();
				return FALSE;
			}else{
				$data = $this->upload->data();
		            //Compress Image
				$config['image_library']='gd2';
				$config['source_image']='./uploads/images/'.$data['file_name'];
				$config['create_thumb']= FALSE;
				$config['maintain_ratio']= TRUE;
				$config['quality']= '60%';
				$config['width']= 800;
				$config['height']= 800;
				$config['new_image']= './uploads/images/'.$data['file_name'];
				$this->load->library('image_lib', $config);
				$this->image_lib->resize();
				echo base_url().'uploads/images/'.$data['file_name'];
			}
		}
	}

	function _create_thumbs($file_name)
	{
		$config = array(
			array(
				'image_library' => 'GD2',
				'source_image' => './uploads/images/'.$file_name,
				'maintain_ratio' => false,
				'width' => 600,
				'height' => 500,
				'new_image' => './uploads/thumbs/600x500/'.$file_name
			)
		);

		$this->load->library('image_lib', $config[0]);
		foreach ($config as $item) {
			$this->image_lib->initialize($item);
			if (!$this->image_lib->resize()) {
				return false;
			}
			$this->image_lib->clear();
		}
	}

	function _create_thumbs_2($file_name)
	{
		$config = array(
			array(
				'image_library' => 'GD2',
				'source_image' => './uploads/images/'.$file_name,
				'maintain_ratio' => false,
				'width' => 394,
				'height' => 449,
				'new_image' => './uploads/thumbs/394x449/'.$file_name
			)
		);

		$this->load->library('image_lib', $config[0]);
		foreach ($config as $item) {
			$this->image_lib->initialize($item);
			if (!$this->image_lib->resize()) {
				return false;
			}
			$this->image_lib->clear();
		}
	}

}