<?php 

defined('BASEPATH') OR exit('No direct script access allowed');

class Halaman extends CI_Controller {

	function __construct()
	{
		parent::__construct();
		$this->load->model('Site_model', 'site_model');
		$this->load->model('admin/Halaman_model', 'halaman_model');
		$this->load->library('upload');
		$this->load->helper('text');
	}

	function update($id_halaman)
	{
		$nama_halaman = strip_tags(htmlspecialchars($this->input->post('nama_halaman', true), ENT_QUOTES));
		$contents = $this->input->post('contents');
		$preslug = strip_tags(htmlspecialchars($this->input->post('slug', true), ENT_QUOTES));
		$string   = preg_replace('/[^a-zA-Z0-9 \&%|{.}=,?!*()"-_+$@;<>\']/', '', $preslug);
		$trim = trim($string);
		$praslug = strtolower(str_replace(" ", "-", $trim));
		$query = $this->db->get_where('tb_halaman', array('slug_halaman'=>$praslug));

		if ($query->num_rows() > 1) {
			$unique_string = rand();
			$slug = $praslug.'-'.$unique_string;
		}else{
			$slug = $praslug;
		}

		$this->halaman_model->_update($id_halaman, $nama_halaman, $contents, $slug);
		$text = $nama_halaman.' Berhasil Diubah.!';
		$this->session->set_flashdata('toast', $text);
		redirect('admin/halaman');
		

	}

	function edit()
	{
		$id_halaman = $this->uri->segment(4);
		$site = $this->site_model->get_site_data()->row_array();
		$data['site_title'] = $site['site_title'];
		$data['site_name'] = $site['site_name'];
		$data['site_keywords'] = $site['site_keywords'];
		$data['site_author'] = $site['site_author'];
		$data['site_description'] = $site['site_description'];
		$data['site_favicon'] = $site['site_favicon'];
		$data['link_kembali'] = site_url('admin/halaman');
		$data['title'] = "Edit Halaman";
		$data['data'] = $this->halaman_model->get_halaman_by_id($id_halaman);
		
		$this->template->load('admin/template', 'admin/edit_halaman_view', $data);
	}

	function delete()
	{
		$id_halaman = $this->uri->segment(4);

		$data = $this->halaman_model->get_file_by_id($id_halaman)->row();
		$images = "./uploads/images/".$data->gambar_halaman;
		$thumbs = "./uploads/thumbs/600x500/".$data->gambar_halaman;
		$thumbs2 = "./uploads/thumbs/394x449/".$data->gambar_halaman;
		unlink($images);
		unlink($thumbs);
		unlink($thumbs2);
		$this->halaman_model->delete_halaman($id_halaman);
		$text = 'Berhasil Menghapus Halaman.!';
		$this->session->set_flashdata('toast', $text);
		redirect('admin/halaman');
	}

	function index()
	{
		$site = $this->site_model->get_site_data()->row_array();
		$data['site_title'] = $site['site_title'];
		$data['site_name'] = $site['site_name'];
		$data['site_keywords'] = $site['site_keywords'];
		$data['site_author'] = $site['site_author'];
		$data['site_description'] = $site['site_description'];
		$data['site_favicon'] = $site['site_favicon'];
		$data['title'] = "Halaman";

		$data['data'] = $this->halaman_model->get_all_halaman();

		$this->template->load('admin/template', 'admin/halaman_view', $data);
	}

	function add()
	{
		$site = $this->site_model->get_site_data()->row_array();
		$data['site_title'] = $site['site_title'];
		$data['site_name'] = $site['site_name'];
		$data['site_keywords'] = $site['site_keywords'];
		$data['site_author'] = $site['site_author'];
		$data['site_description'] = $site['site_description'];
		$data['site_favicon'] = $site['site_favicon'];
		$data['link_kembali'] = site_url('admin/halaman');
		$data['title'] = "Tambah Halaman";

		$this->template->load('admin/template', 'admin/add_halaman_view', $data);
	}

	function publish()
	{
		$nama_halaman = strip_tags(htmlspecialchars($this->input->post('nama_halaman', true), ENT_QUOTES));
		$contents = $this->input->post('contents');
		$preslug = strip_tags(htmlspecialchars($this->input->post('slug', true), ENT_QUOTES));
		$string   = preg_replace('/[^a-zA-Z0-9 \&%|{.}=,?!*()"-_+$@;<>\']/', '', $preslug);
		$trim = trim($string);
		$praslug = strtolower(str_replace(" ", "-", $trim));
		$query = $this->db->get_where('tb_halaman', array('slug_halaman'=>$praslug));

		if ($query->num_rows() > 0) {
			$unique_string = rand();
			$slug = $praslug.'-'.$unique_string;
		}else{
			$slug = $praslug;
		}

		$this->halaman_model->simpan_halaman($nama_halaman, $slug, $contents);
		$text = $nama_halaman.' Berhasil Dipublish.!';
		$this->session->set_flashdata('toast', $text);
		redirect('admin/halaman');

	}

	function _create_thumbs($file_name)
	{
		$config = array(
			array(
				'image_library' => 'GD2',
				'source_image' => './uploads/images/'.$file_name,
				'maintain_ratio' => false,
				'width' => 600,
				'height' => 500,
				'new_image' => './uploads/thumbs/600x500/'.$file_name
			)
		);

		$this->load->library('image_lib', $config[0]);
		foreach ($config as $item) {
			$this->image_lib->initialize($item);
			if (!$this->image_lib->resize()) {
				return false;
			}
			$this->image_lib->clear();
		}
	}

	function _create_thumbs_2($file_name)
	{
		$config = array(
			array(
				'image_library' => 'GD2',
				'source_image' => './uploads/images/'.$file_name,
				'maintain_ratio' => false,
				'width' => 394,
				'height' => 449,
				'new_image' => './uploads/thumbs/394x449/'.$file_name
			)
		);

		$this->load->library('image_lib', $config[0]);
		foreach ($config as $item) {
			$this->image_lib->initialize($item);
			if (!$this->image_lib->resize()) {
				return false;
			}
			$this->image_lib->clear();
		}
	}

}

/* End of file Halaman.php */
/* Location: ./application/controllers/admin/Halaman.php */

?>