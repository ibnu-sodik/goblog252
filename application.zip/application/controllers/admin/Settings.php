<?php 
/**
 * Settings
 */
class Settings extends CI_Controller
{
	
	function __construct()
	{
		parent::__construct();
		$this->load->model('Site_model', 'site_model');
		$this->load->library('upload');
		$this->load->helper('text');
	}

	function delete()
	{
		$sosmed_id = $this->uri->segment(4);

		$this->site_model->delete_sosmed($sosmed_id);
		$text = 'Sosmed Berhasil Dihapus.!';
		$this->session->set_flashdata('toast', $text);
		redirect('admin/settings');
	}

	function edit_sosmed()
	{
		$own_sosmed_id = sanitize($this->input->post('site_id', TRUE));
		$sosmed_id = sanitize($this->input->post('sosmed_id', TRUE));
		$sosmed_name = sanitize($this->input->post('sosmed_name2', TRUE));
		$sosmed_url = sanitize($this->input->post('sosmed_url2', TRUE));
		$sosmed_icon = sanitize($this->input->post('sosmed_icon2', TRUE));
		// lakukan
		$this->site_model->update_sosmed($sosmed_name, $sosmed_url, $sosmed_icon, $sosmed_id);
		$text = $sosmed_name.' Berhasil Diubah.!';
		$this->session->set_flashdata('toast', $text);
		redirect('admin/settings');
	}

	function add_sosmed()
	{
		$own_sosmed_id = sanitize($this->input->post('site_id', TRUE));
		$sosmed_name = sanitize($this->input->post('sosmed_name', TRUE));
		$sosmed_url = sanitize($this->input->post('sosmed_url', TRUE));
		$sosmed_icon = sanitize($this->input->post('sosmed_icon', TRUE));
		// lakukan
		$data = $this->site_model->get_site_by_id($own_sosmed_id)->row();
		$site_name = $data->site_name;
		$this->site_model->save_sosmed($sosmed_name, $sosmed_url, $sosmed_icon, $own_sosmed_id);
		$text = $sosmed_name.' Berhasil Ditambahkan Ke '.$site_name;
		$this->session->set_flashdata('toast', $text);
		redirect('admin/settings');
	}

	function index()
	{
		$result = $this->site_model->get_site_data()->row_array();

		$data['site_id'] = $result['site_id'];
		$data['site_name'] = $result['site_name'];
		$data['site_title'] = $result['site_title'];
		$data['site_author'] = $result['site_author'];
		$data['site_keywords'] = $result['site_keywords'];
		$data['site_description'] = $result['site_description'];
		$data['site_favicon'] = $result['site_favicon'];
		$data['site_logo_header'] = $result['site_logo_header'];
		$data['site_logo_footer'] = $result['site_logo_footer'];
		$data['site_logo_big'] = $result['site_logo_big'];
		$data['konten_kontak'] = $result['konten_kontak'];

		$data['limit_post'] = $result['limit_post'];
		$data['limit_popular_post'] = $result['limit_popular_post'];
		$data['limit_recent_views'] = $result['limit_recent_views'];
		$data['limit_latest_post'] = $result['limit_latest_post'];
		$data['title'] = 'Settings';

		$site_id = $result['site_id'];
		$data['sosmed_web'] = $this->site_model->get_sosmed_by_own($site_id);

		$data['pilih_web'] = $this->site_model->get_site_data();
		
		$this->template->load('admin/template', 'admin/settings_view', $data);
	}

	function update_contact_page()
	{
		$site_id = $this->input->post('site_id', TRUE);
		$konten_kontak = $this->input->post('contents', TRUE);

		$this->site_model->update_contact_page($site_id, $konten_kontak);
		$text = 'Konten Halaman Kontak Berhasil Diubah.!';
		$this->session->set_flashdata('toast', $text);
		redirect('admin/settings');
	}

	function update_info()
	{
		$site_id = $this->input->post('site_id', TRUE);
		$site_title = sanitize($this->input->post('site_title', TRUE));
		$site_name = sanitize($this->input->post('site_name', TRUE));
		$site_keywords = sanitize($this->input->post('site_keywords', TRUE));
		$site_description = sanitize($this->input->post('site_description', TRUE));
		
		// lakukan
		$this->site_model->update_info($site_id, $site_title, $site_name, $site_keywords, $site_description);
		$text = $site_name.' Berhasil Diubah.!';
		$this->session->set_flashdata('toast', $text);
		redirect('admin/settings');
	}

	function update_limit()
	{
		$site_id = $this->input->post('site_id', TRUE);
		$limit_post = sanitize($this->input->post('limit_post', TRUE));
		$limit_popular_post = sanitize($this->input->post('limit_popular_post', TRUE));
		$limit_recent_views = sanitize($this->input->post('limit_recent_views', TRUE));
		$limit_latest_post = sanitize($this->input->post('limit_latest_post', TRUE));
		
		// lakukan
		$this->site_model->update_limit($site_id, $limit_post, $limit_popular_post, $limit_recent_views, $limit_latest_post);
		$text = 'Jumlah Tampilan Posting Berhasil Diubah.!';
		$this->session->set_flashdata('toast', $text);
		redirect('admin/settings');
	}

	function update_img()
	{
		$site_id = $this->input->post('site_id', TRUE);
		$data = $this->site_model->get_site_by_id($site_id)->row();
		$site_name = $data->site_name;

		$f_sf = "./assets/images/".$data->site_favicon;
		$f_slh = "./assets/images/".$data->site_logo_header;
		$f_slf = "./assets/images/".$data->site_logo_footer;

		$config['upload_path'] = './assets/images/';
		$config['allowed_types'] = 'gif|jpg|png|bmp|jpeg|ico';
		$config['encrypt_name'] = FALSE;
		
		$this->upload->initialize($config);
		$site_favicon = $_FILES['site_favicon']['name'];
		$site_logo_header = $_FILES['site_logo_header']['name'];
		$site_logo_footer = $_FILES['site_logo_footer']['name'];

		if (!empty($site_favicon) && !empty($site_logo_header) && !empty($site_logo_footer)) {
			unlink($f_sf);
			unlink($f_slh);
			unlink($f_slf);

	    	// Upload semua gambar
			if ($this->upload->do_upload('site_favicon')) {
				$sf = $this->upload->data();
				$site_favicon = $sf['file_name'];
			}
			if ($this->upload->do_upload('site_logo_header')) {
				$slh = $this->upload->data();
				$site_logo_header = $slh['file_name'];
			}
			if ($this->upload->do_upload('site_logo_footer')) {
				$slf = $this->upload->data();
				$site_logo_footer = $slf['file_name'];
			}
			// lakukan
			$this->site_model->update_img($site_id, $site_favicon, $site_logo_header, $site_logo_footer);
			$text = $site_name.' Berhasil Diubah.!';
			$this->session->set_flashdata('toast', $text);
			redirect('admin/settings');

		} 
		elseif (empty($site_favicon) && !empty($site_logo_header) && !empty($site_logo_footer)) {
			unlink($f_slh);
			unlink($f_slf);

			if ($this->upload->do_upload('site_logo_header')) {
				$slh = $this->upload->data();
				$site_logo_header = $slh['file_name'];
			}
			if ($this->upload->do_upload('site_logo_footer')) {
				$slf = $this->upload->data();
				$site_logo_footer = $slf['file_name'];
			}
			// lakukan
			$this->site_model->update_img_tanpa_ikon($site_id, $site_logo_header, $site_logo_footer);
			$text = $site_name.' Berhasil Diubah.!';
			$this->session->set_flashdata('toast', $text);
			redirect('admin/settings');

		} 
		elseif (!empty($site_favicon) && empty($site_logo_header) && !empty($site_logo_footer)) {
			unlink($f_sf);
			unlink($f_slf);
			if ($this->upload->do_upload('site_favicon')) {
				$sf = $this->upload->data();
				$site_favicon = $sf['file_name'];
			}
			if ($this->upload->do_upload('site_logo_footer')) {
				$slf = $this->upload->data();
				$site_logo_footer = $slf['file_name'];
			}
			// lakukan
			$this->site_model->update_info_tanpa_header($site_id, $site_favicon, $site_logo_footer);
			$text = $site_name.' Berhasil Diubah.!';
			$this->session->set_flashdata('toast', $text);
			redirect('admin/settings');

		} 
		elseif (!empty($site_favicon) && !empty($site_logo_header) && empty($site_logo_footer)) {
			unlink($f_sf);
			unlink($f_slh);
			if ($this->upload->do_upload('site_favicon')) {
				$sf = $this->upload->data();
				$site_favicon = $sf['file_name'];
			}
			if ($this->upload->do_upload('site_logo_header')) {
				$slh = $this->upload->data();
				$site_logo_header = $slh['file_name'];
			}
			// lakukan
			$this->site_model->update_info_tanpa_footer($site_id, $site_favicon, $site_logo_header);
			$text = $site_name.' Berhasil Diubah.!';
			$this->session->set_flashdata('toast', $text);
			redirect('admin/settings');

		}
		elseif (!empty($f_sf) && empty($f_slh) && empty($f_slf)) {
			unlink($f_sf);
			if ($this->upload->do_upload('site_favicon')) {
				$f_sf = $this->upload->data();
				$site_favicon = $f_sf['file_name'];
			}
			// lakukan
			$this->site_model->update_info_hanya_icon($site_id, $site_favicon);
			$text = $site_name.' Berhasil Diubah.!';
			$this->session->set_flashdata('toast', $text);
			redirect('admin/settings');
		}
		elseif (empty($f_sf) && empty($f_slh) && !empty($f_slf)) {
			unlink($f_slf);
			if ($this->upload->do_upload('site_logo_footer')) {
				$slf = $this->upload->data();
				$site_logo_footer = $slf['file_name'];
			}
			// lakukan
			$this->site_model->update_info_hanya_footer($site_id, $site_logo_footer);
			$text = $site_name.' Berhasil Diubah.!';
			$this->session->set_flashdata('toast', $text);
			redirect('admin/settings');
		}
		elseif (empty($f_sf) && !empty($f_slh) && empty($f_slf)) {
			unlink($f_slh);
			if ($this->upload->do_upload('site_logo_header')) {
				$slh = $this->upload->data();
				$site_logo_header = $slh['file_name'];
			}
			// lakukan
			$this->site_model->update_info_hanya_header($site_id, $site_logo_header);
			$text = $site_name.' Berhasil Diubah.!';
			$this->session->set_flashdata('toast', $text);
			redirect('admin/settings');
		}
		else{
			$text = $site_name.' Tidak Berubah.!';
			$this->session->set_flashdata('toast', $text);
			redirect('admin/settings');
		}
	}

}