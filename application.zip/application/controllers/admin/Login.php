<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Login extends CI_Controller {
	
	function __construct()
	{
		parent::__construct();
		$this->load->library('session');
		$this->load->model('admin/Login_model', 'login_model');
		$this->load->model('Site_model', 'site_model');
		if ($this->session->userdata('logged_in') == TRUE) {
			$url = base_url('admin/dashboard');
			redirect($url);
		}
	}

	function index()
	{
		$site = $this->site_model->get_site_data()->row_array();
		$data['site_title'] 		= $site['site_title'];
		$data['site_keywords'] 		= $site['site_keywords'];
		$data['site_author'] 		= $site['site_author'];
		$data['site_description'] 	= $site['site_description'];
		$data['site_favicon'] 		= $site['site_favicon'];
		$data['site_logo_header'] 	= $site['site_logo_header'];
		$data['form_action'] 		= site_url('admin/login/auth');
		$data['flash']				= $this->session->flashdata('pesan');
		$this->load->view('admin/login_view', $data);
		$this->load->helper('text');
	}

	function auth()
	{
		$username = str_replace("'", "", htmlspecialchars($this->input->post('username', True), ENT_QUOTES));
		$password = str_replace("'", "", htmlspecialchars($this->input->post('password', True), ENT_QUOTES));
		$validasi = $this->login_model->validasi($username, $password);

		if ($validasi->num_rows() > 0) {
			$this->session->set_userdata('logged_in', TRUE);
			$date = date('Y-m-d H:i:s');

			$user_data = $validasi->row_array();
			if ($user_data['level']==1) {
				// Admin
				$this->session->set_userdata('access', '1');
				$id = $user_data['id'];
				$this->login_model->update_login($date, $id);
				$last_login = $user_data['last_login'];
				$full_name = $user_data['full_name'];
				$this->session->set_userdata('id', $id);
				$this->session->set_userdata('full_name', $full_name);
				redirect('admin/dashboard');
			} else {
				// Other access
				$this->session->set_userdata('access', '2');
				$id = $user_data['id'];
				$this->login_model->update_login($date, $id);
				$last_login = $user_data['last_login'];
				$full_name = $user_data['full_name'];
				$this->session->set_userdata('id', $id);
				$this->session->set_userdata('full_name', $full_name);
				redirect('admin/dashboard');
			}
		} else {
			$url = base_url('admin');
			$text = 'Username Atau Password Salah.!';
			$this->session->set_flashdata('toast', $text);
			redirect($url);
		}

	}

}

/* End of file Login.php */
/* Location: ./application/controllers/admin/Login.php */