<?php
/**
 * Tag
 */
class Tag extends CI_Controller
{
	
	function __construct()
	{
		parent::__construct();
		$this->load->model('admin/Tag_model', 'tag_model');
		$this->load->model('Site_model', 'site_model');
		$this->load->helper('text');
	}

	function update()
	{
		$id = $this->input->post('id_tag',TRUE);
		$tag = strip_tags(htmlspecialchars($this->input->post('tag2',TRUE),ENT_QUOTES));
		$string   = preg_replace('/[^a-zA-Z0-9 \&%|{.}=,?!*()"-_+$@;<>\']/', '', $tag);
		$trim     = trim($string);
		$slug     = strtolower(str_replace(" ", "-", $trim));
		$this->tag_model->_update($id,$tag,$slug);
		$text = $tag. ' Berhasil Diubah.!';
		$this->session->set_flashdata('toast', $text);
		redirect('admin/tag');
	}

	function save()
	{
		$tag = strip_tags(htmlspecialchars($this->input->post('tag',TRUE),ENT_QUOTES));
		$string   = preg_replace('/[^a-zA-Z0-9 \&%|{.}=,?!*()"-_+$@;<>\']/', '', $tag);
		$trim     = trim($string);
		$slug     = strtolower(str_replace(" ", "-", $trim));
		$this->tag_model->_insert($tag,$slug);
		$text = 'Berhasil Menambah Tag '.$tag;
		$this->session->set_flashdata('toast', $text);
		redirect('admin/tag');
	}

	function delete()
	{
		$tag_id = $this->uri->segment(4);

		$this->tag_model->delete_tag($tag_id);
		$text = 'Tag Berhasil Dihapus.!';
		$this->session->set_flashdata('toast', $text);
		redirect('admin/tag');
	}

	function index()
	{
		$site = $this->site_model->get_site_data()->row_array();
		$data['site_title'] = $site['site_title'];
		$data['site_name'] = $site['site_name'];
		$data['site_keywords'] = $site['site_keywords'];
		$data['site_favicon'] = $site['site_favicon'];
		$data['site_author'] = $site['site_author'];
		$data['site_logo_footer'] = $site['site_logo_footer'];
		$data['site_logo_header'] = $site['site_logo_header'];
		$data['site_description'] = $site['site_description'];
		$data['title'] = "Tag";

		$data['data'] = $this->tag_model->get_all_tag();
		$this->template->load('admin/template', 'admin/tag_view', $data);
	}

}