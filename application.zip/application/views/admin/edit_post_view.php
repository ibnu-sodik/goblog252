<?php 
$row = $data->row_array();
?>
<div class="row">
	<div class="col-md-12">
		<h6 class="page-head-line">
		<a href="<?= $link_kembali; ?>" class="btn btn-default"><i class="fa fa-arrow-left"></i></a>
			&nbsp;Edit Artikel</h6>
		<form method="POST" enctype="multipart/form-data" action="<?= site_url('admin/post/update') ?>">

			<div class="col-md-8">

				<div class="form-group">
					<label for="title">Judul</label>
					<input type="hidden" name="post_id" value="<?= $row['post_id'] ?>">
					<input type="text" id="title" value="<?= $row['post_title'] ?>" name="title" placeholder="Judul" class="form-control judul" autofocus required>
				</div>
				<div class="form-group">
					<input type="text" value="<?= $row['post_slug'] ?>" name="slug" class="form-control slug btn-link" placeholder="Permalink" readonly>
				</div>
				<div class="form-group">
					<label for="content">Konten</label>
					<textarea id="summernote" name="contents" cols="8" rows="8"><?= $row['post_contents'] ?></textarea>
				</div>

			</div>

			<div class="col-md-4">

				<div class="form-group">
					<label for="image">Gambar</label>
					<input type="file" name="filefoto" id="image" class="dropify" data-height="190" data-default-file="<?= base_url('uploads/thumbs/600x500/'.$row['post_image']) ?>">
				</div>
				<div class="form-group">
					<label for="category">Kategori</label>
					<select name="category" class="form-control" id="category" required>
						<option value="">-----Pilih Kategori-----</option>
						<?php foreach ($category->result() as $val): ?>
							<?php if ($row['post_category_id']==$val->category_id): ?>
								<option value="<?= $val->category_id; ?>" selected><?= $val->category_name ?></option>
								<?php else: ?>
									<option value="<?= $val->category_id; ?>"><?= $val->category_name; ?></option>
								<?php endif ?>
							<?php endforeach ?>
						</select>
					</div>
					<div class="form-group">
						<label for="tags">Tag</label>
						<div style="overflow-y: scroll;height: 150px;margin-bottom: 30px;">
							<?php 
							$post_tag = $row['post_tags'];
							$strtag = explode(",", $post_tag);
							for ($i=0; $i < count($strtag); $i++) { }
								foreach($tag->result() as $rtag): ?>
									<div class="form-group checkbox">
										<label>
											<input type="checkbox" name="tag[]" value="<?= $rtag->tag_slug; ?>"
											<?php if(in_array($rtag->tag_slug, $strtag)){echo 'checked="checked"';} ?>> <?= $rtag->tag_name; ?>
										</label>
									</div>
								<?php endforeach; ?>
							</div>
						</div>
						<button type="submit" class="btn btn-md btn-default btn-block">
							<i class="fa fa-fw fa-send"></i> Publish
						</button>
						<hr>
						<div class="form-group">
							<label for="meta-description">Deskripsi Meta</label>
							<textarea cols="6" rows="6" class="form-control" placeholder="Deskripsi Meta" id="meta-description" name="description"><?= $row['post_description'] ?></textarea>
						</div>

					</div>
				</form>
			</div>
		</div>
