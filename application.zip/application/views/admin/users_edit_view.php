<div class="row">
	<div class="col-md-12">
		<h2 class="page-head-line">
			<a href="<?= $link_kembali; ?>" class="btn btn-default"><i class="fa fa-arrow-left"></i></a>&nbsp;Edit User <small><?=$full_name;?></small></h2>

			<ul class="nav nav-tabs">
				<li class="active">
					<a href="#personalInfo" data-toggle="tab">Informasi Pribadi</a>
				</li>				
				<li class="">
					<a href="#changePass" data-toggle="tab">Ganti Password</a>
				</li>
				<li class="">
					<a href="#sosmed" data-toggle="tab">Sosial Media</a>
				</li>
			</ul>

			<div class="tab-content">
				
				<div class="tab-pane fade active in" id="personalInfo">
					<div class="row pad-top-botm ">
						<hr>
						<?php
						$file = file_exists(base_url('uploads/thumbs/admin/'.$foto)); 
						if (!$file && empty($foto)):
							?>
							<div class="col-lg-3 col-md-3 col-sm-3 ">
								<form enctype="multipart/form-data" method="POST" action="<?=site_url('admin/users/update_foto/'.$id)?>">
									<label></label>
									<input type="file" name="filefoto" class="dropify" required>
									<div style="margin-bottom: 3px;"></div>
									<button type="submit" class="btn btn-block btn-info">Simpan <i class="fa fa-fw fa-send"></i></button>
								</form>
							</div>
							<?php else: ?>
								<div class="col-lg-3 col-md-3 col-sm-3 text-center">
									<img class="img-thumbnail img-responsive" src="<?= base_url('uploads/thumbs/admin/'.$foto); ?>">
									<div style="margin-bottom: 3px;"></div>
									<a class="btn btn-block btn-danger" href="<?=site_url('admin/users/delete_foto/'.$id)?>" title="Hapus">Hapus <i class="fa fa-fw fa-trash"></i></a>
								</div>
							<?php endif ?>

							<div class="col-lg-3 col-md-3 col-sm-3">
								<form method="POST" action="<?= site_url('admin/users/update_personal/'.$id); ?>">
									<div class="form-group">
										<label for="full_name">Nama</label>
										<input type="text" name="full_name" id="full_name" class="form-control" placeholder="Nama" value="<?=$full_name;?>">
									</div>
									<div class="form-group">
										<label for="username">Username</label>
										<input type="text" name="username" id="username" class="form-control" placeholder="Username" value="<?=$username;?>">
									</div>
									<div class="form-group">
										<label for="email">Email</label>
										<input type="text" name="email" id="email" class="form-control" placeholder="Email" value="<?=$email;?>">
									</div>
									<div class="form-group">
										<button type="submit" name="submit" class="btn btn-block btn-info">Simpan <i class="fa fa-send"></i></button>
									</div>
								</form>
							</div>

							<div class="col-md-6 col-sm-6 col-lg-6">
								<form method="POST" action="<?= site_url('admin/users/update_user_info/'.$id); ?>">
									<div class="form-group">
										<label for="contents">Quotes</label>
										<textarea required class="form-control" id="summernote" name="contents"><?= $user_info; ?></textarea>
									</div>
									<div class="form-group">
										<button type="submit" name="submit" class="btn btn-block btn-info">Simpan <i class="fa fa-send"></i></button>
									</div>
								</form>
							</div>
						</div>
					</div>

					<div class="tab-pane fade" id="changePass">
						<hr>
						<form class="form-inline" method="POST" action="<?= site_url('admin/users/update_password/'.$id) ?>">
							<div class="form-group">
								<input type="password" name="password" class="form-control" placeholder="Password Baru">
							</div>
							<div class="form-group">
								<input type="password" name="conf_password" class="form-control" placeholder="Konfirmasi Password">
							</div>
							<div class="form-group">
								<button type="submit" name="submit" class="btn btn-block btn-info">Simpan <i class="fa fa-send"></i></button>
							</div>
						</form>
					</div>

					<div class="tab-pane fade" id="sosmed">
						<div class="col-md-12">
							<h3>Website Social Links</h3>
							<hr>
							<a href="#" class="btn btn-primary tombol-layang tombol-modal" data-target="#addModal" data-toggle="modal"><i class="fa fa-fw fa-plus fa-1x"></i></a>
							<div class="table-responsive">
								<table class="table table-hover table-striped" id="tabelku">
									<thead>
										<tr>
											<th class="text-center">No</th>
											<th class="text-center">Nama Sosmed</th>
											<th class="text-center">URL</th>
											<th class="text-center">Icon</th>
											<th class="text-center">Opsi</th>
										</tr>
									</thead>
									<tbody>
										<?php 
										$no=0;
										foreach($sosmed_author->result() as $row):
											$no++;
											?>
											<tr>
												<td class="text-center"><?= $no; ?></td>
												<td class="text-center"><?= $row->sosmed_name; ?></td>
												<td class="text-center">
													<a href="<?= $row->sosmed_url; ?>" class="btn btn-primary" target="_blank"><?= $row->sosmed_name; ?> <i class="fa fa-eye"></i></a>
												</td>
												<td class="text-center"><i class="fa fa-<?= $row->sosmed_icon; ?>"></i></td>
												<td class="text-center">
													<a href="javascript:void(0);" title="Edit" data-id="<?=$row->sosmed_id; ?>" 
														data-sosmed="<?=$row->sosmed_name; ?>" 
														data-url="<?=$row->sosmed_url; ?>" 
														data-icon="<?=$row->sosmed_icon; ?>" 
														data-own="<?=$row->own_user_id; ?>" 
														class="btn btn-sm btn-warning edit-sosmedOwn"><i class="fa fa-pencil"></i></a>

														<a title="Hapus" href="<?=site_url('admin/users/delete_sosmed/'.$row->sosmed_id); ?>" class="btn btn-sm btn-danger tombol-hapus"><i class="fa fa-trash"></i></a>
													</td>
												</tr>
											<?php endforeach; ?>
										</tbody>
									</table>
								</div>

								<!-- modal add -->
								<div class="modal fade" id="addModal" tabindex="-1" role="dialog" aria-labelledby="modalSosmed" aria-hidden="true">
									<div class="modal-dialog">
										<div class="modal-content">
											<div class="modal-header">					
												<button type="button" class="close" data-dismiss="modal" aria-label="Close">
													<span aria-hidden="true">&times;</span>
												</button>
												<h4 class="modal-title">Tambah Sosmed</h4>
											</div>
											<form method="post" action="<?= base_url('admin/users/add_sosmed'); ?>">

												<div class="modal-body">
													<div class="form-group">
														<label for="sosmed_name">Nama Sosmed</label>
														<input type="text" name="sosmed_name" id="sosmed_name" class="form-control" required placeholder="Nama Sosmed">
													</div>
													<div class="form-group">
														<label for="sosmed_url">Url Sosmed</label>
														<input type="text" name="sosmed_url" id="sosmed_url" class="form-control" placeholder="Url Sosmed" />
													</div>
													<div class="form-group">
														<label for="sosmed_icon">Icon Sosmed</label>
														<div class="input-group">
															<span class="form-group input-group-btn">
																<button class="btn btn-default disabled" type="button">fa fa-</button>
															</span>
															<input type="text" name="sosmed_icon" id="sosmed_icon" class="form-control" placeholder="Icon Sosmed" />
														</div>
													</div>

												</div>
												<div class="modal-footer">
													<input type="hidden" name="own_user_id" required value="<?= $id; ?>">
													<button type="submit" class="btn btn-primary"><i class="fa fa-fw fa-save"></i> Simpan</button>
													<button type="button" class="btn btn-secondary" data-dismiss="modal">Tutup <i class="fa fa-fw fa-remove"></i></button>
												</div>

											</form>
										</div>
									</div>
								</div>

								<!-- modal edit -->
								<div class="modal fade" id="editModal" tabindex="-1" role="dialog" aria-labelledby="modalSosmed" aria-hidden="true">
									<div class="modal-dialog">
										<div class="modal-content">
											<div class="modal-header">					
												<button type="button" class="close" data-dismiss="modal" aria-label="Close">
													<span aria-hidden="true">&times;</span>
												</button>
												<h4 class="modal-title">Edit Sosmed</h4>
											</div>
											<form method="post" action="<?= base_url('admin/users/edit_sosmed'); ?>">

												<div class="modal-body">
													<div class="form-group">
														<label for="sosmed_name2">Nama Sosmed</label>
														<input type="text" name="sosmed_name2" id="sosmed_name2" class="form-control" required placeholder="Nama Sosmed">
													</div>
													<div class="form-group">
														<label for="sosmed_url2">Url Sosmed</label>
														<input type="text" name="sosmed_url2" id="sosmed_url2" class="form-control" placeholder="Url Sosmed" />
													</div>
													<div class="form-group">
														<label for="sosmed_icon2">Icon Sosmed</label>
														<div class="input-group">
															<span class="form-group input-group-btn">
																<button class="btn btn-default disabled" type="button">fa fa-</button>
															</span>
															<input type="text" name="sosmed_icon2" id="sosmed_icon2" class="form-control" placeholder="Icon Sosmed" />
														</div>
													</div>

												</div>
												<div class="modal-footer">
													<input type="hidden" name="sosmed_id">
													<input type="hidden" name="own_user_id">
													<button type="submit" class="btn btn-primary"><i class="fa fa-fw fa-save"></i> Simpan</button>
													<button type="button" class="btn btn-secondary" data-dismiss="modal">Tutup <i class="fa fa-fw fa-remove"></i></button>
												</div>

											</form>
										</div>
									</div>
								</div>
							</div>
						</div>

					</div>
				</div>
			</div>