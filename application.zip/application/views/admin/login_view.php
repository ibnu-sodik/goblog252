<!DOCTYPE html>
<html">
<head>
	<meta charset="utf-8" />
	<meta name="viewport" content="width=device-width, initial-scale=1.0" />
	<title><?=$site_title;?>::LogIn</title>
	<link rel="shortcut icon" href="<?= base_url('assets/images/'.$site_favicon) ?>" type="image/x-icon" />

	<link href="<?=base_url()?>assets2/css/bootstrap.css" rel="stylesheet" />
	<link href="<?=base_url()?>assets2/css/font-awesome.css" rel="stylesheet" />
	<link href='https://fonts.googleapis.com/css?family=Open+Sans' rel='stylesheet' type='text/css' />

	<script src="<?=base_url()?>assets2/js/sweetalert.min.js"></script>

</head>
<body style="background-color: #757575;">
	<div class="container">

		<div class="flash-data" data-flashdata="<?= $this->session->flashdata('pesan'); ?>">
		</div>	

		<div class="row text-center " style="padding-top:100px;">
			<div class="col-md-12">
				<img src="<?=base_url('assets/images/'.$site_logo_header);?>" />
			</div>
		</div>
		<div class="row ">
			<div class="col-md-4 col-md-offset-4 col-sm-6 col-sm-offset-3 col-xs-10 col-xs-offset-1">

				<div class="panel-body">
					<form role="form" action="<?=$form_action?>" method="post">
						<div class="form-group input-group">
							<span class="input-group-addon"><i class="fa fa-fw fa-user"  ></i></span>
							<input type="text" class="form-control" name="username" placeholder="Username " required autofocus>
						</div>
						<div class="form-group input-group">
							<span class="input-group-addon"><i class="fa fa-fw fa-lock"  ></i></span>
							<input id="password" type="password" name="password" class="form-control"  placeholder="Password" required>
							<span class="input-group-addon"><i class="fa fa-fw fa-eye" id="toggle-password"></i></span>
						</div>

						<button type="submit" class="btn btn-success btn-block">Login</button>
						<div class="form-group">
							<span class="pull-right">
								<a style="color: #fff; text-decoration: none;" href="<?=base_url()?>lupa-password" >Lupa password ? </a> 
							</span>
						</div>
						<hr />
						Belum terdaftar ? <a style="color: #fff; text-decoration: none;" href="<?=base_url()?>register" >klik disini </a> atau kembali ke <a style="color: #fff; text-decoration: none;" href="<?=base_url()?>">Home</a> 
					</form>
				</div>
			</div>
		</div>
	</div>
	<script type="text/javascript" src="<?= base_url('assets2/js/jquery-1.10.2.js'); ?>"></script>
	<script type="text/javascript" src="<?= base_url('assets2/js/bootstrap.js'); ?>"></script>
	<script type="text/javascript" src="<?= base_url('assets2/js/goblog.js'); ?>"></script>
</body>
</html>
