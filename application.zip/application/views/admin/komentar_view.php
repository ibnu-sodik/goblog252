<div class="row">
	<div class="col-md-12">

		<h2 class="page-head-line">Menu Settings</h2>
		<div class="col-md-4 col-md-offset-8">
			<form role="form" method="GET" action="<?= site_url('admin/komentar/hasil') ?>">
				<div class="input-group">
					<input type="text" name="cari" class="form-control" placeholder="Cari Komentar..." />
					<span class="form-group input-group-btn">
						<button type="submit" class="btn btn-info" type="button"><i class="fa fa-gear fa-spin"></i> Cari</button>
					</span>
				</div>				
			</form>
		</div>
		<div class="clearfix"></div>
		<hr>
		<ul class="nav nav-tabs">
			<li class="active" role="presentation">
				<a href="#all" data-toggle="tab">Semua Komentar <span class="badge bg-default"><?= $jumlah_semua; ?></span></a>
			</li>
			<li role="presentation">
				<a href="<?= site_url('admin/komentar/unpublish') ?>" >Butuh Moderasi <span class="badge bg-info"><?= $jumlah_unpublish; ?></span></a>
			</li>
		</ul>

		<div class="tab-content">
			<div class="tab-pane fade active in" id="all">
				<div class="text-center">
					<marquee>
						<div class="alert alert-warning alert-dismissable col-md-5">
							<button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
							<p><b>Perhatian.!</b> Jangan Hapus Komentar Dari <b>Parent Awal.</b> Hapuslah Dari <b>Child Ke Dua.</b></p>
						</div>
					</marquee>
				</div>
				<div class="panel panel-default">
					<div class="panel-body">
						<ul class="media-list">
							
							<?php foreach ($komentar->result() as $row): ?>
								<ul class="media-list">
									<li class="media">
										<div class="media-heading">
											<h4><a href="<?= site_url('blog/'.$row->post_slug); ?>" target="_blank"><?= $row->post_title; ?></a></h4>
										</div>
										<br>
										<?php 
										$hash = md5( strtolower( trim( $row->comment_email ) ) );
										$link_foto = 'https://www.gravatar.com/avatar/'.$hash;
										?>
										<span class="pull-left">
											<img class="media-object img-circle img-responsive" src="<?= $link_foto; ?>?s=50&r=pg">
										</span>
										<div class="media-body">
											<h4 class="media-heading">
												<?= $row->comment_name; ?> <small><?= '< '.$row->comment_email.' >'; ?></small>
											</h4>
											<span><?= date('d F Y H:i', strtotime($row->comment_date));?></span>
											<div class="clearfix"></div>
											
											<?php if ($row->comment_status == '1'): ?>
												<div class="col-md-offset-10 pull-right">
													<a data-comment_id="<?= $row->comment_id; ?>" data-comment_post_id="<?= $row->post_id; ?>" title="Balas" href="javascript:void(0)" class="btn btn-info btn-sm tombol-balas"><i class="fa fa-reply"></i></a>

													<a data-comment_id="<?= $row->comment_id; ?>" data-comment_message="<?= $row->comment_message; ?>" data-nama_web="<?= $row->komentator_website; ?>" title="Edit" href="javascript:void(0)" class="btn btn-warning btn-sm tombol-edit"><i class="fa fa-pencil"></i></a>

													<a title="Hapus" href="<?= site_url('admin/komentar/hapus/'.$row->comment_id); ?>" class="btn btn-danger btn-sm tombol-hapus"><i class="fa fa-trash"></i></a>
													</div><?php else: ?>
													<div class="col-md-offset-10 pull-right">
														<p class="label label-danger">Komentar Butuh Moderasi <i class="fa fa-exclamation"></i></p>
													</div>												
												<?php endif; ?>

												<?php if (!empty($row->komentator_website)): ?>
													<a target="_blank" class="btn btn-<?= ($row->comment_status == '0' ? 'danger disabled' : 'info'); ?> btn-sm" href="<?= 'http://'.$row->komentator_website; ?>" title="Lihat <?= $row->komentator_website; ?>"><?= $row->komentator_website; ?>&nbsp;<i class="fa fa-eye"></i>
													</a>
												<?php endif; ?>
												<p>
													<?= nl2br($row->comment_message);?>
												</p>

												<?php 
												$comment_id = $row->comment_id;
												$query = $this->db->query("SELECT * FROM tb_comment WHERE comment_status = '1' AND comment_parent = '$comment_id'");
												foreach ($query->result() as $key):
													?>
													<div class="media">
														<?php 
														$hash = md5( strtolower( trim( $key->comment_email ) ) );
														$link_foto = 'https://www.gravatar.com/avatar/'.$hash;
														?>
														<span class="pull-left">
															<img class="media-object img-circle img-responsive" src="<?= $link_foto; ?>?s=50&r=pg">
														</span>
														<div class="media-body">
															<h4 class="media-heading">
																<?= $key->comment_name; ?> <small><?= '< '.$key->comment_email.' >'; ?></small>
															</h4>														
															<span><?= date('d F Y H:i', strtotime($key->comment_date));?></span>
															<div class="clearfix"></div>
															<?php if ($key->comment_status == '1'): ?>
																<div class="col-md-offset-10 pull-right">
																	<a data-comment_id="<?= $key->comment_id; ?>" data-comment_post_id="<?= $key->comment_post_id; ?>" title="Balas" href="javascript:void(0)" class="btn btn-info btn-sm tombol-balas"><i class="fa fa-reply"></i></a>

																	<a data-comment_id="<?= $key->comment_id; ?>" data-comment_message="<?= $key->comment_message; ?>" data-nama_web="<?= $row->komentator_website; ?>" title="Edit" href="javascript:void(0)" class="btn btn-warning btn-sm tombol-edit"><i class="fa fa-pencil"></i></a>

																	<a title="Hapus" href="<?= site_url('admin/komentar/hapus/'.$key->comment_id); ?>" class="btn btn-danger btn-sm tombol-hapus"><i class="fa fa-trash"></i></a>
																	</div><?php else: ?>
																	<div class="col-md-offset-10 pull-right">
																		<p class="label label-danger">Komentar Butuh Moderasi <i class="fa fa-exclamation"></i></p>
																	</div>												
																<?php endif; ?>
																<?php if (!empty($key->komentator_website)): ?>
																	<a target="_blank" class="btn btn-info btn-sm" href="<?= 'http://'.$key->komentator_website; ?>" title="Lihat <?= $key->komentator_website; ?>"><?= $key->komentator_website; ?>&nbsp;<i class="fa fa-eye"></i></a>
																<?php endif; ?>
																<p>
																	<?= nl2br($key->comment_message);?>
																</p>

																<?php 
																$comment_id = $key->comment_id;
																$query2 = $this->db->query("SELECT * FROM tb_comment WHERE comment_status = '1' AND comment_parent = '$comment_id'");
																foreach ($query2->result() as $val):
																	?>
																	<div class="media">
																		<?php 
																		$hash = md5( strtolower( trim( $val->comment_email ) ) );
																		$link_foto = 'https://www.gravatar.com/avatar/'.$hash;
																		?>
																		<span class="pull-left">
																			<img class="media-object img-circle img-responsive" src="<?= $link_foto; ?>?s=50&r=pg">
																		</span>
																		<div class="media-body">
																			<h4 class="media-heading">
																				<?= $val->comment_name; ?> <small><?= '< '.$val->comment_email.' >'; ?></small>
																			</h4>																
																			<span><?= date('d F Y H:i', strtotime($val->comment_date));?></span>
																			<div class="clearfix"></div>
																			<?php if ($val->comment_status == '1'): ?>
																				<div class="col-md-offset-10 pull-right">
																					<span class="btn disabled"></span>

																					<a data-comment_id="<?= $val->comment_id; ?>" data-comment_message="<?= $val->comment_message; ?>" data-nama_web="<?= $row->komentator_website; ?>" title="Edit" href="javascript:void(0)" class="btn btn-warning btn-sm tombol-edit"><i class="fa fa-pencil"></i></a>

																					<a title="Hapus" href="<?= site_url('admin/komentar/hapus/'.$val->comment_id); ?>" class="btn btn-danger btn-sm tombol-hapus"><i class="fa fa-trash"></i></a>
																					</div><?php else: ?>
																					<div class="col-md-offset-10 pull-right">
																						<p class="label label-danger">Komentar Butuh Moderasi <i class="fa fa-exclamation"></i></p>
																					</div>												
																				<?php endif; ?>
																				<?php if (!empty($val->komentator_website)): ?>
																					<a target="_blank" class="btn btn-info btn-sm" href="<?= 'http://'.$val->komentator_website; ?>" title="Lihat <?= $val->komentator_website; ?>"><?= $val->komentator_website; ?>&nbsp;<i class="fa fa-eye"></i></a>
																				<?php endif; ?>
																				<p>
																					<?= nl2br($val->comment_message);?>
																				</p>
																			</div>
																		</div>
																	<?php endforeach ?>
																</div>
															</div>
														<?php endforeach ?>

													</div>
												</li>
											</ul>
										<?php endforeach; ?>

									</div>
									<?php if ($pagination): ?>
										<div class="panel-footer">
											<?= $pagination; ?>
										</div>							
									<?php endif ?>
								</div>
							</div>

						</div>

					</div>
				</div>

				<div class="modal fade" id="modalBalas" tabindex="-1" role="dialog" aria-labelledby="modalCategory" aria-hidden="true">
					<div class="modal-dialog">
						<div class="modal-content">
							<div class="modal-header">
								<button type="button" class="close" data-dismiss="modal" aria-label="Close">
									<span aria-hidden="true">&times;</span>
								</button>
								<h4 class="modal-title">Balas Komentar</h4>
							</div>
							<form method="post" action="<?=site_url('admin/komentar/balas')?>">
								<div class="modal-body">
									<div class="form-group">
										<input type="text" name="web" class="form-control" placeholder="Nama Website">
									</div>
									<div class="form-group">
										<textarea name="contents" required class="form-control" autofocus></textarea>
									</div>
								</div>
								<div class="modal-footer">
									<input type="hidden" name="comment_id" required>
									<input type="hidden" name="comment_post_id" required>
									<button type="submit" class="btn btn-primary"><i class="fa fa-fw fa-save"></i> Simpan</button>
									<button type="button" class="btn btn-secondary" data-dismiss="modal">Tutup <i class="fa fa-fw fa-remove"></i></button>
								</div>
							</form>
						</div>
					</div>
				</div>

				<div class="modal fade" id="modalEdit" tabindex="-1" role="dialog" aria-labelledby="modalCategory" aria-hidden="true">
					<div class="modal-dialog">
						<div class="modal-content">
							<div class="modal-header">
								<button type="button" class="close" data-dismiss="modal" aria-label="Close">
									<span aria-hidden="true">&times;</span>
								</button>
								<h4 class="modal-title">Edit Komentar</h4>
							</div>
							<form method="post" action="<?=site_url('admin/komentar/edit')?>">
								<div class="modal-body">
									<div class="form-group">
										<input type="text" name="web" class="form-control nama_web" placeholder="Nama Website">
									</div>
									<div class="form-group">
										<textarea name="contents" required class="form-control komentar" autofocus></textarea>
									</div>
								</div>
								<div class="modal-footer">
									<input type="hidden" name="comment_id" required>
									<button type="submit" class="btn btn-primary"><i class="fa fa-fw fa-save"></i> Simpan</button>
									<button type="button" class="btn btn-secondary" data-dismiss="modal">Tutup <i class="fa fa-fw fa-remove"></i></button>
								</div>
							</form>
						</div>
					</div>
				</div>

				<script type="text/javascript">
					$(document).ready(function() {
						$('.tombol-balas').on('click', function() {
							var co_id = $(this).data('comment_id');
							var co_pid = $(this).data('comment_post_id');
							$('#modalBalas').modal('show');
							$('[name="comment_id"]').val(co_id);
							$('[name="comment_post_id"]').val(co_pid);
						});

						$('.tombol-edit').on('click', function() {
							var co_id = $(this).data('comment_id');
							var isi = $(this).data('comment_message');
							var web = $(this).data('nama_web');
							$('#modalEdit').modal('show');
							$('[name="comment_id"]').val(co_id);
							$('.komentar').val(isi);
							$('.nama_web').val(web);
						});
					});
				</script>