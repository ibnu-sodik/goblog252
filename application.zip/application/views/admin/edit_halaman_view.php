<?php 
$row = $data->row_array();
?>
<div class="row">
	<div class="col-md-12">
		<h6 class="page-head-line">
		<a href="<?= $link_kembali; ?>" class="btn btn-default"><i class="fa fa-arrow-left"></i></a>
			&nbsp;Edit Halaman</h6>
		<form method="POST" enctype="multipart/form-data" action="<?= site_url('admin/halaman/update/'.$row['id_halaman']); ?>">

			<div class="col-md-8">

				<div class="form-group">
					<label for="nama_halaman">Judul</label>
					<input type="hidden" name="id_halaman" value="<?= $row['id_halaman'] ?>">
					<input type="text" id="nama_halaman" value="<?= $row['nama_halaman'] ?>" name="nama_halaman" placeholder="Judul" class="form-control judul" autofocus required>
				</div>
				<div class="form-group">
					<input type="text" value="<?= $row['slug_halaman'] ?>" name="slug" class="form-control slug btn-link" placeholder="Permalink" readonly>
				</div>
				<div class="form-group">
					<label for="contents">Konten</label>
					<textarea id="summernote" name="contents" cols="8" rows="8"><?= $row['konten_halaman'] ?></textarea>
				</div>

			</div>
			<div class="col-md-4">
				<hr>
				<button type="submit" class="btn btn-md btn-default btn-block">
					<i class="fa fa-fw fa-send"></i> Publish
				</button>
			</div>
			</form>
		</div>
	</div>
