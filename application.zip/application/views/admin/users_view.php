<link href="<?= base_url() ?>assets2/css/prettyPhoto.css" rel="stylesheet" />
<div class="row">
	<div class="col-md-12">
		<h2 class="page-head-line">Users</h2>

		<hr>
		<a href="#" class="btn btn-primary tombol-layang tombol-modal" data-target="#addModal" data-toggle="modal"><i class="fa fa-fw fa-plus fa-1x"></i></a>
		<div class="table-responsive">
			<table class="table table-hover table-striped" id="tabelku">
				<thead>
					<tr>
						<th class="text-center">No</th>
						<th class="text-center">Nama</th>
						<th class="text-center">Username</th>
						<th class="text-center">Email</th>
						<th class="text-center">Status</th>
						<th class="text-center">Foto</th>
						<th class="text-center">Opsi</th>
					</tr>
				</thead>
				<tbody>
					<?php 
					$no=0;
					foreach($users->result() as $row):
						$no++;
						?>
						<tr>
							<td class="text-center"><?= $no; ?></td>
							<td class="text-center"><?= $row->full_name; ?></td>
							<td class="text-center"><?= $row->username; ?></td>
							<td class="text-center"><?= $row->email; ?></td>

							<?php if($row->status == '1'): ?>
								<td class="text-center"><a title="Kunci" href="<?= site_url('admin/users/lock/'.$row->id) ?>"> <i class="fa fa-fw fa-unlock-alt"></i></a></td>
								<?php else: ?>
									<td class="text-center"><a title="Kunci" href="<?= site_url('admin/users/unlock/'.$row->id) ?>"> <i class="fa fa-fw fa-lock"></i></a></td>
								<?php endif; ?>
								<td class="text-center">
									<div class="overlay">
										<a class="preview" title="<?= $row->full_name; ?>" href="<?= base_url('uploads/thumbs/admin/'.$row->foto); ?>">
											<img class="img-thumbnail img-responsive gambar-mini" src="<?= base_url('uploads/thumbs/admin/'.$row->foto); ?>">
										</a>
									</div>
								</td>
								<td class="text-center">
									<a href="<?= site_url('admin/users/edit/'.$row->id); ?>" title="Edit" class="btn btn-sm btn-warning edit-sosmed"><i class="fa fa-pencil"></i></a>

									<a title="Hapus" href="<?=site_url('admin/users/delete/'.$row->id); ?>" class="btn btn-sm btn-danger tombol-hapus"><i class="fa fa-trash"></i></a>
								</td>
							</tr>
						<?php endforeach; ?>
					</tbody>
				</table>
			</div>
		</div>
	</div>

	<div class="modal fade" id="addModal" tabindex="-1" role="dialog" aria-labelledby="modalCategory" aria-hidden="true">
		<div class="modal-dialog">
			<div class="modal-content modal-lg">
				<div class="modal-header">
					<button type="button" class="close" data-dismiss="modal" aria-label="Close">
						<span aria-hidden="true">&times;</span>
					</button>
					<h4 class="modal-title">Tambah User</h4>
				</div>
				<form method="post" enctype="multipart/form-data" action="<?=site_url('admin/users/save')?>">
					<div class="modal-body">
						<div class="row">
							<div class="col-md-3">
								<input type="file" name="filefoto" class="dropify" required>
							</div>
							<div class="col-md-9">

								<div class="form-group">
									<label for="full_name">Nama</label>
									<input type="text" name="full_name" id="full_name" required placeholder="Nama" class="form-control" autofocus>
								</div>
								<div class="form-group">
									<label for="username">Username</label>
									<input type="text" name="username" id="username" required placeholder="Username" class="form-control">
								</div>
								<div class="form-group">
									<label for="email">Email</label>
									<input type="email" name="email" id="email" required placeholder="Email" class="form-control">
								</div>
								<div class="form-group">
									<label for="password">Password</label>
									<input type="password" name="password" id="password" required placeholder="Password" class="form-control">
								</div>

							</div>
						</div>
					</div>
					<div class="modal-footer">
						<button type="submit" class="btn btn-primary"><i class="fa fa-fw fa-save"></i> Simpan</button>
						<button type="button" class="btn btn-secondary" data-dismiss="modal">Tutup <i class="fa fa-fw fa-remove"></i></button>
					</div>
				</form>
			</div>
		</div>
	</div>
	<script src="<?= base_url() ?>assets2/js/jquery.prettyPhoto.js"></script>
	<script src="<?= base_url() ?>assets2/js/jquery.mixitup.min.js"></script>
	<script src="<?= base_url() ?>assets2/js/galleryCustom.js"></script>