<div class="row">
	<div class="col-md-12">
		<h6 class="page-head-line">
		<a href="<?= $link_kembali; ?>" class="btn btn-default"><i class="fa fa-arrow-left"></i></a>
			&nbsp;Tambah Artikel</h6>
		<form method="POST" enctype="multipart/form-data" action="<?= site_url('admin/post/publish') ?>">

			<div class="col-md-8">

				<div class="form-group">
					<label for="title">Judul</label>
					<input type="text" id="title" name="title" placeholder="Judul" class="form-control judul" autofocus required>
				</div>
				<div class="form-group">
					<input type="text" name="slug" class="form-control slug btn-link" placeholder="Permalink" readonly>
				</div>
				<div class="form-group">
					<label for="contents">Konten</label>
					<textarea id="summernote" name="contents" cols="8" rows="8"></textarea>
				</div>

			</div>

			<div class="col-md-4">

				<div class="form-group">
					<label for="image">Gambar</label>
					<input type="file" name="filefoto" id="image" class="dropify" data-height="190" required />
				</div>
				<div class="form-group">
					<label for="category">Kategori</label>
					<select name="category" class="form-control" id="category" required>
						<option value="">-----Pilih Kategori-----</option>
						<?php foreach ($category->result() as $row): ?>
							<option value="<?= $row->category_id; ?>"><?= $row->category_name; ?></option>
						<?php endforeach ?>
					</select>
				</div>
				<div class="form-group">
					<label for="tags">Tag</label>
					<div style="overflow-y: scroll;height: 150px;margin-bottom: 30px;">
						<?php foreach($tag->result() as $row): ?>
							<div class="form-group checkbox">
								<label>
									<input type="checkbox" name="tag[]" value="<?= $row->tag_slug; ?>"> <?= $row->tag_name; ?>
								</label>
							</div>
						<?php endforeach; ?>
					</div>
				</div>
				<button type="submit" class="btn btn-md btn-default btn-block">
					<i class="fa fa-fw fa-send"></i> Publish
				</button>
				<hr>
				<div class="form-group">
					<label for="meta-description">Deskripsi Meta</label>
					<textarea cols="6" rows="6" class="form-control" placeholder="Deskripsi Meta" id="meta-description" name="description"></textarea>
				</div>

			</div>
		</form>
	</div>
</div>
