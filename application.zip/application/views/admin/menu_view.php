<div class="row">
	<div class="col-md-12">

		<h2 class="page-head-line">Menu Settings</h2>

		<ul class="nav nav-tabs">
			<li class="active">
				<a href="#main" data-toggle="tab">Main Menu</a>
			</li>
			<li class="">
				<a href="#second" data-toggle="tab">Second Menu</a>
			</li>
		</ul>

		<div class="tab-content">
			<div class="tab-pane fade active in" id="main">

				<?php if ($main_menu->num_rows() == 0): ?>
					<div class="clearfix"><hr></div>
					<div class="col-md-4 col-md-offset-4">
						<div class="alert alert-info text-center">
							<h4> PERHATIAN</h4> 
							<hr />
							<i class="fa fa-warning fa-4x"></i>
							<p>
								Belum Ada Menu Jenis Main Menu <br>
								Silahkan Menambahkan Menu dengan Klik Tombol Dibawah
							</p>
							<hr />
							<a href="<?=site_url('admin/menu/add_main');?>" class="btn btn-info">Tambah Menu</a> 
						</div>
					</div>
					<?php else: ?>
						<a href="<?=site_url('admin/menu/add_main');?>" class="tombol-layang btn btn-primary"><i class="fa fa-fw fa-plus fa-1x"></i></a>
						<?php foreach ($main_menu->result() as $row): ?>
							<div class="row">
								<div class="col-md-8" style="margin-top: 10px;">

									<div class="input-group">
										<button class="btn btn-primary btn-block"><?= strtoupper($row->judul); ?></button>
										<div class="input-group-btn">									
											<button data-toggle="dropdown" class="btn btn-primary dropdown-toggle"><span class="caret"></span></button>
											<ul class="dropdown-menu">
												<li><a href="<?= site_url('admin/menu/edit_main/'.$row->id_menu); ?>">Edit</a></li>
												<li><a href="<?= site_url('admin/menu/delete/'.$row->id_menu); ?>">Delete</a></li>
											</ul>
										</div>
									</div>
								</div>
							</div>
							<?php 
							$id_menu = $row->id_menu;
							$query = $this->db->query("SELECT * FROM tb_menu WHERE parent_id = '$id_menu' ORDER BY urut");
							foreach($query->result() as $sub):
								?>
								<div class="row">
									<div class="col-md-7 col-md-offset-1 col-sm-offset-1" style="margin-top: 10px;">

										<div class="input-group">
											<button class="btn btn-info btn-block"><?= strtoupper($sub->judul); ?></button>
											<div class="input-group-btn">									
												<button data-toggle="dropdown" class="btn btn-info dropdown-toggle"><span class="caret"></span></button>
												<ul class="dropdown-menu">
													<li><a href="<?= site_url('admin/menu/edit_main/'.$sub->id_menu); ?>">Edit</a></li>
													<li><a href="<?= site_url('admin/menu/delete/'.$sub->id_menu); ?>">Delete</a></li>
												</ul>
											</div>
										</div>
									</div>
								</div>
							<?php endforeach; ?>
						<?php endforeach; ?>
					<?php endif; ?>
				</div>

				<div class="tab-pane fade" id="second">
					<?php if($second_menu->num_rows() == 0): ?>
						<div class="clearfix"><hr></div>
						<div class="col-md-4 col-md-offset-4">
							<div class="alert alert-info text-center">
								<h4> PERHATIAN</h4> 
								<hr />
								<i class="fa fa-warning fa-4x"></i>
								<p>
									Belum Ada Menu Jenis Secondary Menu <br>
									Silahkan Menambahkan Menu dengan Klik Tombol Dibawah
								</p>
								<hr />
								<a href="<?=site_url('admin/menu/add_second');?>" class="btn btn-info">Tambah Menu</a> 
							</div>
						</div>
						<?php else: ?>
							<a href="<?=site_url('admin/menu/add_second');?>" class="tombol-layang btn btn-primary"><i class="fa fa-fw fa-plus fa-1x"></i></a>
							<?php foreach ($second_menu->result() as $row): ?>
								<div class="row">
									<div class="col-md-8" style="margin-top: 10px;">

										<div class="input-group">
											<button class="btn btn-primary btn-block"><?= strtoupper($row->judul); ?></button>
											<div class="input-group-btn">									
												<button data-toggle="dropdown" class="btn btn-primary dropdown-toggle"><span class="caret"></span></button>
												<ul class="dropdown-menu">
													<li><a href="<?= site_url('admin/menu/edit_second/'.$row->id_menu); ?>">Edit</a></li>
													<li><a href="<?= site_url('admin/menu/delete/'.$row->id_menu); ?>">Delete</a></li>
												</ul>
											</div>
										</div>
									</div>
								</div>
							<?php endforeach; ?>
						<?php endif; ?>
					</div>
				</div>

			</div>
		</div>
