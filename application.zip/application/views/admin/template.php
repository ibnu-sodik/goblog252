<?php 
if ($this->session->userdata('logged_in') != TRUE) {
	$url = base_url('admin');
	redirect($url);
}
?>
<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
	<meta charset="utf-8" />
	<meta name="viewport" content="width=device-width, initial-scale=1.0" />
	<?php if(isset($title)): ?>
		<title><?=$title?> | <?= $site_title; ?> Admin Panel</title>
		<?php else: ?>
			<title><?= $site_title; ?></title>
		<?php endif; ?>
		<meta name="keywords" content="<?= $site_keywords; ?>">
		<meta name="description" content="<?= $site_description; ?>">
		<meta name="author" content="<?= $site_author; ?>">
		<link rel="shortcut icon" href="<?= base_url('assets/images/'.$site_favicon) ?>" type="image/x-icon" />

		<link href="<?= base_url() ?>assets2/css/bootstrap.css" rel="stylesheet" />
		<link href="<?= base_url() ?>assets2/css/font-awesome.css" rel="stylesheet" />
		<link href="<?= base_url() ?>assets2/css/basic.css" rel="stylesheet" />
		<link href="<?= base_url() ?>assets2/css/dataTable.min.css" rel="stylesheet" />
		<link href="<?= base_url() ?>assets2/css/dropify.min.css" rel="stylesheet" />
		<link href="<?= base_url() ?>assets2/css/jquery.toast.min.css" rel="stylesheet" />
		<link href="<?= base_url() ?>assets2/summernote/summernote.css" rel="stylesheet" />
		<link href="<?= base_url() ?>assets2/css/custom.css" rel="stylesheet" />
		<link href="<?= base_url() ?>assets2/css/prism.css" rel="stylesheet" />
		<link href='http://fonts.googleapis.com/css?family=Open+Sans' rel='stylesheet' type='text/css' />

		<script src="<?= base_url() ?>assets2/js/jquery-1.10.2.js"></script>
		<script src="<?=base_url()?>assets2/js/sweetalert.min.js"></script>
		<script src="<?= base_url() ?>assets2/js/highchart/highchart.js"></script>
		<script src="https://code.highcharts.com/highcharts-more.js"></script>
		<script src="https://code.highcharts.com/modules/dumbbell.js"></script>
		<script src="https://code.highcharts.com/modules/lollipop.js"></script>
		<script src="<?= base_url() ?>assets2/js/highchart/exporting.js"></script>
		<script src="<?= base_url() ?>assets2/js/highchart/export-data.js"></script>
		<script src="<?= base_url() ?>assets2/js/highchart/accessibility.js"></script>

	</head>
	<body>
		<div id="wrapper">
			<nav class="navbar navbar-default navbar-cls-top " role="navigation" style="margin-bottom: 0">
				<div class="navbar-header">
					<button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".sidebar-collapse">
						<span class="sr-only">Toggle navigation</span>
						<span class="icon-bar"></span>
						<span class="icon-bar"></span>
						<span class="icon-bar"></span>
					</button>
					<a class="navbar-brand" href="<?=base_url('admin')?>"><?=$site_name;?></a>
				</div>
				<div class="header-right">
					<a target="_blank" href="<?= base_url(); ?>" class="btn btn-default" title="Lihat Website"><i class="fa fa-eye fa-1x"></i></a>

					<a href="message-task.html" class="btn btn-info" title="Pesan Baru"><b>30 </b><i class="fa fa-inbox fa-1x"></i></a>

					<a href="<?= site_url('admin/profil'); ?>" class="btn btn-primary" title="Profil"><?= $this->session->userdata('full_name'); ?> <i class="fa fa-user fa-1x"></i></a>

					<a href="<?= site_url('admin/logout') ?>" class="btn btn-danger" title="Logout"><i class="fa fa-exclamation-circle fa-1x"></i></a>

				</div>
			</nav>
			<!-- /. NAV TOP  -->
			<nav class="navbar-default navbar-side" role="navigation">
				<div class="sidebar-collapse">
					<ul class="nav" id="main-menu">
						<li>
							<div class="user-img-div">
								<?php
								$user_id = $this->session->userdata('id');
								$query = $this->db->get_where('tb_user', array('id' => $user_id));
								$row = $query->row_array();
								$file = file_exists(base_url('./uploads/thumbs/admin/'.$row['foto']));
								if (!$file && !empty($row['foto'])):
									?>
									<img src="<?= base_url('./uploads/thumbs/admin/'.$row["foto"]) ?>" class="img-thumbnail img-responsive" />
									<?php else: ?>
										<img src="<?= base_url('assets/images/'.$site_favicon) ?>" class="img-thumbnail img-responsive" />
									<?php endif; ?>
									<div class="inner-text">
										<?= $this->session->userdata('full_name'); ?>
										<br />
										<small>Terakhir Login : <?= waktu_berlalu($row['last_login']);?> </small>
									</div>
								</div>

							</li>


							<li>
								<a href="<?=site_url('admin/dashboard')?>"><i class="fa fa-dashboard "></i>Dashboard</a>
							</li>
							<li>
								<a href="#"><i class="fa fa-desktop "></i>Posting <span class="fa arrow"></span></a>
								<ul class="nav nav-second-level">
									<li>
										<a href="<?=site_url('admin/category')?>"><i class="fa fa-tag"></i>Kategori</a>
									</li>
									<li>
										<a href="<?=site_url('admin/halaman')?>"><i class="fa fa fa-file" aria-hidden="true"></i>Halaman</a>
									</li>
									<li>
										<a href="<?=site_url('admin/post')?>"><i class="fa fa-book"></i>Artikel</a>
									</li>
									<li>
										<a href="<?=site_url('admin/tag')?>"><i class="fa fa-tags"></i>Tag</a>
									</li>
								</ul>
							</li>

							<li>
								<a href="<?= site_url('admin/subscribe') ?>"><i class="fa fa-envelope"></i>Subscribers </a>

							</li>
							<li>
								<a href="<?= site_url('admin/pesan') ?>"><i class="fa fa-inbox"></i>Pesan</a>
							</li>
							<li>
								<a href="<?= site_url('admin/komentar') ?>"><i class="fa fa-comments"></i>Komentar</a>
							</li>
							<li>
								<a href="<?= site_url('admin/users') ?>"><i class="fa fa-users "></i>Users</a>
							</li>

							<li>
								<a href="#"><i class="fa fa-cogs "></i>Settings <span class="fa arrow"></span></a>
								<ul class="nav nav-second-level">
									<li>
										<a href="<?= site_url('admin/settings') ?>"><i class="fa fa-desktop"></i>Basic</a>
									</li>
									<li>
										<a href="<?= site_url('admin/menu') ?>"><i class="fa fa-bars"></i>Menu</a>
									</li>
								</ul>
							</li>

						</ul>

					</div>

				</nav>
				<!-- /. NAV SIDE  -->
				<div id="page-wrapper">
					<div id="page-inner">
						<div class="flash-data-admin" data-flashdata="<?= $this->session->flashdata('pesan'); ?>"></div>
						<div class="toast-admin" data-flashdata="<?= $this->session->flashdata('toast'); ?>"></div>
						<div class="toast-admin-error" data-flashdata="<?= $this->session->flashdata('toast_error'); ?>"></div>
						<?=$contents?>
					</div>
					<!-- /. PAGE INNER  -->
				</div>
				<!-- /. PAGE WRAPPER  -->
			</div>
			<!-- /. WRAPPER  -->

			<div id="footer-sec">
				&copy; <?=date('Y')?> <?=$site_name?> | powered by : <?=$site_author?>
			</div>

			<script src="<?= base_url() ?>assets2/js/jquery-ui.min.js"></script>
			<script src="<?= base_url() ?>assets2/js/bootstrap.js"></script>
			<script src="<?= base_url() ?>assets2/js/jquery.metisMenu.js"></script>
			<script src="<?= base_url() ?>assets2/js/jquery.dataTables.min.js"></script>
			<script src="<?= base_url() ?>assets2/js/dataTables.bootstrap.min.js"></script>
			<script src="<?= base_url() ?>assets2/summernote/summernote.js"></script>
			<script src="<?= base_url() ?>assets2/summernote/lang/summernote-id-ID.js"></script>
			<script src="<?= base_url() ?>assets2/js/dropify.min.js"></script>
			<script src="<?= base_url() ?>assets2/js/jquery.toast.min.js"></script>
			<script src="<?= base_url() ?>assets2/js/prism.js"></script>

			<script src="<?= base_url() ?>assets2/js/custom.js"></script>

		</body>
		</html>