<div class="row">
	<div class="col-md-12">

		<h1 class="page-head-line">Pelanggan</h1>
		<a href="#" class="btn btn-primary tombol-layang tombol-modal" data-toggle="modal" data-target="#addModal"><i class="fa fa-fw fa-plus fa-1x"></i></a>
		<div class="table-responsive">
			<table class="table table-hover table-striped" id="tabelku">
				<thead>
					<tr>
						<th class="text-center">No</th>
						<th class="text-center">Email</th>
						<th class="text-center">Berlangganan Pada</th>
						<th class="text-center">Status</th>
						<th class="text-center">Rating</th>
						<th class="text-center">Opsi</th>
					</tr>
				</thead>
				<tbody>
					<?php 
					$no=0;
					foreach ($subscribers->result() as $row):
						$no++;
						?>
						<tr>
							<td class="text-center"><?=$no?></td>
							<td class="text-left"><?=$row->subscribe_email;?></td>
							<td class="text-left"><?=tgl($row->subscribe_created_at);?></td>
							<td class="text-center">
								<?php if ($row->subscribe_status == 0): ?>
									<label class="label label-info">Pelanggan Baru</label>
									<?php else: ?>
										<label class="label label-success">Aktif</label>
									<?php endif; ?>
								</td>
								<td class="text-center">
									<?php if ($row->subscribe_rating != 0): ?>
										<a class="btn btn-default btn-xs" href="<?= site_url('admin/subscribe/decrease/'.$row->subscribe_id); ?>"><i class="fa fa-minus"></i></a>									
									<?php endif ?>
									&nbsp;<span><?= $row->subscribe_rating; ?></span>&nbsp;
									<a class="btn btn-default btn-xs" href="<?= site_url('admin/subscribe/increase/'.$row->subscribe_id); ?>"><i class="fa fa-plus"></i></a>
								</td>
								<td class="text-center">
									<?php if ($row->subscribe_status == 0): ?>
										<a href="<?= site_url('admin/subscribe/activate/'.$row->subscribe_id); ?>" class="btn btn-xs btn-success tombol-konfirmasi"><i class="fa fa-power-off" title="Aktifkan"></i></a>
									<?php endif ?>
									<a title="Hapus" href="<?=site_url('admin/subscribe/delete/'.$row->subscribe_id); ?>" class="btn btn-xs btn-danger tombol-hapus"><i class="fa fa-trash"></i></a>
								</td>
							</tr>
						<?php endforeach ?>
					</tbody>
				</table>
			</div>

		</div>
	</div>