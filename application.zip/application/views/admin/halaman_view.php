<div class="row">
	<div class="col-md-12">

		<h1 class="page-head-line">Halaman</h1>
		<a href="<?=site_url('admin/halaman/add');?>" class="tombol-layang btn btn-primary"><i class="fa fa-fw fa-plus fa-1x"></i></a>
		<div class="table-responsive">
			<table class="table table-hover table-striped" id="tabelku">
				<thead>
					<tr>
						<th class="text-center">No</th>
						<th class="text-center">Judul</th>
						<th class="text-center">Author</th>
						<th class="text-center">Opsi</th>
					</tr>
				</thead>
				<tbody>
					<?php 
					$no=0;
					foreach ($data->result() as $row):
						$no++;
						?>
						<tr>
							<td class="text-center"><?=$no?></td>
							<td class="text-center"><?=$row->nama_halaman;?></td>
							<td class="text-center"><?=$row->full_name;?></td>
							<td class="text-center">
								<a title="Edit" href="<?=site_url('admin/halaman/edit/'.$row->id_halaman); ?>" class="btn btn-sm btn-warning"><i class="fa fa-pencil"></i></a>
								<a title="Hapus" href="<?=site_url('admin/halaman/delete/'.$row->id_halaman); ?>" class="btn btn-sm btn-danger tombol-hapus"><i class="fa fa-trash"></i></a>
							</td>
						</tr>
					<?php endforeach ?>
				</tbody>
			</table>
		</div>

	</div>
</div>
