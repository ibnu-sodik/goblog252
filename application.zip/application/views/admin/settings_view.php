<div class="row">
	<div class="col-md-12">
		<h2 class="page-head-line">Basic Settings</h2>
		<ul class="nav nav-tabs">
			<li class="active"><a href="#websiteInformation" data-toggle="tab">Website Information</a>
			</li>
			<li class=""><a href="#websiteImage" data-toggle="tab">Website Image</a>
			</li>
			<li class=""><a href="#websiteSocialLinks" data-toggle="tab">Website Social Links</a>
			</li>
			<li class=""><a href="#websitePost" data-toggle="tab">Website Post</a>
			</li>
			<li class=""><a href="#websiteKontenKontak" data-toggle="tab">Konten Kontak</a>
			</li>
		</ul>

		<div class="tab-content">

			<div class="tab-pane fade active in" id="websiteInformation">
				<div class="col-md-6">
					<h3>Website Information</h3>
					<hr>
					<form method="POST" enctype="multipart/form-data" action="<?= base_url('admin/settings/update_info'); ?>">

						<div class="form-group">
							<label for="site_name">Site Name</label>
							<input type="text" name="site_name" id="site_name" placeholder="Site Name" class="form-control" value="<?= $site_name; ?>">
						</div>
						<div class="form-group">
							<label for="site_title">Site Title</label>
							<input type="text" name="site_title" id="site_title" placeholder="Site Title" class="form-control" value="<?= $site_title; ?>">
						</div>
						<div class="form-group">
							<label for="site_keywords">Site Keywords</label>
							<textarea name="site_keywords" id="site_keywords" placeholder="Site Keywords" class="form-control" rows="3"><?= $site_keywords; ?></textarea>
						</div>
						<div class="form-group">
							<label for="site_description">Site Description</label>
							<textarea name="site_description" id="site_description" placeholder="Site Description" class="form-control" rows="3"><?= $site_description; ?></textarea>
						</div>

						<div class="form-group">
							<input type="hidden" name="site_id" value="<?=$site_id;?>" required>
							<button type="submit" class="btn btn-info btn-block">Update <i class="fa fa-send"></i></button>
						</div>
					</form>
				</div>

			</div>

			<div class="tab-pane fade" id="websiteImage">
				<div class="col-md-6">
					<h3>Website Image</h3>
					<hr>
					<form method="POST" enctype="multipart/form-data" action="<?= base_url('admin/settings/update_img'); ?>">
						<div class="form-group">
							<label for="site_favicon">Favicon</label><br>
							<img class="img-thumbnail img-responsive" width="32" height="32" src="<?= base_url('assets/images/'.$site_favicon); ?>">

							<input class="form-control" type="file" name="site_favicon" id="site_favicon">
							<p class="help-block">Ukuran Gambar 32x32 px (Recommended)</p>
						</div>
						<div class="form-group">
							<label for="site_logo_header">Logo Header</label><br>
							<img style="background-color: #757575;" class="img-thumbnail img-responsive" src="<?= base_url('assets/images/'.$site_logo_header); ?>">

							<input class="form-control" type="file" name="site_logo_header" id="site_logo_header">
						</div>
						<div class="form-group">
							<label for="site_logo_footer">Logo Footer</label><br>
							<img style="background-color: #757575;" class="img-thumbnail img-responsive" src="<?= base_url('assets/images/'.$site_logo_footer); ?>">

							<input class="form-control" type="file" name="site_logo_footer" id="site_logo_footer">
						</div>
						<div class="form-group">
							<input type="hidden" name="site_id" value="<?=$site_id;?>" required>
							<button type="submit" class="btn btn-info btn-block">Update <i class="fa fa-send"></i></button>
						</div>
					</form>
				</div>
			</div>

			<div class="tab-pane fade" id="websiteSocialLinks">
				<div class="col-md-12">
					<h3>Website Social Links</h3>
					<hr>
					<a href="#" class="btn btn-primary tombol-layang tombol-modal" data-target="#addModal" data-toggle="modal"><i class="fa fa-fw fa-plus fa-1x"></i></a>
					<div class="table-responsive">
						<table class="table table-hover table-striped" id="tabelku">
							<thead>
								<tr>
									<th class="text-center">No</th>
									<th class="text-center">Nama Sosmed</th>
									<th class="text-center">URL</th>
									<th class="text-center">Icon</th>
									<th class="text-center">Opsi</th>
								</tr>
							</thead>
							<tbody>
								<?php 
								$no=0;
								foreach($sosmed_web->result() as $row):
									$no++;
									?>
									<tr>
										<td class="text-center"><?= $no; ?></td>
										<td class="text-center"><?= $row->sosmed_name; ?></td>
										<td class="text-center">
											<a href="<?= $row->sosmed_url; ?>" class="btn btn-primary" target="_blank"><?= $row->sosmed_name; ?> <i class="fa fa-eye"></i></a>
										</td>
										<td class="text-center"><i class="fa fa-<?= $row->sosmed_icon; ?>"></i></td>
										<td class="text-center">
											<a href="javascript:void(0);" title="Edit" data-id="<?=$row->sosmed_id; ?>" 
												data-sosmed="<?=$row->sosmed_name; ?>" 
												data-url="<?=$row->sosmed_url; ?>" 
												data-icon="<?=$row->sosmed_icon; ?>" 
												data-own="<?=$row->own_sosmed_id; ?>" 
												class="btn btn-sm btn-warning edit-sosmed"><i class="fa fa-pencil"></i></a>

												<a title="Hapus" href="<?=site_url('admin/settings/delete/'.$row->sosmed_id); ?>" class="btn btn-sm btn-danger tombol-hapus"><i class="fa fa-trash"></i></a>
											</td>
										</tr>
									<?php endforeach; ?>
								</tbody>
							</table>
						</div>
					</div>

					<!-- modal add -->
					<div class="modal fade" id="addModal" tabindex="-1" role="dialog" aria-labelledby="modalSosmed" aria-hidden="true">
						<div class="modal-dialog">
							<div class="modal-content">
								<div class="modal-header">					
									<button type="button" class="close" data-dismiss="modal" aria-label="Close">
										<span aria-hidden="true">&times;</span>
									</button>
									<h4 class="modal-title">Tambah Sosmed</h4>
								</div>
								<form method="post" action="<?= base_url('admin/settings/add_sosmed'); ?>">

									<div class="modal-body">
										<div class="form-group">
											<label for="site_id">Pilih Website</label>
											<select name="site_id" id="site_id" class="form-control" required>
												<option value="">-----Pilih Website-----</option>
												<?php foreach ($pilih_web->result() as $row): ?>
													<option value="<?= $row->site_id; ?>"><?= $row->site_name; ?></option>
												<?php endforeach ?>
											</select>
										</div>
										<div class="form-group">
											<label for="sosmed_name">Nama Sosmed</label>
											<input type="text" name="sosmed_name" id="sosmed_name" class="form-control" required placeholder="Nama Sosmed">
										</div>
										<div class="form-group">
											<label for="sosmed_url">Url Sosmed</label>
											<input type="text" name="sosmed_url" id="sosmed_url" class="form-control" placeholder="Url Sosmed" />
										</div>
										<div class="form-group">
											<label for="sosmed_icon">Icon Sosmed</label>
											<div class="input-group">
												<span class="form-group input-group-btn">
													<button class="btn btn-default disabled" type="button">fa fa-</button>
												</span>
												<input type="text" name="sosmed_icon" id="sosmed_icon" class="form-control" placeholder="Icon Sosmed" />
											</div>
										</div>

									</div>
									<div class="modal-footer">
										<button type="submit" class="btn btn-primary"><i class="fa fa-fw fa-save"></i> Simpan</button>
										<button type="button" class="btn btn-secondary" data-dismiss="modal">Tutup <i class="fa fa-fw fa-remove"></i></button>
									</div>

								</form>
							</div>
						</div>
					</div>

					<!-- modal edit -->
					<div class="modal fade" id="editModal" tabindex="-1" role="dialog" aria-labelledby="modalSosmed" aria-hidden="true">
						<div class="modal-dialog">
							<div class="modal-content">
								<div class="modal-header">					
									<button type="button" class="close" data-dismiss="modal" aria-label="Close">
										<span aria-hidden="true">&times;</span>
									</button>
									<h4 class="modal-title">Edit Sosmed</h4>
								</div>
								<form method="post" action="<?= base_url('admin/settings/edit_sosmed'); ?>">

									<div class="modal-body">
										<div class="form-group">
											<label for="sosmed_name2">Nama Sosmed</label>
											<input type="text" name="sosmed_name2" id="sosmed_name2" class="form-control" required placeholder="Nama Sosmed">
										</div>
										<div class="form-group">
											<label for="sosmed_url2">Url Sosmed</label>
											<input type="text" name="sosmed_url2" id="sosmed_url2" class="form-control" placeholder="Url Sosmed" />
										</div>
										<div class="form-group">
											<label for="sosmed_icon2">Icon Sosmed</label>
											<div class="input-group">
												<span class="form-group input-group-btn">
													<button class="btn btn-default disabled" type="button">fa fa-</button>
												</span>
												<input type="text" name="sosmed_icon2" id="sosmed_icon2" class="form-control" placeholder="Icon Sosmed" />
											</div>
										</div>

									</div>
									<div class="modal-footer">
										<input type="hidden" name="sosmed_id">
										<input type="hidden" name="site_id">
										<button type="submit" class="btn btn-primary"><i class="fa fa-fw fa-save"></i> Simpan</button>
										<button type="button" class="btn btn-secondary" data-dismiss="modal">Tutup <i class="fa fa-fw fa-remove"></i></button>
									</div>

								</form>
							</div>
						</div>
					</div>
				</div>

				<div class="tab-pane fade" id="websitePost">
					<div class="col-md-12">
						<form action="<?=site_url('admin/settings/update_limit')?>" method="post">
							<div class="row">
								<div class="form-group col-md-2">
									<label for="limit_post">Limit Post : </label>
									<select name="limit_post" id="limit_post" class="form-control">
										<?php for ($i=1; $i <=20 ; $i++): ?>
											<?php if ($limit_post == $i): ?>
												<option value="<?= $i; ?>" selected><?= $i; ?></option><?php else: ?>
												<option value="<?= $i; ?>"><?= $i; ?></option>
											<?php endif; ?>
										<?php endfor; ?>
									</select>
								</div>
								<div class="form-group col-md-2">
									<label for="limit_latest_post">Limit Latest Post : </label>
									<select name="limit_latest_post" id="limit_latest_post" class="form-control">
										<?php for ($i=1; $i <=20 ; $i++): ?>
											<?php if ($limit_latest_post == $i): ?>
												<option value="<?= $i; ?>" selected><?= $i; ?></option><?php else: ?>
												<option value="<?= $i; ?>"><?= $i; ?></option>
											<?php endif; ?>
										<?php endfor; ?>
									</select>
								</div>
								<div class="form-group col-md-2">
									<label for="limit_recent_views">Limit Recent Views : </label>
									<select name="limit_recent_views" id="limit_recent_views" class="form-control">
										<?php for ($i=1; $i <=20 ; $i++): ?>
											<?php if ($limit_recent_views == $i): ?>
												<option value="<?= $i; ?>" selected><?= $i; ?></option><?php else: ?>
												<option value="<?= $i; ?>"><?= $i; ?></option>
											<?php endif; ?>
										<?php endfor; ?>
									</select>
								</div>
								<div class="form-group col-md-2">
									<label for="limit_popular_post">Limit Popular Post : </label>
									<select name="limit_popular_post" id="limit_popular_post" class="form-control">
										<?php for ($i=1; $i <=20 ; $i++): ?>
											<?php if ($limit_popular_post == $i): ?>
												<option value="<?= $i; ?>" selected><?= $i; ?></option><?php else: ?>
												<option value="<?= $i; ?>"><?= $i; ?></option>
											<?php endif; ?>
										<?php endfor; ?>
									</select>
								</div>
								<div class="form-group col-md-3">
									<label></label>
									<input type="hidden" name="site_id" value="<?=$site_id;?>" required>
									<button type="submit" class="btn btn-secondary btn-block"><i class="fa fa-send"></i> Simpan</button>
								</div>
							</div>
						</form>
					</div>
				</div>

				<!-- Konten Kontak -->
				<div class="tab-pane fade" id="websiteKontenKontak">
					<div class="col-md-7">
						<form  enctype="multipart/form-data"  method="POST" action="<?= site_url('admin/settings/update_contact_page'); ?>">

							<div class="form-group">
								<label for="contents">Konten Halaman Kontak</label>
								<textarea required id="summernote" name="contents" cols="8" rows="8"><?= $konten_kontak; ?></textarea>
							</div>
							<div class="form-group">
								<input type="hidden" name="site_id" value="<?=$site_id;?>" required>
								<button type="submit" class="btn btn-md btn-default btn-block">
									<i class="fa fa-fw fa-send"></i> Publish
								</div>
							</form>
						</div>
					</div>

				</div>

			</div>
		</div>