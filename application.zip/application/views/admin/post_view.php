<div class="row">
	<div class="col-md-12">

		<h1 class="page-head-line">Artikel</h1>
		<a href="<?=site_url('admin/post/add');?>" class="tombol-layang btn btn-primary"><i class="fa fa-fw fa-plus fa-1x"></i></a>

		<ul class="nav nav-tabs">
			<li class="active" role="presentation">
				<a href="#publish" data-toggle="tab">Publish</a>
			</li>
			<li role="presentation">
				<a href="<?= site_url('admin/post/draft') ?>"><span class="badge badge-pill badge-info"><?= $jumlah_draft; ?></span> Draft</a>
			</li>
		</ul>

		<div class="tab-content">
			<div class="tab-pane active fade in" id="publish">
				<hr>
				<div class="table-responsive">
					<table class="table table-hover table-striped" id="tabelku">
						<thead>
							<tr>
								<th class="text-center">No</th>
								<th class="text-center">Judul</th>
								<th class="text-center">Link</th>
								<th class="text-center">Tanggal Post</th>
								<th class="text-center">Kategori</th>
								<th class="text-center">Dilihat</th>
								<th class="text-center">Opsi</th>
							</tr>
						</thead>
						<tbody>
							<?php 
							$no=0;
							foreach ($data->result() as $row):
								$no++;
								?>
								<tr>
									<td class="text-center"><?=$no?></td>
									<td>
									    <?=$row->post_title;?><br/>
									    <label id="link" class="label label-info"><?= base_url('blog/'.$row->post_slug);?></label>
									</td>
								    <td class="text-center"><button class="btn btn-sm btn-info" onclick="copyToClipboard('#link')">Copy Link</button></td>
									<td class="text-center"><?=$row->post_date;?></td>
									<td class="text-center"><?=$row->category_name;?></td>
									<td class="text-center"><?=$row->post_views;?></td>
									<td class="text-center">
										<a title="Draft" href="<?=site_url('admin/post/unpost/'.$row->post_id); ?>" class="btn btn-sm btn-info"><i class="fa fa-download"></i></a>
										<a title="Hapus" href="<?=site_url('admin/post/delete/'.$row->post_id); ?>" class="btn btn-sm btn-danger tombol-hapus"><i class="fa fa-trash"></i></a>
									</td>
								</tr>
							<?php endforeach ?>
						</tbody>
					</table>
				</div>
			</div>
		</div>


	</div>
</div>
<script>
    function copyToClipboard(element){
        var $temp = $("<label>");
        $("body").append($temp);
        $temp.val($(element).text()).select();
        document.execCommand("copy");
        $temp.remove();
    }
</script>
