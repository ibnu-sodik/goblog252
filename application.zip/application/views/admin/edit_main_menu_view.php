<?php 
$row = $data->row_array();
?>
<div class="row">
	<div class="col-md-12">
		<h6 class="page-head-line">
		<a href="<?= $link_kembali; ?>" class="btn btn-default"><i class="fa fa-arrow-left"></i></a>
		&nbsp;Edit Main Menu</h6>
		<div class="col-md-6">
			<form method="post" action="<?= $form_location; ?>">
				<input type="hidden" name="kategori_menu" value="main">
				<div class="form-group">
					<label for="judul">Judul</label>
					<input type="text" name="judul" id="judul" class="form-control" placeholder="Judul" required value="<?= $row['judul'] ?>">
				</div>
				<div class="form-group">
					<label for="induk">Induk Menu</label>
					<select name="induk" id="induk" class="form-control">
						<option value="0">--- Tidak Berinduk ---</option>
						<?php foreach ($data_opt->result() as $val): ?>
							<?php if ($row['parent_id'] == $val->id_menu): ?>
								<option value="<?=$val->id_menu;?>" selected><?= $val->judul; ?></option>
								<?php else: ?>
									<option value="<?=$val->id_menu;?>"><?= $val->judul; ?></option>
								<?php endif; ?>
							<?php endforeach ?>
						</select>
					</div>
					<div class="form-group" id="jenis_link">
						<label for="jenis_link">Jenis Link</label>
						<select name="jenis_link" class="form-control">
							<?php
							$variable = array(
								'halaman' => 'Halaman',
								'kategori' => 'Kategori',
								'url' => 'URL',
							);
							foreach ($variable as $key => $value): ?>
								<?php if ($row['jenis_link'] == $key): ?>
									<option value="<?= $key; ?>" selected><?= $value; ?></option>
									<?php else: ?>
										<option value="<?= $key; ?>"><?= $value; ?></option>
									<?php endif; ?>
								<?php endforeach ?>
							</select>
						</div>
						<div class="form-group" id="link_halaman">
							<label for="link_halaman">Link Halaman</label>
							<select name="link_halaman" class="form-control">
								<option value="">--- Pilih Halaman ---</option>
								<?php foreach ($halaman->result() as $val): ?>
									<?php
									$hal = str_replace("pages/", "", $row['link']);
									if ($hal == $val->slug_halaman): ?>
										<option value="<?= $val->slug_halaman; ?>" selected><?= $val->nama_halaman; ?></option>
										<?php else: ?>
											<option value="<?= $val->slug_halaman; ?>"><?= $val->nama_halaman; ?></option>
										<?php endif; ?>
									<?php endforeach; ?>
								</select>
							</div>
							<div class="form-group" id="link_kategori">
								<label for="link_kategori">Link Kategori</label>
								<select name="link_kategori" class="form-control">
									<option value="">--- Pilih Kategori ---</option>
									<?php foreach ($kategori->result() as $val): ?>
										<?php 
										$cat = str_replace("category/", "", $row['link']);
										if ($cat == $val->category_slug): ?>
											<option value="<?= $val->category_slug; ?>" selected><?= $val->category_name; ?></option>
											<?php else: ?>
												<option value="<?= $val->category_slug; ?>"><?= $val->category_name; ?></option>
											<?php endif; ?>
										<?php endforeach ?>
									</select>
								</div>
								<div class="form-group" id="link_url">
									<label for="url">Link URL</label>
									<input type="text" name="link_url" class="form-control" placeholder="URL" value="<?= $row['link']; ?>">
								</div>
								<div class="form-group">
									<label for="urut">No Urut</label>
									<select name="urut" id="urut" class="form-control">
										<option value="">--- Urutan ---</option>
										<?php for ($i=1; $i <=20 ; $i++): ?>
											<?php if ($row['urut'] == $i): ?>
												<option value="<?= $i; ?>" selected><?= $i; ?></option>
												<?php else: ?>
													<option value="<?= $i; ?>"><?= $i; ?></option>
												<?php endif; ?>
											<?php endfor; ?>
										</select>
									</div>
									<div class="form-group">
										<button type="submit" class="btn btn-secondary btn-block"><i class="fa fa-send"></i> Simpan</button>
									</div>
								</form>
							</div>
						</div>
					</div>