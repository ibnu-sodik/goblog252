<div class="row">
	<div class="col-md-12">
		<h6 class="page-head-line">
			<a href="<?= $link_kembali; ?>" class="btn btn-default"><i class="fa fa-arrow-left"></i></a>
			&nbsp;Detail Pesan
		</h6>

		<ul class="media-list">
			<li class="media">
				<div class="media-heading">
					<span class="pull-right"><?= date('d F Y H:i', strtotime($tgl_kirim));?></span>
					<h3><?= $subjek_pesan; ?></h3>
				</div>
				<br>
				<?php 
				$hash = md5( strtolower( trim( $pesan_email ) ) );
				$link_foto = 'https://www.gravatar.com/avatar/'.$hash;
				?>
				<span class="pull-left">
					<img class="media-object img-circle img-responsive" src="<?= $link_foto; ?>?s=50&r=pg">
				</span>
				<div class="media-body">
					<h3 class="media-heading"><?= $pesan_dari; ?> <small><?= '< '.$pesan_email.' >'; ?></small></h3>
					<p>
						<?= nl2br($isi_pesan);?>
					</p>

					<?php if (isset($no_hp)): ?>
						<a target="_blank" class="btn btn-success" href="<?= $link_balas_wa; ?>" title="Balas Via WhatsApp"><i class="fa fa-reply"></i> &nbsp;Balas Via Whatsapp</a>
					<?php endif; ?>
				</div>
			</li>
		</ul>
		
	</div>
</div>