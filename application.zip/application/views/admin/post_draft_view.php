<div class="row">
	<div class="col-md-12">

		<h1 class="page-head-line">Artikel</h1>
		<a href="<?=site_url('admin/post/add');?>" class="tombol-layang btn btn-primary"><i class="fa fa-fw fa-plus fa-1x"></i></a>

		<ul class="nav nav-tabs">
			<li role="presentation">
				<a href="<?= site_url('admin/post') ?>" >Publish</a>
			</li>
			<li class="active" role="presentation">
				<a href="#draft" data-toggle="tab"><span class="badge badge-pill badge-info"><?= $jumlah_draft; ?></span> Draft</a>
			</li>
		</ul>

		<div class="tab-content">
			<div class="tab-pane active fade in" id="draft">
				<hr>
				<div class="table-responsive">
					<table class="table table-hover table-striped" id="tabelku">
						<thead>
							<tr>
								<th class="text-center">No</th>
								<th class="text-center">Judul</th>
								<th class="text-center">Tanggal Post</th>
								<th class="text-center">Kategori</th>
								<th class="text-center">Dilihat</th>
								<th class="text-center">Opsi</th>
							</tr>
						</thead>
						<tbody>
							<?php 
							$no=0;
							foreach ($data->result() as $row):
								$no++;
								?>
								<tr>
									<td class="text-center"><?=$no?></td>
									<td><?=$row->post_title;?></td>
									<td class="text-center"><?=$row->post_date;?></td>
									<td class="text-center"><?=$row->category_name;?></td>
									<td class="text-center"><?=$row->post_views;?></td>
									<td class="text-center">
										<a title="Posting" href="<?=site_url('preview/'.$row->post_slug); ?>" class="btn btn-sm btn-default"><i class="fa fa-eye"></i></a>
										<a title="Posting" href="<?=site_url('admin/post/posting/'.$row->post_id); ?>" class="btn btn-sm btn-info"><i class="fa fa-upload"></i></a>
										<a title="Edit" href="<?=site_url('admin/post/edit/'.$row->post_id); ?>" class="btn btn-sm btn-warning"><i class="fa fa-pencil"></i></a>
										<a title="Hapus" href="<?=site_url('admin/post/delete/'.$row->post_id); ?>" class="btn btn-sm btn-danger tombol-hapus"><i class="fa fa-trash"></i></a>
									</td>
								</tr>
							<?php endforeach ?>
						</tbody>
					</table>
				</div>
			</div>
		</div>


	</div>
</div>
