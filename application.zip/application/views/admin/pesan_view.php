<div class="row">
	<div class="col-md-12">

		<h2 class="page-head-line">Inbox</h2>
		<div class="table-responsive mailbox-content">
			<table class="table table-hover table-striped" id="tabelku">
				<thead>
					<tr>
						<th class="text-center">Opsi</th>
						<th>Pengirim</th>
						<th>Pesan</th>
					</tr>
				</thead>
				<tbody>
					<?php foreach($pesan->result() as $row): ?>
						<?php if($row->status_pesan == '0'): ?>
							<tr style="cursor: pointer;">
								<td class="text-center">
									<?php if($row->pesan_bintang == '0'): ?>
										<a href="<?= site_url('admin/pesan/star/'.$row->pesan_id); ?>" class="btn btn-default" title="Bintangi"><i class="fa fa-star-o"></i></a><?php else: ?>
										<a href="<?= site_url('admin/pesan/unstar/'.$row->pesan_id); ?>" class="btn btn-warning" title="Hapus Bintang"><i class="fa fa-star"></i></a>
									<?php endif; ?>
									<?php if($row->status_pesan == '0'): ?>
										<a href="<?= site_url('admin/pesan/read/'.$row->pesan_id); ?>" class="btn btn-default" title="Tandai Sudah Dibaca"><i class="fa fa-envelope"></i></a><?php else: ?>
										<a href="<?= site_url('admin/pesan/unread/'.$row->pesan_id); ?>" class="btn btn-default" title="Tandai Belum Dibaca"><i class="fa fa-envelope"></i></a>
									<?php endif; ?>
									<a title="Hapus" href="<?=site_url('admin/pesan/delete/'.$row->pesan_id); ?>" class="btn btn-default tombol-hapus"><i class="fa fa-trash-o"></i></a>
								</td>
								<td data-pesan_id = "<?= $row->pesan_id; ?>"><b><?= $row->pesan_dari; ?></b></td>
								<td data-pesan_id = "<?= $row->pesan_id; ?>"><b><?= $row->subjek_pesan; ?></b> - <?= batasi_kata(nl2br($row->isi_pesan), 5); ?> ...</td>
							</tr>
							<?php else: ?>
								<tr style="cursor: pointer;">
									<td class="text-center">								
										<?php if($row->pesan_bintang == '0'): ?>
											<a href="<?= site_url('admin/pesan/star/'.$row->pesan_id); ?>" class="btn btn-default" title="Bintangi"><i class="fa fa-star-o"></i></a><?php else: ?>
											<a href="<?= site_url('admin/pesan/unstar/'.$row->pesan_id); ?>" class="btn btn-warning" title="Hapus Bintang"><i class="fa fa-star"></i></a>
										<?php endif; ?>
										<?php if($row->status_pesan == '0'): ?>
											<a href="<?= site_url('admin/pesan/read/'.$row->pesan_id); ?>" class="btn btn-default" title="Tandai Sudah Dibaca"><i class="fa fa-envelope"></i></a><?php else: ?>
											<a href="<?= site_url('admin/pesan/unread/'.$row->pesan_id); ?>" class="btn btn-default" title="Tandai Belum Dibaca"><i class="fa fa-envelope-o"></i></a>
										<?php endif; ?>
										<a title="Hapus" href="<?=site_url('admin/pesan/delete/'.$row->pesan_id); ?>" class="btn btn-default tombol-hapus"><i class="fa fa-trash-o"></i></a>
									</td>
									<td data-pesan_id = "<?= $row->pesan_id; ?>"><?= $row->pesan_dari; ?></td>
									<td data-pesan_id = "<?= $row->pesan_id; ?>"><?= $row->subjek_pesan.' - '.batasi_kata(nl2br($row->isi_pesan), 5); ?> ...</td>
								</tr>
							<?php endif; ?>
						<?php endforeach; ?>
					</tbody>

				</table>
			</div>

		</div>
	</div>

	<script type="text/javascript">
		$(document).ready(function(){
			$('.mailbox-content table tr td').not(":first-child").on('click', function(e) {
				e.stopPropagation();
				e.preventDefault();
				var pesan_id=$(this).data('pesan_id');

				window.location = "<?php echo site_url('admin/pesan/detail/');?>"+pesan_id;
			});
		});
	</script>