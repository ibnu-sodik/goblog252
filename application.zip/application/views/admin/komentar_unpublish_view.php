<div class="row">
	<div class="col-md-12">

		<h2 class="page-head-line">Menu Settings</h2>
		<div class="col-md-4 col-md-offset-8">
			<form role="form" method="GET" action="<?= site_url('admin/komentar/hasil') ?>">
				<div class="input-group">
					<input type="text" name="cari" class="form-control" placeholder="Cari Komentar..." />
					<span class="form-group input-group-btn">
						<button type="submit" class="btn btn-info" type="button"><i class="fa fa-gear fa-spin"></i> Cari</button>
					</span>
				</div>				
			</form>
		</div>
		<div class="clearfix"></div>
		<hr>
		<ul class="nav nav-tabs">
			<li role="presentation">
				<a href="<?= site_url('admin/komentar') ?>" >Semua Komentar <span class="badge bg-default"><?= $jumlah_semua; ?></span></a>
			</li>
			<li  class="active" role="presentation">
				<a href="#unpublish" data-toggle="tab">Butuh Moderasi <span class="badge bg-info"><?= $jumlah_unpublish; ?></span></a>
			</li>
		</ul>

		<div class="tab-content">
			<div class="tab-pane fade active in" id="unpublish">
				<div class="panel panel-default">
					<div class="panel-body">
						<ul class="media-list">

							<?php foreach ($unpublish->result() as $row): ?>
								<ul class="media-list">
									<li class="media">
										<div class="media-heading">
											<h4><a href="<?= site_url('blog/'.$row->post_slug); ?>" target="_blank"><?= $row->post_title; ?></a></h4>
										</div>
										<br>
										<?php 
										$hash = md5( strtolower( trim( $row->comment_email ) ) );
										$link_foto = 'https://www.gravatar.com/avatar/'.$hash;
										?>
										<span class="pull-left">
											<img class="media-object img-circle img-responsive" src="<?= $link_foto; ?>?s=50&r=pg">
										</span>
										<div class="media-body">
											<h4 class="media-heading">
												<?= $row->comment_name; ?> <small><?= '< '.$row->comment_email.' >'; ?></small>
											</h4>
											<span><?= date('d F Y H:i', strtotime($row->comment_date));?></span>
											<div class="clearfix"></div>
											<div class="col-md-offset-10">
												<a title="Publish" href="<?= site_url('admin/komentar/publish/'.$row->comment_id) ?>" class="btn btn-info btn-sm tombol-publish"><i class="fa fa-send"></i></a>
												<a title="Hapus" href="<?= site_url('admin/komentar/hapus/'.$row->comment_id); ?>" class="btn btn-danger btn-sm tombol-hapus"><i class="fa fa-trash"></i></a>
											</div>
											<?php if (!empty($row->komentator_website)): ?>
												<a target="_blank" class="btn btn-<?= ($row->comment_status == '0' ? 'danger disabled' : 'info'); ?> btn-sm" href="<?= 'http://'.$row->komentator_website; ?>" title="Lihat <?= $row->komentator_website; ?>"><?= $row->komentator_website; ?>&nbsp;<i class="fa fa-eye"></i>
												</a>
											<?php endif; ?>

											<p>
												<?= nl2br($row->comment_message);?>
											</p>
										</div>
									</li>
								</ul>
							<?php endforeach; ?>

						</div>
						<?php if ($pagination): ?>
							<div class="panel-footer">
								<?= $pagination; ?>
							</div>							
						<?php endif ?>
					</div>
				</div>

			</div>

		</div>
	</div>