<div class="row">
	<div class="col-md-12">
		<h6 class="page-head-line">
			<a href="<?= $link_kembali; ?>" class="btn btn-default"><i class="fa fa-arrow-left"></i></a>
		&nbsp;Tambah Main Menu</h6>
		<div class="col-md-6">
			<form method="post" action="<?= $form_location; ?>">
				<input type="hidden" name="kategori_menu" value="main">
				<div class="form-group">
					<label for="judul">Judul</label>
					<input type="text" name="judul" id="judul" class="form-control" placeholder="Judul" required>
				</div>
				<div class="form-group">
					<label for="induk">Induk Menu</label>
					<select name="induk" id="induk" class="form-control">
						<option value="0">--- Tidak Berinduk ---</option>
						<?php foreach ($main_menu->result() as $row): ?>
							<option value="<?=$row->id_menu;?>"><?= $row->judul; ?></option>
						<?php endforeach ?>
					</select>
				</div>
				<div class="form-group" id="jenis_link">
					<label for="jenis_link">Jenis Link</label>
					<select name="jenis_link" class="form-control">
						<option value="halaman">Halaman</option>
						<option value="kategori">Kategori</option>
						<option value="url">URL</option>
					</select>
				</div>
				<div class="form-group" id="link_halaman">
					<label for="link_halaman">Link Halaman</label>
					<select name="link_halaman" class="form-control">
						<option value="">--- Pilih Halaman ---</option>
						<?php foreach ($halaman->result() as $row): ?>
							<option value="<?= $row->slug_halaman; ?>"><?= $row->nama_halaman; ?></option>
						<?php endforeach ?>
					</select>
				</div>
				<div class="form-group" id="link_kategori">
					<label for="link_kategori">Link Kategori</label>
					<select name="link_kategori" class="form-control">
						<option value="">--- Pilih Kategori ---</option>
						<?php foreach ($kategori->result() as $row): ?>
							<option value="<?= $row->category_slug; ?>"><?= $row->category_name; ?></option>
						<?php endforeach ?>
					</select>
				</div>
				<div class="form-group" id="link_url">
					<label for="url">Link URL</label>
					<input type="text" name="link_url" class="form-control" placeholder="URL">
				</div>
				<div class="form-group">
					<label for="urut">No Urut</label>
					<select name="urut" id="urut" class="form-control">
						<option value="">--- Urutan ---</option>
						<?php for ($i=1; $i <=20 ; $i++): ?>
							<option value="<?= $i; ?>"><?= $i; ?></option>
						<?php endfor; ?>
					</select>
				</div>
				<div class="form-group">
					<button type="submit" class="btn btn-secondary btn-block"><i class="fa fa-send"></i> Simpan</button>
				</div>
			</form>
		</div>
	</div>
</div>