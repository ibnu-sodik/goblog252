<?php 
$replace_1 = str_replace('["', '', $bulan_ini);
$replace_2 = str_replace('"]', '', $replace_1);

for ($i=1; $i <=12 ; $i++) { 
	if ($i == $replace_2) {
		$nama_bulan = date('F');
	}
}
?>
<div class="row">
	<div class="col-md-12">
		<h1 class="page-head-line">DASHBOARD</h1>
	</div>
</div>
<!-- /. ROW  -->
<div class="row">
	<div class="col-md-3">
		<div class="main-box mb-red">
			<a href="<?= site_url('admin/post'); ?>">
				<i class="fa fa-book fa-2x"></i>
				<h5><?= number_format($jumlah_artikel); ?>&nbsp;Artikel</h5>
			</a>
		</div>
	</div>
	<div class="col-md-3">
		<div class="main-box mb-dull">
			<a href="javascript:void(0)">
				<i class="fa fa-users fa-2x"></i>
				<h5><?= number_format($jumlah_pengunjung); ?>&nbsp;Pengunjung</h5>
			</a>
		</div>
	</div>
	<div class="col-md-3">
		<div class="main-box mb-cyan">
			<a href="javascript:void(0)">
				<i class="fa fa-eye fa-2x"></i>
				<h5><?= number_format($jumlah_post_dilihat); ?>&nbsp;Artikel Terlihat</h5>
			</a>
		</div>
	</div>
	<div class="col-md-3">
		<div class="main-box mb-pink">
			<a href="<?= site_url('admin/subscribe'); ?>">
				<i class="fa fa-users fa-2x"></i>
				<h5><?= number_format($jumlah_pelanggan); ?>&nbsp;Pelanggan</h5>
			</a>
		</div>
	</div>

</div>
<!-- /. ROW  -->

<div class="row">
	
	<div class="col-md-6">
		<div class="panel panel-default">
			<div class="panel-body">
				<div id="statistikVisitor"></div>
			</div>
		</div>
	</div>
	
	<div class="col-md-6">
		<div class="panel panel-default">
			<div class="panel-body">
				<div id="statistikVisitorPerBulan"></div>
			</div>
		</div>
	</div>
	
	<div class="col-md-6">
		<div class="panel panel-default">
			<div class="panel-body">
				<div id="statistikVisitorPerTahun"></div>
			</div>
		</div>
	</div>

	<div class="col-md-6">
		<div class="panel panel-default">
			<div class="panel-body">
				<div id="browserStat"></div>
			</div>
		</div>
	</div>

</div>

<div class="row">
	<div class="col-md-6">
		<div class="panel panel-default">
			<div class="panel-heading">
				10 Artikel Paling Laris
			</div>
			<div class="panel-body">
				<div id="carouselTop5Artikel" class="carousel slide" data-ride="carousel" style="border: 5px solid #000;">

					<div class="carousel-inner">
						<?php 
						$query = $this->db->query("SELECT MAX(post_views) as jumlah from tb_post");
						$data = $query->row_array();
						$jumlah = $data['jumlah'];

						foreach ($top_lima_artikel->result() as $value):
							if($value->post_views == $jumlah) $class ="item active"; else $class="item";
							?>
							<div class="<?=$class;?>">
								<img src="<?= base_url('uploads/images/'.$value->post_image) ?>" alt="" />
								<div class="carousel-caption">
									<h3><?= $value->post_title; ?></h3>
								</div>
							</div>
						<?php endforeach ?>
					</div>
					<!--INDICATORS-->
					<ol class="carousel-indicators">
						<?php for ($i=0; $i < $top_lima_artikel->num_rows() ; $i++): ?>
							<li data-target="#carouselTop5Artikel" data-slide-to="<?=$i?>" <?php if($i==0)echo 'class="active"'; ?>></li>
						<?php endfor; ?>
					</ol>
					<!--PREVIUS-NEXT BUTTONS-->
					<a class="left carousel-control" href="#carouselTop5Artikel" data-slide="prev">
						<span class="glyphicon glyphicon-chevron-left"></span>
					</a>
					<a class="right carousel-control" href="#carouselTop5Artikel" data-slide="next">
						<span class="glyphicon glyphicon-chevron-right"></span>
					</a>
				</div>
			</div>
		</div>
	</div>
</div>
<script type="text/javascript">

	// Statistk Visitor
	Highcharts.chart('statistikVisitor', {

		chart: {
			type: 'lollipop'
		},

		accessibility: {
			point: {
				valueDescriptionFormat: '{index}. {xDescription}, {point.y}.'
			}
		},

		legend: {
			enabled: false
		},

		subtitle: {
			text: 'Selama Bulan <?= $nama_bulan; ?> Tahun <?= date('Y'); ?>'
		},

		title: {
			text: 'Statistik Pengunjung'
		},

		tooltip: {
			shared: true
		},

		xAxis: {
			type: 'category'
		},

		yAxis: {
			title: {
				text: 'Jumlah'
			}
		},

		series: [{
			name: 'Jumlah Pengunjung',
			data: [
			<?php foreach($statistik_visitor as $value):
				$tanggal = $value->tanggal;
				$jumlah = $value->jumlah;
				?>
				{
					name: '<?= $tanggal.' '.$nama_bulan; ?>',
					low: <?= $jumlah; ?>,
				},
			<?php endforeach; ?>
			]
		}]

	});

	// Statistk Visitor Per Bulan
	Highcharts.chart('statistikVisitorPerBulan', {

		chart: {
			type: 'lollipop'
		},

		accessibility: {
			point: {
				valueDescriptionFormat: '{index}. {xDescription}, {point.y}.'
			}
		},

		legend: {
			enabled: false
		},

		subtitle: {
			<?php 
			foreach($statistik_visitor_per_bulan as $row){
				$tahun = $row->tahun;
			}
			?>
			text: 'Tahun <?= $tahun; ?>'
		},

		title: {
			text: 'Statistik Pengunjung Per Bulan'
		},

		tooltip: {
			shared: true
		},

		xAxis: {
			type: 'category'
		},

		yAxis: {
			title: {
				text: 'Jumlah'
			}
		},

		series: [{
			name: 'Jumlah Pengunjung',
			data: [
			<?php foreach($statistik_visitor_per_bulan as $row):
				$bulan = $row->bulan;
				$jumlah = $row->jumlah;

				$pil_bulan = array(
					01=>'Januari','Februari','Maret','April','Mei','Juni','Juli','Agustus','September','Oktober','November','Desember'
				);

				foreach ($pil_bulan as $key => $value) {
					if ($bulan==$key) {
						$per_bulan = $value;
					}
				}

				?>
				{
					name: '<?= $per_bulan; ?>',
					low: <?= $jumlah; ?>,
				},
			<?php endforeach; ?>
			]
		}]

	});

	// Statistk Visitor Per Tahun
	Highcharts.chart('statistikVisitorPerTahun', {

		chart: {
			type: 'lollipop'
		},

		accessibility: {
			point: {
				valueDescriptionFormat: '{index}. {xDescription}, {point.y}.'
			}
		},

		legend: {
			enabled: false
		},

		title: {
			text: 'Statistik Pengunjung Per Tahun'
		},

		tooltip: {
			shared: true
		},

		xAxis: {
			type: 'category'
		},

		yAxis: {
			title: {
				text: 'Jumlah'
			}
		},

		series: [{
			name: 'Jumlah Pengunjung',
			data: [
			<?php foreach($statistik_visitor_per_tahun as $row):
				$tahun = $row->tahun;
				$jumlah = $row->jumlah;
				?>

				{
					name: '<?= $tahun; ?>',
					low: <?= $jumlah; ?>,
				},
			<?php endforeach; ?>
			]
		}]

	});

	// Browser
	Highcharts.chart('browserStat', {
		chart: {
			plotBackgroundColor: null,
			plotBorderWidth: null,
			plotShadow: false,
			type: 'pie'
		},
		title: {
			text: 'Browser Pengguna Selama Mengunjungi Goblog'
		},

		subtitle: {
			text: 'Total Pengunjung : <?= $jumlah_pengunjung; ?>'
		},
		tooltip: {
			pointFormat: '{series.name}: <b>{point.percentage:.1f}%</b>'
		},
		accessibility: {
			point: {
				valueSuffix: '%'
			}
		},
		plotOptions: {
			pie: {
				allowPointSelect: true,
				cursor: 'pointer',
				dataLabels: {
					enabled: true
				},
				showInLegend: true
			}
		},
		series: [{
			name: 'Presentase',
			colorByPoint: true,
			data: [
			<?php 
			foreach($statistik_browser as $row):
				$browser = $row->browser;
				$jumlah = $row->jumlah;
				$query = $this->db->query("SELECT MAX(visitor_browser) as bb from tb_visitors");
				$data = $query->row_array();
				$bb = $data['bb'];
				$query2 = $this->db->query("SELECT count(visitor_browser) as total from tb_visitors where visitor_browser = '$bb'");
				$data = $query2->row_array();
				$total = $data['total'];
				
				if ($total == $jumlah) {
					$sliced = 'true';
					$selected = 'true';
				}else{
					$sliced = 'false';
					$selected = 'false';
				}
				?>
				{
					name: '<?= $browser; ?>',
					y: <?= $jumlah; ?>,
					sliced: <?= $sliced; ?>,
					selected: <?= $selected; ?>
				},
			<?php endforeach; ?> 
			]
		}]
	});
</script>