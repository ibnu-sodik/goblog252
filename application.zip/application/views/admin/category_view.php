<div class="row">
	<div class="col-md-12">

		<h1 class="page-head-line">Kategori</h1>
		<a href="#" class="btn btn-primary tombol-layang tombol-modal" data-toggle="modal" data-target="#addModal"><i class="fa fa-fw fa-plus fa-1x"></i></a>
		<div class="table-responsive">
			<table class="table table-hover table-striped" id="tabelku">
				<thead>
					<tr>
						<th class="text-center">No</th>
						<th class="text-center">Nama Kategori</th>
						<th class="text-center">Permalink</th>
						<th class="text-center">Opsi</th>
					</tr>
				</thead>
				<tbody>
					<?php 
					$no=0;
					foreach ($data->result() as $row):
						$no++;
						?>
						<tr>
							<td class="text-center"><?=$no?></td>
							<td class="text-center"><?=$row->category_name;?></td>
							<td class="text-center"><?=$row->category_slug;?></td>
							<td class="text-center">
								<a href="javascript:void(0);" title="Edit" data-id="<?=$row->category_id; ?>" data-category="<?=$row->category_name; ?>" class="btn btn-sm btn-warning edit-category"><i class="fa fa-pencil"></i></a>
								<a title="Hapus" href="<?=site_url('admin/category/delete/'.$row->category_id); ?>" class="btn btn-sm btn-danger tombol-hapus"><i class="fa fa-trash"></i></a>
							</td>
						</tr>
					<?php endforeach ?>
				</tbody>
			</table>
		</div>

	</div>

	<!-- modal add -->
	<div class="modal fade" id="addModal" tabindex="-1" role="dialog" aria-labelledby="modalCategory" aria-hidden="true">
		<div class="modal-dialog">
			<div class="modal-content">
				<div class="modal-header">
					<button type="button" class="close" data-dismiss="modal" aria-label="Close">
						<span aria-hidden="true">&times;</span>
					</button>
					<h4 class="modal-title">Tambah Kategori</h4>
				</div>
				<form method="post" action="<?=site_url('admin/category/save')?>">
					<div class="modal-body">
						<div class="form-group">
							<label for="category">Nama Kategori</label>
							<input type="text" name="category" id="category" required placeholder="Nama Kategori" class="form-control" autofocus>
						</div>
					</div>
					<div class="modal-footer">
						<button type="submit" class="btn btn-primary"><i class="fa fa-fw fa-save"></i> Simpan</button>
						<button type="button" class="btn btn-secondary" data-dismiss="modal">Tutup <i class="fa fa-fw fa-remove"></i></button>
					</div>
				</form>
			</div>
		</div>
	</div>

	<!-- modal edit -->
	<div class="modal fade" id="editModal" tabindex="-1" role="dialog" aria-labelledby="modalCategory" aria-hidden="true">
		<div class="modal-dialog">
			<div class="modal-content">
				<div class="modal-header">
					<button type="button" class="close" data-dismiss="modal" aria-label="Close">
						<span aria-hidden="true">&times;</span>
					</button>
					<h4 class="modal-title">Edit Kategori</h4>
				</div>
				<form method="post" action="<?=site_url('admin/category/update')?>">
					<div class="modal-body">
						<div class="form-group">
							<label for="category2">Nama Kategori</label>
							<input type="hidden" name="id_kategori">
							<input type="text" name="category2" id="category2" required autofocus placeholder="Nama Kategori" class="form-control">
						</div>
					</div>
					<div class="modal-footer">
						<button type="submit" class="btn btn-primary"><i class="fa fa-fw fa-save"></i> Simpan</button>
						<button type="button" class="btn btn-secondary" data-dismiss="modal">Tutup <i class="fa fa-fw fa-remove"></i></button>
					</div>
				</form>
			</div>
		</div>
	</div>


</div>