<?php 
if (isset($canonical) && isset($url)) {
	$canonical = $canonical;
	$url = $url;
}else{
	$canonical = site_url('');
	$url = site_url('');
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
	<script data-ad-client="ca-pub-5291703466353684" async src="https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js"></script>
	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
	<meta name="google-site-verification" content="pFwneB8wyeEopIl0fGldx9VnEzHUx30wCf70S_eOkPw" />
	<?php if(isset($title)): ?>
		<title><?=$title?> | <?= $site_title; ?></title>
		<meta property="og:title" content="<?= $title;?>" /><?php else: ?>
		<title><?= $site_title; ?></title>
		<meta property="og:title" content="<?= $site_title;?>" />
	<?php endif; ?>

	<meta name="keywords" content="<?= $site_keywords; ?>">

	<?php if (isset($description)): ?>
		<meta name="description" content="<?= $description; ?>" /><?php else: ?>
		<meta name="description" content="<?= $site_description; ?>" />
	<?php endif; ?>

	<?php if(isset($description)): ?>
		<meta property="og:description" content="<?= $description;?>" /><?php else: ?>
		<meta property="og:description" content="<?= $site_description;?>" />
	<?php endif; ?>

	<?php if (isset($author)): ?>
		<meta name="author" content="<?= $author; ?>"><?php else: ?>
		<meta name="author" content="<?= $site_author; ?>">
	<?php endif; ?>

	<meta property="og:locale" content="id_ID" />
	<meta property="og:type" content="website" />
	<meta property="og:url" content="<?= $url; ?>" />
	<meta property="og:site_name" content="<?= $site_name;?>" />
	<?php if (isset($category)): ?>
		<meta property="article:section" content="<?php echo $category;?>" />		
	<?php endif; ?>
	<?php if (isset($gambar)): ?>		
		<meta property="og:image" content="<?= base_url('uploads/images/thumbs/'.$gambar); ?>" />
		<meta property="og:image:secure_url" content="<?= base_url('uploads/images/thumbs/'.$gambar); ?>" /><?php else: ?>
		<meta property="og:image" content="<?= base_url('assets/images/'.$site_favicon); ?>" />
		<meta property="og:image:secure_url" content="<?= base_url('assets/images/'.$site_favicon); ?>" />
	<?php endif; ?>
	<meta property="og:image:width" content="560" />
	<meta property="og:image:height" content="315" />

	<link rel="canonical" href="<?= $canonical; ?>">
	<?php if(isset($url_prev)): ?>
		<link rel="prev" href="<?= $url_prev;?>" />
	<?php endif; ?>
	<?php if (isset($url_next)): ?>
		<link rel="next" href="<?= $url_next;?>" />
	<?php endif; ?>

	<link rel="shortcut icon" href="<?= base_url('assets/images/'.$site_favicon) ?>" type="image/x-icon" />
	<link rel="apple-touch-icon" href="<?= base_url('assets/images/apple-touch-icon.png') ?>">

	<link href="https://fonts.googleapis.com/css?family=Poppins:300,400,500,600,700" rel="stylesheet"> 

	<link href="<?= base_url('assets/css/bootstrap.css') ?>" rel="stylesheet">

	<link href="<?= base_url('assets/style.css') ?>" rel="stylesheet">

	<link href="<?= base_url('assets/css/jquery.toast.min.css') ?>" rel="stylesheet">

	<link href="<?= base_url('assets/css/responsive.css') ?>" rel="stylesheet">

	<link href="<?= base_url('assets/css/colors.css') ?>" rel="stylesheet">
	<link href="<?= base_url('assets/css/prism.css') ?>" rel="stylesheet">

	<link href="<?= base_url('assets/css/version/tech.css') ?>" rel="stylesheet">

	<link href="<?= base_url('assets/css/font-awesome.min.css') ?>" rel="stylesheet">

	<script src="<?= base_url('assets/js/jquery.min.js') ?>"></script>
	<script src="<?= base_url('assets/js/jquery.toast.min.js') ?>"></script>
	<script src="<?= base_url('assets/js/prism.js') ?>"></script>

</head>
<body>

	<div id="wrapper">
		<header class="tech-header header">
			<div class="container-fluid">
				<nav class="navbar navbar-toggleable-md navbar-inverse fixed-top bg-inverse">
					<button class="navbar-toggler navbar-toggler-right" type="button" data-toggle="collapse" data-target="#navbarCollapse" aria-controls="navbarCollapse" aria-expanded="false" aria-label="Toggle navigation">
						<span class="navbar-toggler-icon"></span>
					</button>
					<a class="navbar-brand" href="<?= base_url(); ?>"><img src="<?= base_url('assets/images/'.$site_logo_header) ?>" alt=""></a>
					<div class="collapse navbar-collapse" id="navbarCollapse">
						<ul class="navbar-nav mr-auto">
							<?php 
							$query = $this->db->query("SELECT * FROM tb_menu WHERE parent_id = '0' AND kategori_menu = 'main' ORDER BY urut");
							if ($query->num_rows() > 0):
								foreach ($query->result() as $row):
									$id_menu = $row->id_menu;
									$query2 = $this->db->query("SELECT * FROM tb_menu WHERE parent_id = '$id_menu' AND kategori_menu = 'main' ORDER BY urut");
									if ($query2->num_rows() > 0):
										?>

										<li class="nav-item dropdown has-submenu">
											<a href="#" class="nav-link dropdown-toggle" id="<?= $row->judul ?>" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false"><?= $row->judul ?></a>
											<ul class="dropdown-menu" aria-labelledby="<?= $row->judul ?>">
												<?php foreach($query2->result() as $row2): ?>
													<li class="nav-link"><a href="<?= $row2->link; ?>" class="nav-item"><?= $row2->judul; ?></a></li>
												<?php endforeach; ?>
											</ul>
										</li>

										<?php else: ?>

											<li class="nav-item">
												<a class="nav-link" href="<?= site_url($row->link); ?>"><?= $row->judul ?></a>
											</li>

											<?php 
										endif;
									endforeach;
									?>

									<?php else: ?>

										<li class="nav-item">
											<p class="nav-link">Tidak Ada Menu</p>
										</li>

										<?php
									endif;
									?>

								</ul>

								<form class="form-inline my-2 my-lg-0" method="GET" action="<?= site_url('search') ?>">
									<input class="form-control mr-sm-2" id="search_query" name="search_query" type="text" placeholder="Search" aria-label="Search" required>
									<button style="cursor: pointer;" class="btn btn-primary" type="submit"><i class="fa fa-search"></i></button>
								</form>

							</div>
						</nav>
					</div>
				</header>

				<?= $contents; ?>

				<footer class="footer">
					<div class="container">
						<div class="row">
							<div class="col-lg-7">
								<div class="widget">
									<div class="footer-text text-left">
										<img src="<?= base_url('assets/images/'.$site_logo_footer) ?>" alt="" class="img-fluid">
										<p><?= nl2br($site_description); ?></p>
										<div class="social">
											<?php foreach($sosmed_web->result() as $row): ?>
												<a href="<?= $row->sosmed_url; ?>" data-toggle="tooltip" data-placement="bottom" title="<?= $row->sosmed_name; ?>"><i class="fa fa-<?= $row->sosmed_icon; ?>"></i></a>
											<?php endforeach; ?>
										</div>

										<hr class="invis">

										<div class="newsletter-widget text-left">
											<form class="form-inline" method="POST" action="<?= site_url('subscribe'); ?>">
												<input type="hidden" name="url" value="<?=site_url()?>" required>
												<input type="email" name="email" class="form-control" placeholder="Enter your email address" required>
												<button style="cursor: pointer;" type="submit" class="btn btn-primary">SUBSCRIBE</button>
											</form>
										</div>
									</div>
								</div>
							</div>

							<div class="col-lg-3 col-md-12 col-sm-12 col-xs-12">
								<div class="widget">
									<h2 class="widget-title">Popular Categories</h2>
									<div class="link-widget">
										<ul>
											<?php foreach($popular_categories->result() as $row): ?>
												<li><a href="<?= site_url('category/'.$row->category_slug); ?>"><?=$row->category_name;?> <span>(<?= $row->jumlah; ?>)</span></a></li>
											<?php endforeach; ?>
										</ul>
									</div>
								</div>
							</div>

							<?php 
							$query_sl = $this->db->query("SELECT * FROM tb_menu WHERE parent_id = '0' AND kategori_menu = 'second' order by urut ASC");
							if($query_sl->num_rows() > 0):
								?>
								<div class="col-lg-2 col-md-12 col-sm-12 col-xs-12">
									<div class="widget">
										<h2 class="widget-title">Quick Link</h2>
										<div class="link-widget">
											<ul>
												<?php foreach ($query_sl->result() as $value): ?>
													<li><a href="<?= site_url($value->link); ?>"><?= $value->judul; ?></a></li>
												<?php endforeach ?>
											</ul>
										</div>
									</div>
								</div>
							<?php endif; ?>

						</div>

						<div class="row">
							<div class="col-md-12 text-center">
								<br>
								<?php 
								$tahun = 2021;
								if ($tahun==date('Y')):
									?>
									<div class="copyright">&copy; <?= date('Y').' - '.$site_name ?></div><?php else: ?>
									<div class="copyright">&copy; <?= date('Y').' - '.$tahun.' '.$site_name ?></div>
								<?php endif; ?>
							</div>
						</div>
					</div>
				</footer>

				<div class="dmtop">Scroll to Top</div>
				<div class="flash-data-sukses" data-flashdata="<?= $this->session->flashdata('pesan_sukses'); ?>"></div>
				<div class="flash-data-error" data-flashdata="<?= $this->session->flashdata('pesan_error'); ?>"></div>

			</div>


			<script src="<?= base_url('assets/js/tether.min.js') ?>"></script>
			<script src="<?= base_url('assets/js/bootstrap.min.js') ?>"></script>
			<script src="<?= base_url('assets/js/custom.js') ?>"></script>
			<script src="<?= base_url('assets/js/goblog.js') ?>"></script>
			<div id="fb-root"></div>
			<script async defer crossorigin="anonymous" src="https://connect.facebook.net/id_ID/sdk.js#xfbml=1&version=v9.0&appId=1859649057516529&autoLogAppEvents=1" nonce="fX445QPH"></script>
			
		</body>
		</html>