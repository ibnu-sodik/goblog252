<div class="page-title lb single-wrapper">
	<div class="container">
		<div class="row">
			<div class="col-lg-8 col-md-8 col-sm-12 col-xs-12">
				<h2><i class="<?= $font_awesome; ?>"></i> <?= $judul; ?></h2>
			</div><!-- end col -->
			<div class="col-lg-4 col-md-4 col-sm-12 hidden-xs-down hidden-sm-down">
				<ol class="breadcrumb">
					<li class="breadcrumb-item"><a href="<?=site_url('home')?>">Home</a></li>
					<li class="breadcrumb-item active"><?=$judul?></li>
				</ol>
			</div>                    
		</div>
	</div>
</div>
<section class="section wb">
	<div class="container">
		<div class="row">
			<div class="col-lg-12">
				<div class="page-wrapper">
					<div class="row">
						<div class="col-lg-5 col-md-5 col-sm-5">
							<?= nl2br($konten_kontak); ?>
						</div>

						<div class="col-lg-7 col-md-7 col-sm-7">
							<form class="form-wrapper" method="POST" action="<?= site_url('contact/kirim') ?>">
								<input type="text" name="pengirim" class="form-control" placeholder="Nama mu">
								<input type="text" name="email" class="form-control" placeholder="Email mu">
								<input type="text" name="no_hp" class="form-control" placeholder="Nomor HP Ex: 62xxxxxxxxx">
								<input type="text" name="subjek" class="form-control" placeholder="Subjek">
								<textarea class="form-control" name="pesan" placeholder="Tulis pesanmu disini"></textarea>
								<button style="cursor: pointer;" type="submit" name="submit" class="btn-block btn btn-primary">Kirim <i class="fa fa-send"></i></button>
							</form>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>
</section>