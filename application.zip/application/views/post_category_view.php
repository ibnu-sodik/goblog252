<div class="page-title lb single-wrapper">
	<div class="container">
		<div class="row">
			<div class="col-lg-8 col-md-8 col-sm-12 col-xs-12">
				<h2><i class="<?=$font_awesome;?>"></i> Kategori <small class="hidden-xs-down hidden-sm-down"><?=$judul?></small></h2>
			</div><!-- end col -->
			<div class="col-lg-4 col-md-4 col-sm-12 hidden-xs-down hidden-sm-down">
				<ol class="breadcrumb">
					<li class="breadcrumb-item"><a href="<?=site_url('home')?>">Home</a></li>
					<li class="breadcrumb-item"><a href="javascript:void(0)"><label for="search_query">Kategori</label></a></li>
					<li class="breadcrumb-item active"><?=$isi?></li>
				</ol>
			</div><!-- end col -->                    
		</div><!-- end row -->
	</div><!-- end container -->
</div><!-- end page-title -->

<section class="section wb">
	<div class="container">
		<div class="row">
			<div class="col-lg-12">
				<div class="page-wrapper">
					<div class="row">

						<?php foreach($kategori->result() as $row): ?>
							<div class="col-lg-4 col-md-4 col-xs-4">							
								<div class="blog-box">
									<div class="post-media">
										<a href="<?= site_url('blog/'.$row->post_slug); ?>" title="<?= $row->post_title; ?>">
											<img src="<?= base_url('uploads/images/'.$row->post_image); ?>" alt="<?= $row->post_title; ?>" class="img-fluid ">
											<div class="hovereffect">
												<span></span>
											</div><!-- end hover -->
										</a>
									</div><!-- end media -->
									<div class="blog-meta big-meta">
										<span><a class="bg-orange" href="<?= site_url('category/'.$row->category_slug); ?>" title="<?= $row->category_slug; ?>"><?= $row->category_name; ?></a></span>
										<h4><a href="<?= site_url('blog/'.$row->post_slug); ?>" title="<?= $row->post_title; ?>"><?= $row->post_title; ?></a></h4>
										<small><a href="javascript:void(0)"><?= date('d M Y', strtotime($row->post_date)); ?></a></small>
										<small><a href="javascript:void(0)"><?= $row->full_name; ?></a></small>
										<small><a href="javascript:void(0)"><i class="fa fa-eye"></i> <?= $row->post_views; ?></a></small>
									</div>
								</div>
							</div>
						<?php endforeach; ?>

					</div>
				</div>

				<hr class="invis">
				
				<?=$pagination;?>
			</div>
		</div>
	</div>
</section>
