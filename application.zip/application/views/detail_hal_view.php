<div class="page-title lb single-wrapper">
	<div class="container">
		<div class="row">
			<div class="col-lg-8 col-md-8 col-sm-12 col-xs-12">
				<h2><i class="fa fa-book bg-orange"></i> <?= $judul; ?> </h2>
			</div><!-- end col -->
			<div class="col-lg-4 col-md-4 col-sm-12 hidden-xs-down hidden-sm-down">
				<ol class="breadcrumb">
					<li class="breadcrumb-item"><a href="<?= site_url('home'); ?>">Home</a></li>
					<li class="breadcrumb-item active"><?= $judul; ?></li>
				</ol>
			</div><!-- end col -->                    
		</div><!-- end row -->
	</div><!-- end container -->
</div><!-- end page-title -->

<section class="section wb">
	<div class="container">
		<div class="row">			
			<div class="col-lg-12 col-md-12 col-xs-12">							
				<div class="blog-box">
					<?= $konten; ?>
				</div>
			</div>
		</div>
	</div>
</section>