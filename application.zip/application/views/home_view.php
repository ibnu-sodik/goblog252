<section class="section first-section">
	<div class="container-fluid">
		<div class="masonry-blog clearfix">

			<?php foreach($post_header->result() as $row): ?>
				<div class="first-slot">
					<div class="masonry-box post-media">
						<img src="<?= base_url('uploads/images/'.$row->post_image); ?>" alt="<?= $row->post_title; ?>" class="img-fluid img-responsive img-thumbanil">
						<div class="shadoweffect">
							<div class="shadow-desc">
								<div class="blog-meta">
									<span class="bg-orange"><a href="<?= site_url('category/'.$row->category_slug); ?>" title="<?= $row->category_slug; ?>"><?= $row->category_name; ?></a></span>
									<h4><a href="<?= site_url('blog/'.$row->post_slug); ?>" title="<?= $row->post_title; ?>"><?= $row->post_title; ?></a></h4>
									<small><a href="javascript:void(0)" title="<?= date('d M Y', strtotime($row->post_date)); ?>"><?= date('d M Y', strtotime($row->post_date)); ?></a></small>
									<small><a href="javascript:void(0)" title="<?= $row->full_name; ?>">by <?= $row->full_name; ?></a></small>
								</div>
							</div>
						</div>
					</div>
				</div>
			<?php endforeach; ?>

			<?php foreach($post_header2->result() as $row): ?>
				<div class="second-slot">
					<div class="masonry-box post-media">
						<img src="<?= base_url('uploads/thumbs/394x449/'.$row->post_image); ?>" alt="<?= $row->post_title; ?>" class="img-fluid img-responsive img-thumbanil">
						<div class="shadoweffect">
							<div class="shadow-desc">
								<div class="blog-meta">
									<span class="bg-orange"><a href="<?= site_url('category/'.$row->category_slug); ?>" title="<?= $row->post_title; ?>"><?= $row->category_name; ?></a></span>
									<h4><a href="<?= site_url('blog/'.$row->post_slug); ?>" title="<?= $row->post_title; ?>"><?= $row->post_title; ?></a></h4>
									<small><a href="javascript:void(0)" title="<?= date('d M Y', strtotime($row->post_date)); ?>"><?= date('d M Y', strtotime($row->post_date)); ?></a></small>
									<small><a href="javascript:void(0)" title="<?= $row->full_name; ?>">by <?= $row->full_name; ?></a></small>
								</div>
							</div>
						</div>
					</div>
				</div>
			<?php endforeach; ?>

			<?php foreach($post_header3->result() as $row): ?>
				<div class="last-slot">
					<div class="masonry-box post-media">
						<img src="<?= base_url('uploads/thumbs/394x449/'.$row->post_image); ?>" alt="<?= $row->post_title; ?>" class="img-fluid img-responsive img-thumbanil">
						<div class="shadoweffect">
							<div class="shadow-desc">
								<div class="blog-meta">
									<span class="bg-orange"><a href="<?= site_url('category/'.$row->category_slug); ?>" title="<?= $row->post_title; ?>"><?= $row->category_name; ?></a></span>
									<h4><a href="<?= site_url('blog/'.$row->post_slug); ?>" title="<?= $row->post_title; ?>"><?= $row->post_title; ?></a></h4>
									<small><a href="javascript:void(0)" title="<?= date('d M Y', strtotime($row->post_date)); ?>"><?= date('d M Y', strtotime($row->post_date)); ?></a></small>
									<small><a href="javascript:void(0)" title="<?= $row->full_name; ?>">by <?= $row->full_name; ?></a></small>
								</div>
							</div>
						</div>
					</div>
				</div>
			<?php endforeach; ?>

		</div>
	</div>
</section>

<section class="section">
	<div class="container">
		<div class="row">
			<div class="col-lg-9 col-md-12 col-sm-12 col-xs-12">
				<div class="page-wrapper">
					<div class="blog-top clearfix">
						<h4 class="pull-left">Recent News <a href="#"><i class="fa fa-rss"></i></a></h4>
					</div>

					<div class="blog-list clearfix">

						<?php foreach($latest_posts->result() as $row): ?>
							<div class="blog-box row">
								<div class="col-md-4">
									<div class="post-media">
										<a href="<?= site_url('blog/'.$row->post_slug); ?>" title="<?= $row->post_title; ?>">
											<img src="<?= base_url('uploads/thumbs/600x500/'.$row->post_image) ?>" alt="<?= $row->post_image; ?>" class="img-fluid img-responsive img-thumbanil">
											<div class="hovereffect"></div>
										</a>
									</div>
								</div>

								<div class="blog-meta big-meta col-md-8">
									<h4><a href="<?= site_url('blog/'.$row->post_slug); ?>" title="<?= $row->post_title; ?>"><?= $row->post_title; ?></a></h4>
									<p align="justify"><?= batasi_kata($row->post_description, 30); ?> ...</p>
									<small class="firstsmall"><a class="bg-orange" href="<?= site_url('category/'.$row->category_slug) ?>" title=""><?= $row->category_name ?></a></small>
									<small><a href="javascript:void(0)"><?= date('d M Y', strtotime($row->post_date)); ?></a></small>
									<small><a href="javascript:void(0)"><?= $row->full_name; ?></a></small>
									<small><a href="javascript:void(0)"><i class="fa fa-eye"></i> <?= $row->post_views; ?></a></small>
								</div><!-- end meta -->
							</div><!-- end blog-box -->

							<hr class="invis">
						<?php endforeach; ?>

						<!-- <div class="row">
							<div class="col-lg-10 offset-lg-1">
								<div class="banner-spot clearfix">
									<div class="banner-img">
										<img src="" alt="" class="img-fluid img-responsive img-thumbanil">
									</div>
								</div>
							</div>
						</div> -->

					</div>
				</div>
				<?php if ($latest_posts->num_rows() > 0): ?>
					<hr class="invis">

					<div class="row pull-right">
						<div class="col-md-6">
							<nav aria-label="Page navigation">
								<ul class="pagination justify-content-start">
									<li class="page-item">
										<a class="page-link btn btn-block" href="<?= site_url('blog');?>">Lihat Semua <i class="fa fa-fw fa-arrow-right"></i></a>
									</li>
								</ul>
							</nav>
						</div>
					</div>
				<?php endif; ?>

			</div>

			<div class="col-lg-3 col-md-12 col-sm-12 col-xs-12">
				<div class="sidebar">
					
					<!-- <div class="widget">
						<div class="banner-spot clearfix">
							<div class="banner-img">
								<img src="" alt="" class="img-fluid img-responsive img-thumbanil">
							</div>
						</div>
					</div> -->

					<div class="widget">
						<h2 class="widget-title">Popular Posts</h2>
						<div class="blog-list-widget">
							<div class="list-group">

								<?php foreach($popular_posts->result() as $row): ?>
									<a href="<?= site_url('blog/'.$row->post_slug); ?>" class="list-group-item list-group-item-action flex-column align-items-start">
										<div class="w-100 justify-content-between">
											<img src="<?= base_url('uploads/thumbs/600x500/'.$row->post_image) ?>" alt="<?= $row->post_title; ?>" class="img-fluid img-responsive img-thumbanil float-left">
											<h5 class="mb-1"><?= $row->post_title; ?></h5>
											<small><?= date('d M Y', strtotime($row->post_date)); ?></small>
										</div>
									</a>
								<?php endforeach; ?>

							</div>
						</div>
					</div>

					<div class="widget">
						<h2 class="widget-title">Recent Reviews</h2>
						<div class="blog-list-widget">
							<div class="list-group">

								<?php foreach($recent_views->result() as $row): ?>
									<a href="<?= base_url('blog/'.$row->post_slug) ?>" class="list-group-item list-group-item-action flex-column align-items-start">
										<div class="w-100 justify-content-between">
											<img src="<?= base_url('uploads/thumbs/600x500/'.$row->post_image) ?>" alt="<?= $row->post_title; ?>" class="img-fluid img-responsive img-thumbanil float-left">
											<h5 class="mb-1"><?= $row->post_title; ?></h5>
										</div>
									</a>
								<?php endforeach; ?>

							</div>
						</div>
					</div>

					<div class="widget">
						<h2 class="widget-title">Follow Us</h2>
						<div class="banner-spot clearfix">
							<div class="banner-img">
								<div class="fb-page" 
								data-href="https://www.facebook.com/GoBlog252-102308025039445/" data-small-header="false" 
								data-adapt-container-width="true" 
								data-hide-cover="false" 
								data-show-facepile="true"></div>
							</div>
						</div>
					</div>

				</div>
			</div>
		</div>
	</div>
</section>