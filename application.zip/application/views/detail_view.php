<section class="section single-wrapper">
	<div class="container">
		<div class="row">
			<div class="col-lg-9 col-md-12 col-sm-12 col-xs-12">
				<div class="page-wrapper">
					<div class="blog-title-area text-center">
						<ol class="breadcrumb hidden-xs-down">
							<li class="breadcrumb-item"><a href="<?= site_url('home') ?>">Home</a></li>
							<li class="breadcrumb-item"><a href="<?= site_url('blog') ?>">Blog</a></li>
							<li class="breadcrumb-item active"><?= $judul; ?></li>
						</ol>

						<span class="color-orange"><a href="<?= site_url('category/'.$category_slug); ?>" title="<?= $category_slug; ?>"><?= $category; ?></a></span>

						<h3><?= $judul; ?></h3>

						<div class="blog-meta big-meta">
							<small><a href="javascript:void(0)" title="<?= date('d M Y',strtotime($date)); ?>"><?= date('d M Y',strtotime($date)); ?></a></small>
							<small><a href="javascript:void(0)" title="<?= $author; ?>">by <?= $author; ?></a></small>
							<small><a href="javascript:void(0)" title="<?= number_format($views); ?>"><i class="fa fa-eye"></i> <?= number_format($views); ?></a></small>
						</div>
					</div>

					<div class="single-post-media">
						<img src="<?= base_url('uploads/images/'.$gambar) ?>" alt="<?= $gambar; ?>" class="img-fluid">
					</div>

					<div class="blog-content">  
						<div class="pp">
							<?= $konten; ?>
						</div>
					</div>
					<hr class="invis1">

					<div class="blog-title-area">
						<div class="tag-cloud-single">
							<span>Tags</span>
							<?php 
							$split_tag = explode(",", $tags);
							foreach($split_tag as $tag):
								?>
								<small><a href="<?= site_url('tag/'.$tag); ?>" title="<?=$tag;?>"><?=$tag;?></a></small>
							<?php endforeach; ?>
						</div>

						<div class="post-sharing">
							<span>Share artikel ini Melalui : </span>
							<ul class="list-inline">

								<li><a title="LinkedIn" href="javascript:void(0)" onclick="javascript:openSocialShare('https://www.linkedin.com/shareArticle?mini=true&url=<?= site_url("blog/".$slug) ?>');" class="btn-padding lk-button btn btn-primary"><i class="fa fa-linkedin"></i></a></li>

								<li><a title="Gmail" href="javascript:void(0)" onclick="javascript:openSocialShare('https://mail.google.com/mail/u/0/?ui=2&view=cm&fs=1&tf=1&su=<?= $judul ?>&body=<?= site_url("blog/".$slug) ?>');" class="btn-padding gm-button btn btn-primary"><i class="fa fa-envelope"></i></a></li>

								<li><a title="Facebook" href="javascript:void(0)" onclick="javascript:openSocialShare('https://www.facebook.com/sharer.php?u=<?= site_url("blog/".$slug) ?>');" class="btn-padding fb-button btn btn-primary"><i class="fa fa-facebook"></i></a></li>

								<li><a title="Telegram" href="javascript:void(0)" onclick="javascript:openSocialShare('https://telegram.me/share/url?url=<?= site_url("blog/".$slug) ?>');" class="btn-padding tl-button btn btn-primary"><i class="fa fa-telegram"></i></a></li>

								<li><a title="Twitter" href="javascript:void(0)" onclick="javascript:openSocialShare('http://twitter.com/share?text=<?=$judul?>&url=<?=site_url("blog/".$slug)?>')" class="btn-padding tw-button btn btn-primary"><i class="fa fa-twitter"></i></a></li>

								<li><a title="WhatsApp" href="javascript:void(0)" onclick="javascript:openSocialShare('https://web.whatsapp.com/send?text=<?= $judul.' | '.site_url("blog/".$slug) ?>')" class="btn-padding wa-button btn btn-primary"><i class="fa fa-whatsapp"></i></a></li>
							</ul>
						</div>
					</div>

					<div class="row">
						<div class="col-lg-12">
							<div class="banner-spot clearfix">
								<div class="banner-img">
									<script async src="https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js"></script>
									<!-- ad-goblog -->
									<ins class="adsbygoogle"
									style="display:block"
									data-ad-client="ca-pub-5291703466353684"
									data-ad-slot="1376190492"
									data-ad-format="auto"
									data-full-width-responsive="true"></ins>
									<script>
										(adsbygoogle = window.adsbygoogle || []).push({});
									</script>
									<!-- <img src="upload/banner_01.jpg" alt="" class="img-fluid"> -->
								</div>
							</div>
						</div>
					</div>
					<?php if($prev_post->num_rows() > 0 OR $next_post->num_rows() > 0): ?>

					<hr class="invis1">

					<div class="custombox prevnextpost clearfix">
						<div class="row">

							
							<div class="col-lg-6">
								<div class="blog-list-widget">
									<div class="list-group">
										<?php if($prev_post->num_rows() > 0): ?>
											<?php foreach($prev_post->result() as $row): ?>
												<a href="<?=site_url('blog/'.$row->post_slug);?>" class="list-group-item list-group-item-action flex-column align-items-start">
													<div class="w-100 justify-content-between text-right">
														<?= $row->post_id; ?>
														<img src="<?= base_url('uploads/images/'.$row->post_image); ?>" alt="<?= $row->post_title; ?>" class="img-fluid float-right">
														<h5 class="mb-1"><?= $row->post_title; ?></h5>
														<small>Prev Post</small>
													</div>
												</a>
											<?php endforeach; ?>
											<?php else: ?>
												<p>Akhir Dari Artikel</p>
											<?php endif; ?>
										</div>
									</div>
								</div>

								<div class="col-lg-6">
									<div class="blog-list-widget">
										<div class="list-group">
											<?php if($next_post->num_rows() > 0): ?>
												<?php foreach($next_post->result() as $row): ?>
													<a href="<?=site_url('blog/'.$row->post_slug);?>" class="list-group-item list-group-item-action flex-column align-items-start">
														<div class="w-100 justify-content-between text-left">
															<?= $row->post_id; ?>
															<img src="<?= base_url('uploads/images/'.$row->post_image); ?>" alt="<?= $row->post_title; ?>" class="img-fluid float-left">
															<h5 class="mb-1"><?= $row->post_title; ?></h5>
															<small>Next Post</small>
														</div>
													</a>
												<?php endforeach; ?>
												<?php else: ?>
													<p>Akhir Dari Artikel</p>
												<?php endif; ?>
											</div>
										</div>
									</div>

								</div>
							</div>
						<?php endif; ?>

						<hr class="invis1">

						<div class="custombox authorbox clearfix">
							<h4 class="small-title">Tentang Penulis</h4>
							<div class="row">
								<div class="col-lg-2 col-md-2 col-sm-2 col-xs-12">
									<img src="<?= base_url('uploads/thumbs/admin/'.$author_foto) ?>" alt="" class="img-fluid rounded-circle img-responsive"> 
								</div><!-- end col -->

								<div class="col-lg-10 col-md-10 col-sm-10 col-xs-12">
									<h4><a href="javascript:void(0)"><?= $author; ?></a></h4>
									<p><?= nl2br($user_info); ?></p>

									<div class="topsocial">
										<?php foreach($sosmed_author->result() as $row): ?>
											<a href="<?= $row->sosmed_url; ?>" data-toggle="tooltip" data-placement="bottom" title="<?= $row->sosmed_name; ?>"><i class="fa fa-<?= $row->sosmed_icon; ?>"></i></a>
										<?php endforeach; ?>
									</div>

								</div>
							</div>
						</div>

						<?php if($related_post->num_rows() > 0): ?>
							<hr class="invis1">
							<div class="custombox clearfix">
								<h4 class="small-title">Mungkin Anda Juga Suka</h4>
								<div class="row">

									<?php foreach($related_post->result() as $row): ?>
										<div class="col-lg-6 col-md-6 col-xs-6">
											<div class="blog-box">
												<div class="post-media">
													<a href="<?=site_url('blog/'.$row->post_slug)?>" title="<?= $row->post_title; ?>">
														<img src="<?= base_url('uploads/images/'.$row->post_image); ?>" alt="<?= $row->post_title; ?>" class="img-fluid">
														<div class="hovereffect">
															<span class=""></span>
														</div>
													</a>
												</div>
												<div class="blog-meta">							
													<h4><a href="<?= site_url('blog/'.$row->post_slug); ?>" title="<?= $row->post_title; ?>"><?= $row->post_title; ?></a></h4>
													<small><a href="<?= site_url('category/'.$row->category_slug); ?>" title="<?= $row->category_slug; ?>"><?= $row->category_name; ?></a></small>
													<small><a href="javascript:void(0)"><?= date('d M Y', strtotime($row->post_date)); ?></a></small>
												</div>
											</div>
										</div>
									<?php endforeach; ?>

								</div>
							</div>
						<?php endif; ?>

						<hr class="invis1">

						<ul class="nav nav-tabs" id="GoTab" role="tablist">
							<li class="nav-item">
								<a class="nav-link active" id="tab-default-comments" data-toggle="tab" href="#default-comments" role="tab" aria-controls="default-comments" aria-selected="true">Default Komentar</a>
							</li>
						</ul>

						<hr class="invis1">

						<div class="tab-content" id="GoTabContent">

							<div class="tab-pane fade show active" id="default-comments" role="tabpanel" aria-labelledby="default-comments-tab">
								<div class="custombox clearfix">
									<h4 class="small-title"><?= $comment; ?> Komentar</h4>
									<div class="row">
										<div class="col-lg-12">
											<div class="comments-list">
												<?php foreach($lihat_komentar->result() as $row):

													$hash = md5( strtolower( trim( $row->comment_email ) ) );
													$link_foto = 'https://www.gravatar.com/avatar/'.$hash;
													?>
													<li class="comment" style="list-style: none;">
														<div class="media">
															<span class="media-left">
																<img src="<?= $link_foto; ?>?s=50&r=pg" alt="<?= $row->comment_email; ?>" class="rounded-circle">
															</span>
															<div class="media-body">
																<h4 class="media-heading user_name"><?= $row->comment_name; ?> <small><?= waktu_berlalu($row->comment_date); ?></small></h4>
																<p><?= nl2br($row->comment_message); ?></p>
																<a href="javascript:void(0)" class="btn btn-primary btn-sm btn-reply" data-comment_id="<?=$row->comment_id;?>" data-comment_post_id="<?=$row->comment_post_id;?>">Balas</a>
															</div>
														</div>
														<?php 
														$comment_id = $row->comment_id;
														$query = $this->db->query("SELECT * FROM tb_comment WHERE comment_status = '1' AND comment_parent = '$comment_id'");
														foreach($query->result() as $val):
															$hash = md5( strtolower( trim( $val->comment_email ) ) );
															$link_foto = 'https://www.gravatar.com/avatar/'.$hash;
															?>
															<ul class="last-child">
																<li class="comment" style="list-style: none;">
																	<div class="media last-child">
																		<span class="media-left">
																			<img src="<?= $link_foto; ?>?s=50&r=pg" alt="<?= $val->comment_email; ?>" class="rounded-circle">
																		</span>
																		<div class="media-body">
																			<h4 class="media-heading user_name"><?= $val->comment_name; ?> <small><?= waktu_berlalu($val->comment_date); ?></small></h4>
																			<p><?= nl2br($val->comment_message); ?></p>
																			
																			<a href="javascript:void(0)" class="btn btn-primary btn-sm btn-reply" data-comment_id="<?=$val->comment_id;?>" data-comment_post_id="<?=$val->comment_post_id;?>">Balas</a>
																		</div>
																	</div>
																	<?php 
																	$comment_id = $val->comment_id;
																	$query2 = $this->db->query("SELECT * FROM tb_comment WHERE comment_status = '1' AND comment_parent = '$comment_id'");
																	foreach ($query2->result() as $key):
																		$hash = md5( strtolower( trim( $key->comment_email ) ) );
																		$link_foto = 'https://www.gravatar.com/avatar/'.$hash;
																		?>
																		<ul class="last-child">
																			<li class="comment" style="list-style: none;">
																				<div class="media last-child">
																					<span class="media-left">
																						<img src="<?= $link_foto; ?>?s=50&r=pg" alt="<?= $key->comment_email; ?>" class="rounded-circle">
																					</span>
																					<div class="media-body">
																						<h4 class="media-heading user_name"><?= $key->comment_name; ?> <small><?= waktu_berlalu($key->comment_date); ?></small></h4>
																						<p><?= nl2br($key->comment_message); ?></p>

																					</div>
																				</div>
																			</li>
																		</ul>
																	<?php endforeach ?>
																</li>
															</ul>
														<?php endforeach; ?>
													</li>
												<?php endforeach; ?>
											</div>
										</div>
									</div>
								</div>

								<div class="custombox clearfix" id="formBalas" style="display: none; position: relative;">
									<h4 class="small-title">Balas Komentar</h4>
									<div class="row">
										<div class="col-lg-12">
											<form class="form-wrapper" method="POST" action="<?= site_url('kirim_balasan')?>">
												<input type="hidden" name="slug" value="<?= $slug; ?>">
												<input type="hidden" name="co_pid" required>
												<input type="hidden" name="co_id" required>
												<input type="text" name="nama" class="form-control" placeholder="Nama" autofocus>
												<input type="text" name="email" class="form-control" placeholder="Email">
												<input type="text" name="website" class="form-control" placeholder="Website">
												<textarea name="balasan" class="form-control" placeholder="Balasan"></textarea>
												<button style="cursor: pointer;" type="submit" name="submit" class="btn btn-primary"><i class="fa fa-send"></i> Kirim</button>
												<button style="cursor: pointer;" type="reset" class="btn-close btn btn-warning" id="tutupKomentar">Batal <i class="fa fa-remove"></i></button>
											</form>
										</div>
									</div>
								</div>

								<script type="text/javascript">
									$(document).ready(function() {
										$('.btn-reply').on('click', function() {
											var com_id = $(this).data('comment_id');
											var com_post_id = $(this).data('comment_post_id');
											$('#formBalas').show();
											$('#beriKomentar').hide();
											$('[name="co_id"]').val(com_id);
											$('[name="co_pid"]').val(com_post_id);
										});

										$('.btn-close').on('click', function() {
											$('#formBalas').hide();
											$('#beriKomentar').show();
										})
									});
								</script>

								<hr class="invis1">

								<div class="custombox clearfix" id="beriKomentar">
									<h4 class="small-title">Beri Komentar</h4>
									<div class="row">
										<div class="col-lg-12">
											<form class="form-wrapper" method="POST" action="<?= site_url('kirim_komentar'); ?>">
												<input type="hidden" name="slug" value="<?= $slug; ?>">
												<input type="hidden" name="co_pid" value="<?= $post_id; ?>" required>
												<input type="text" name="nama" class="form-control" placeholder="Nama">
												<input type="text" name="email" class="form-control" placeholder="Email">
												<input type="text" name="website" class="form-control" placeholder="Website">
												<textarea name="komentar" class="form-control" placeholder="Komentar"></textarea>
												<button style="cursor: pointer;" type="submit" name="submit" class="btn btn-primary"><i class="fa fa-send"></i> Kirim</button>
											</form>
										</div>
									</div>
								</div>
							</div>

						</div>

					</div>
				</div>

				<div class="col-lg-3 col-md-12 col-sm-12 col-xs-12">
					<div class="sidebar">
						
						<div class="widget">
							<div class="banner-spot clearfix">
								<div class="banner-img">
									<script async src="https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js"></script>
									<ins class="adsbygoogle"
									style="display:block"
									data-ad-format="fluid"
									data-ad-layout-key="-hb-2z-1n+8q+a2"
									data-ad-client="ca-pub-5291703466353684"
									data-ad-slot="3016575229"></ins>
									<script>
										(adsbygoogle = window.adsbygoogle || []).push({});
									</script>
									
									<!-- <img src="<?=base_url()?>assets/upload/banner_07.jpg" alt="" class="img-fluid"> -->
								</div>
							</div>
						</div>

						<div class="widget">
							<h2 class="widget-title">Popular Posts</h2>
							<div class="blog-list-widget">
								<div class="list-group">
									<?php foreach($popular_posts->result() as $row): ?>
										<a href="<?= site_url('blog/'.$row->post_slug); ?>" class="list-group-item list-group-item-action flex-column align-items-start">
											<div class="w-100 justify-content-between">
												<img src="<?= base_url('uploads/thumbs/600x500/'.$row->post_image) ?>" alt="<?= $row->post_title; ?>" class="img-fluid float-left">
												<h5 class="mb-1"><?= $row->post_title; ?></h5>
												<small><?= date('d M Y', strtotime($row->post_date)); ?></small>
											</div>
										</a>
									<?php endforeach; ?>
								</div>
							</div>
						</div>

						<div class="widget">
							<h2 class="widget-title">Recent Reviews</h2>
							<div class="blog-list-widget">
								<div class="list-group">

									<?php foreach($recent_views->result() as $row): ?>
										<a href="<?= base_url('blog/'.$row->post_slug) ?>" class="list-group-item list-group-item-action flex-column align-items-start">
											<div class="w-100 justify-content-between">
												<img src="<?= base_url('uploads/thumbs/600x500/'.$row->post_image) ?>" alt="<?= $row->post_title; ?>" class="img-fluid float-left">
												<h5 class="mb-1"><?= $row->post_title; ?></h5>
											</div>
										</a>
									<?php endforeach; ?>

								</div>
							</div>
						</div>

						<div class="widget">
							<h2 class="widget-title">Follow Us</h2>
							<div class="banner-spot clearfix">
								<div class="banner-img">
									<div class="fb-page" 
									data-href="https://www.facebook.com/GoBlog252-102308025039445/"
									data-width="360"
									data-hide-cover="false"
									data-show-facepile="true"></div>
								</div>
							</div>
							&nbsp;
							<!-- <div class="clearfix">
								<a href="https://twitter.com/Is_Isodik?ref_src=twsrc%5Etfw" class="twitter-follow-button" data-show-count="false" class="social-button twitter-button">
									<i class="fa fa-twitter"></i>
								</a>
								<script async src="https://platform.twitter.com/widgets.js" charset="utf-8"></script>
							</div> -->
						</div>

					</div>
				</div>
			</div>
		</div>
	</section>

	<script type="text/javascript" async >
		function openSocialShare(url){
			window.open(url,'sharer','toolbar=0,status=0,width=648,height=395');
			return true;
		}
	</script>