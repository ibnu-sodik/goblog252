<?php 
date_default_timezone_set('Asia/Jakarta');
function tgl_indo($indo_tgl){
	$indo_tgl = strtotime($indo_tgl);
	return $indo_tgl;
}

function tgl($date)
{
	$tanggal = new DateTime($date);
	$hasil = $tanggal->format('d F Y H:i');
	return $hasil;
}

function batasi_kata($kalimat_lengkap, $jumlah_kata)
{
	$arr_str = explode(' ', $kalimat_lengkap);
	$arr_str = array_slice($arr_str, 0, $jumlah_kata );
	return implode(' ', $arr_str);
}

function sanitize($dirty){
	return htmlentities($dirty, ENT_QUOTES,"UTF-8");
}

function waktu_berlalu($datetime, $penuh = false) {
    $sekarang = new DateTime;
    $yangLalu = new DateTime($datetime);
    $diff = $sekarang->diff($yangLalu);

    $diff->w = floor($diff->d / 7);
    $diff->d -= $diff->w * 7;

    $string = array(
        'y' => 'tahun',
        'm' => 'bulan',
        'w' => 'minggu',
        'd' => 'hari',
        'h' => 'jam',
        'i' => 'menit',
        's' => 'detik',
    );
    foreach ($string as $k => &$v) {
        if ($diff->$k) {
            $v = $diff->$k . ' ' . $v . ($diff->$k > 1 ? '' : '');
        } else {
            unset($string[$k]);
        }
    }

    if (!$penuh) $string = array_slice($string, 0, 1);
    return $string ? implode(', ', $string) . ' yang lalu' : 'Baru saja';
}