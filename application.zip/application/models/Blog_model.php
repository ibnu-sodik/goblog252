<?php
/**
 * Blog Model
 */
class Blog_model extends CI_Model
{

	function get_next_post($post_id, $category)
	{
		$query = $this->db->query("SELECT tb_post.*, tb_category.* FROM tb_post
			LEFT JOIN tb_category ON post_category_id = '$category'
			WHERE post_id > '$post_id' AND NOT post_id='$post_id' AND post_published=1 ORDER BY post_id ASC LIMIT 1");
		return $query;
	}

	function get_prev_post($post_id, $category)
	{
		$query = $this->db->query("SELECT tb_post.*, tb_category.* FROM tb_post
			LEFT JOIN tb_category ON post_category_id = '$category'
			WHERE post_id < '$post_id' AND NOT post_id='$post_id' AND post_published=1 ORDER BY post_id DESC LIMIT 1");
		return $query;
	}

	function get_related_post($category_id, $post_id)
	{
		$query = $this->db->query("SELECT tb_category.*,tb_post.* FROM tb_post LEFT JOIN tb_user ON post_user_id =id 
			left join tb_category ON post_category_id = category_id
			WHERE post_category_id='$category_id' AND NOT post_id='$post_id' and post_published = '1' ORDER BY post_views DESC LIMIT 2");
		return $query;
	}

	function get_halaman_by_slug($slug)
	{
		$query = $this->db->query("SELECT * FROM tb_halaman WHERE slug_halaman = '$slug'");
		return $query;
	}

	function get_post_preview_by_slug($slug)
	{
		$query = $this->db->query("SELECT tb_post.*, tb_user.*, COUNT(comment_id) AS comment_total, tb_category.* FROM tb_post
			LEFT JOIN tb_user ON post_user_id = id
			left join tb_comment ON post_id = comment_post_id
			left join tb_category ON post_category_id = category_id
			where post_slug = '$slug' AND post_published = '0' GROUP BY post_id LIMIT 1");
		return $query;
	}

	function get_post_by_slug($slug)
	{
		$query = $this->db->query("SELECT tb_post.*, tb_user.*, COUNT(comment_id) AS comment_total, tb_category.* FROM tb_post
			LEFT JOIN tb_user ON post_user_id = id
			left join tb_comment ON post_id = comment_post_id
			left join tb_category ON post_category_id = category_id
			where post_slug = '$slug' AND post_published = '1' GROUP BY post_id LIMIT 1");
		return $query;
	}
	
	function hitung_views($post_id)
	{
		$visitor_ip = $_SERVER['REMOTE_ADDR'];
		$cek_ip = $this->db->query("SELECT * FROM tb_post_views WHERE view_ip = '$visitor_ip' AND view_post_id = '$post_id' AND DATE(view_date)=CURDATE()");
		if ($cek_ip->num_rows() <= 0) {
			$this->db->trans_start();
			$this->db->query("INSERT INTO tb_post_views SET view_ip = '$visitor_ip', view_post_id = '$post_id'");
			$this->db->query("UPDATE tb_post SET post_views = post_views+1, post_recent_views=NOW() WHERE post_id='$post_id'");
			$this->db->trans_complete();
			if ($this->db->trans_status()==TRUE) {
				return TRUE;
			}else{
				return FALSE;
			}
		}
	}

	function simpan_komentar($co_pid, $nama, $email, $website, $komentar)
	{
		$object = array(
			'comment_name' => $nama,
			'comment_email' => $email,
			'komentator_website' => $website,
			'comment_message' => $komentar,
			'comment_post_id' => $co_pid,
		);
		$this->db->insert('tb_comment', $object);
	}

	function simpan_balasan($co_pid, $co_id, $nama, $email, $website, $balasan)
	{
		$object = array(
			'comment_name' => $nama,
			'comment_email' => $email,
			'komentator_website' => $website,
			'comment_message' => $balasan,
			'comment_parent' => $co_id,
			'comment_post_id' => $co_pid,
		);
		$this->db->insert('tb_comment', $object);
	}

	function lihat_komentar($post_id)
	{
		$query = $this->db->query("SELECT * FROM tb_comment WHERE comment_post_id = '$post_id' AND comment_status = '1' AND comment_parent = '0'");
		return $query;
	}

	function get_blogs()
	{
		$query = $this->db->get_where('tb_post', array('post_published' => '1'));
		return $query;
	}

	function get_blog_perpage($offset,$limit)
	{
		$this->db->select('tb_post.*, full_name, foto, tb_category.*');
		$this->db->from('tb_post');
		$this->db->join('tb_user', 'post_user_id = id', 'left');
		$this->db->join('tb_category', 'post_category_id = category_id', 'left');
		$this->db->where('post_published', 1);
		$this->db->order_by('post_id', 'desc');
		$this->db->limit($limit, $offset);
		$query = $this->db->get();
		return $query;
	}
}