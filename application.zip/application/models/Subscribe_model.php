<?php
defined('BASEPATH') OR exit('No direct script access allowed');

/**
 * Subscribe model
 */
class Subscribe_model extends CI_Model
{
	function cek_email($email)
	{
		$this->db->select('*');
		$this->db->from('tb_subscribe');
		$this->db->where('subscribe_email', $email);
		$query = $this->db->get();
		return $query;
	}

	function simpan_subscribe($email)
	{
		$query = $this->db->query("INSERT INTO tb_subscribe SET subscribe_email = '$email' ");
		return $query;
	}

}