<?php 
defined('BASEPATH') OR exit('No direct script access allowed');

class Visitor_model extends CI_Model {

	
	function statistik_visitor_per_tahun()
	{
		$query = $this->db->query("SELECT DATE_FORMAT(visit_date, '%Y') AS tahun, COUNT(*) as 'jumlah' FROM tb_visitors GROUP BY YEAR(visit_date)");

		if ($query->num_rows() > 0) {
			foreach ($query->result() as $data) {
				$result[] = $data;
			}
			return $result;
		}else{
			return $query;
		}
	}

	function statistik_visitor_per_bulan()
	{
		$query = $this->db->query("SELECT DATE_FORMAT(visit_date, '%m') AS bulan, DATE_FORMAT(visit_date, '%Y') as tahun, COUNT(*) as 'jumlah' FROM tb_visitors WHERE YEAR(visit_date)=YEAR(CURDATE()) GROUP BY MONTH(visit_date)");

		if ($query->num_rows() > 0) {
			foreach ($query->result() as $data) {
				$result[] = $data;
			}
			return $result;
		}else{
			return $query;
		}
	}

	function statistik_visitor()
	{
		$query = $this->db->query("SELECT DATE_FORMAT(visit_date, '%d') AS tanggal, DATE_FORMAT(visit_date, '%m') AS bulan ,COUNT(*) as 'jumlah' FROM tb_visitors WHERE MONTH(visit_date)=MONTH(CURDATE()) GROUP BY DATE_FORMAT(visit_date, '%d')");

		if ($query->num_rows() > 0) {
			foreach ($query->result() as $data) {
				$result[] = $data;
			}
			return $result;
		}else{
			return $query;
		}
	}

	function statistik_browser()
	{
		$query = $this->db->query("SELECT visitor_browser as browser, count(*) as jumlah FROM `tb_visitors` GROUP by visitor_browser");
		if ($query->num_rows() > 0) {
			foreach ($query->result() as $data) {
				$result[] = $data;
			}
			return $result;
		}
	}

	function top_lima_artikel()
	{
		$query = $this->db->query("SELECT * FROM tb_post ORDER BY post_views DESC LIMIT 10");
    	return $query;
	}

	function hitung_total_visitor()
	{
		$query = $this->db->query("SELECT count(*) tot_visitor FROM tb_visitors");
		return $query;
	}

	function hitung_pelanggan()
	{
		$query = $this->db->count_all('tb_subscribe');
		return $query;		
	}

	function hitung_artikel()
	{
		$query = $this->db->count_all('tb_post');
		return $query;		
	}

	function hitung_post_dilihat()
	{
		$query = $this->db->count_all('tb_post_views');
		return $query;		
	}

	function hitung_semua_visitor()
	{
		$query = $this->db->count_all('tb_visitors');
		return $query;
	}

}

/* End of file Visitor_model.php */
/* Location: ./application/models/admin/Visitor_model.php */

?>