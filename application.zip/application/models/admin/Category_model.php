<?php

defined('BASEPATH') OR exit('No direct script access allowed');

class Category_model extends CI_Model
{
	function _update($id,$category,$slug)
	{
		$data = array(
			'category_name' => $category,
			'category_slug' => $slug
		);
		$this->db->where('category_id', $id);
		$this->db->update('tb_category', $data);
	}
	function _insert($category,$slug)
	{
		$data = array(
			'category_name' => $category,
			'category_slug' => $slug
		);
		$this->db->insert('tb_category', $data);
	}
	
	function delete_category($category_id)
	{
		$this->db->where('category_id', $category_id);
		$this->db->delete('tb_category');
	}

	function get_all_category()
	{
		$result = $this->db->get('tb_category');
		return $result;
	}
}

/* End of file Category_model.php */
/* Location: ./application/models/admin/Category_model.php */