<?php
/**
 * Tag Model
 */
class Tag_model extends CI_Model
{
	function _update($id,$tag,$slug)
	{
		$data = array(
			'tag_name' => $tag,
			'tag_slug' => $slug
		);
		$this->db->where('tag_id', $id);
		$this->db->update('tb_tags', $data);
	}
	function _insert($tag,$slug)
	{
		$data = array(
			'tag_name' => $tag,
			'tag_slug' => $slug
		);
		$this->db->insert('tb_tags', $data);
	}
	
	function delete_tag($tag_id)
	{
		$this->db->where('tag_id', $tag_id);
		$this->db->delete('tb_tags');
	}
	
	function get_all_tag()
	{
		$result = $this->db->get('tb_tags');
		return $result;
	}
}