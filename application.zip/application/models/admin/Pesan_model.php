<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Pesan_model extends CI_Model {

	function get_all_pesan()
	{
		$query = $this->db->query("SELECT * FROM tb_pesan ORDER BY tgl_kirim DESC");
		return $query;
	}

	function star($pesan_id)
	{
		$object = array('pesan_bintang' => 1 );
		$this->db->where('pesan_id', $pesan_id);
		$this->db->update('tb_pesan', $object);
	}

	function unstar($pesan_id)
	{
		$object = array('pesan_bintang' => 0 );
		$this->db->where('pesan_id', $pesan_id);
		$this->db->update('tb_pesan', $object);
	}

	function read($pesan_id)
	{
		$object = array('status_pesan' => 1 );
		$this->db->where('pesan_id', $pesan_id);
		$this->db->update('tb_pesan', $object);
	}

	function unread($pesan_id)
	{
		$object = array('status_pesan' => 0 );
		$this->db->where('pesan_id', $pesan_id);
		$this->db->update('tb_pesan', $object);
	}

	function get_pesan_by_id($pesan_id)
	{
		$query = $this->db->query("SELECT * FROM tb_pesan WHERE pesan_id = '$pesan_id'");
		return $query;

	}

	function _delete($pesan_id)
	{
		$this->db->where('pesan_id', $pesan_id);
		$this->db->delete('tb_pesan');
	}

	function simpan_pesan($pengirim, $email, $no_hp, $subjek, $pesan)
	{
		$object = array(
			'pesan_dari' 	=> $pengirim,
			'pesan_email' 	=> $email,
			'no_hp' 		=> $no_hp,
			'subjek_pesan' 	=> $subjek,
			'isi_pesan' 	=> $pesan,
		);
		$this->db->insert('tb_pesan', $object);
	}

}

/* End of file Pesan_model.php */
/* Location: ./application/models/admin/Pesan_model.php */ ?>