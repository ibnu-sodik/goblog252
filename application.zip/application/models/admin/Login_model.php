<?php

defined('BASEPATH') OR exit('No direct script access allowed');

class Login_model extends CI_Model {


	function update_login($date, $id)
	{
		$data = array(
			'last_login' => $date
		);
		$this->db->where('id', $id);
		$this->db->update('tb_user', $data);
	}

	function validasi($username, $password)
	{
		$result = $this->db->query("SELECT * FROM tb_user WHERE email = '$username' OR username='$username' AND password = sha1(md5('$password'))");
		return $result;
	}
	

}

/* End of file Login_model.php */
/* Location: ./application/models/admin/Login_model.php */