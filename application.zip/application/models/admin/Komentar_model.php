<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Komentar_model extends CI_Model {

	function get_all_komentar($offset, $limit)
	{
		$result = $this->db->query("SELECT comment_id,DATE_FORMAT(comment_date,'%d %M %Y %H:%i') AS comment_date, comment_name, comment_email, komentator_website, comment_status, comment_message, post_id, post_title, post_slug
			FROM tb_comment 
			JOIN tb_post ON comment_post_id=post_id 
			WHERE comment_parent='0' ORDER BY comment_id DESC LIMIT $offset, $limit");
		return $result;
	}

	function get_unpublish_komentar($offset, $limit)
	{
		$result = $this->db->query("SELECT comment_id,DATE_FORMAT(comment_date,'%d %M %Y %H:%i') AS comment_date, comment_name, comment_email, komentator_website, comment_status, comment_message, post_id, post_title, post_slug
			FROM tb_comment 
			JOIN tb_post ON comment_post_id=post_id 
			WHERE comment_status = '0' ORDER BY comment_id DESC LIMIT $offset, $limit");
		return $result;
	}

	function publish($comment_id)
	{
		$object = array('comment_status' => 1 );
		$this->db->where('comment_id', $comment_id);
		$this->db->update('tb_comment', $object);
	}

	function edit($comment_id, $contents, $web)
	{
		$object = array(
			'comment_message' => $contents,
			'komentator_website' => $web,
			 );
		$this->db->where('comment_id', $comment_id);
		$this->db->update('tb_comment', $object);
	}

	function hapus($comment_id)
	{
		$this->db->trans_start();
			$this->db->query("DELETE FROM tb_comment WHERE comment_parent='$comment_id'");
			$this->db->query("DELETE FROM tb_comment WHERE comment_id='$comment_id'");
		$this->db->trans_complete();
	}

	function balas($comment_id, $comment_post_id, $contents, $nama, $email, $web)
	{
		$object = array(
			'comment_name' => $nama, 
			'comment_email' => $email, 
			'comment_message' => $contents, 
			'komentator_website' => $web, 
			'comment_parent' => $comment_id, 
			'comment_post_id' => $comment_post_id,
			'comment_status' => '1' 
		);
		$this->db->insert('tb_comment', $object);
	}

	function cari_komentar($keyword, $limit){
		$hsl=$this->db->query("SELECT comment_id,DATE_FORMAT(comment_date,'%d %M %Y %H:%i') AS comment_date, comment_name, comment_email, komentator_website, comment_status, comment_message, post_id, post_title, post_slug
			FROM tb_comment 
			JOIN tb_post ON comment_post_id=post_id  
			WHERE (comment_name LIKE '%$keyword%' OR post_title LIKE '%$keyword%') AND comment_parent='0' ORDER BY comment_id DESC LIMIT $limit");
		return $hsl;
	}

}

/* End of file Komentar_model.php */
/* Location: ./application/models/admin/Komentar_model.php */ ?>