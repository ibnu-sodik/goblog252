<?php 

defined('BASEPATH') OR exit('No direct script access allowed');

class Halaman_model extends CI_Model {

	function _update($id_halaman, $nama_halaman, $konten_halaman, $slug){
		$result = $this->db->query("UPDATE tb_halaman SET 
			nama_halaman = '$nama_halaman',
			konten_halaman = '$konten_halaman',
			halaman_update = NOW(),
			slug_halaman = '$slug' WHERE id_halaman = '$id_halaman'");
		return $result;
	}

	function get_halaman_by_id($id_halaman){
		$result = $this->db->query("SELECT * FROM tb_halaman WHERE id_halaman='$id_halaman'");
		return $result;
	}

	function get_file_by_id($id_halaman)
	{
		$result = $this->db->query("SELECT * FROM tb_halaman WHERE id_halaman = '$id_halaman'");
		return $result;
	}

	function delete_halaman($id_halaman)
	{
		$this->db->where('id_halaman', $id_halaman);
		$this->db->delete('tb_halaman');
	}

	function simpan_halaman($nama_halaman, $slug, $konten_halaman)
	{
		$object = array(
			'nama_halaman' 		=> $nama_halaman,
			'konten_halaman' 	=> $konten_halaman,
			// 'gambar_halaman' 	=> $image,
			'slug_halaman' 		=> $slug,
			'halaman_user_id' 	=> $this->session->userdata('id')
		);
		$this->db->insert('tb_halaman', $object);
	}

	function get_all_halaman()
	{
		$this->db->select('tb_halaman.*, tb_user.*');
		$this->db->from('tb_halaman');
		$this->db->join('tb_user', 'id = halaman_user_id', 'left');
		$query = $this->db->get();
		return $query;
	}

}

/* End of file Halaman_model.php */
/* Location: ./application/models/admin/Halaman_model.php */

?>