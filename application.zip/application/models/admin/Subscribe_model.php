<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Subscribe_model extends CI_Model {

	function delete($subscribe_id)
	{
		$this->db->where('subscribe_id', $subscribe_id);
		$this->db->delete('tb_subscribe');
	}

	function activate($subscribe_id)
	{
		$this->db->set('subscribe_status', '1', false);
		$this->db->where('subscribe_id', $subscribe_id);
		$this->db->update('tb_subscribe');
	}

	function decrease_rating($subscribe_id)
	{
		$this->db->set('subscribe_rating', 'subscribe_rating-1', false);
		$this->db->where('subscribe_id', $subscribe_id);
		$this->db->update('tb_subscribe');
	}

	function increase_rating($subscribe_id)
	{
		$this->db->set('subscribe_rating', 'subscribe_rating+1', false);
		$this->db->where('subscribe_id', $subscribe_id);
		$this->db->update('tb_subscribe');
	}

	function get_subscribers_by_id($subscribe_id)
	{
		$query = $this->db->get_where('tb_subscribe', array('subscribe_id' => $subscribe_id));
		return $query;
	}

	function get_subscribers()
	{
		$query = $this->db->get('tb_subscribe');
		return $query;
	}

}

/* End of file Subscribe_model.php */
/* Location: ./application/models/admin/Subscribe_model.php */ 
?>