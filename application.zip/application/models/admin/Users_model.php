<?php
/**
 * Users model
 */
class Users_model extends CI_Model
{

	function delete_sosmed($sosmed_id)
	{
		$this->db->where('sosmed_id', $sosmed_id);
		$this->db->delete('tb_sosmed');
	}

	function update_sosmed($sosmed_name, $sosmed_url, $sosmed_icon, $sosmed_id)
	{
		$object = array(
			'sosmed_name' 		=> $sosmed_name,
			'sosmed_url' 		=> $sosmed_url,
			'sosmed_icon' 		=> $sosmed_icon
		);
		$this->db->where('sosmed_id', $sosmed_id);
		$this->db->update('tb_sosmed', $object);
	}

	function save_sosmed($sosmed_name, $sosmed_url, $sosmed_icon, $own_user_id)
	{
		$object = array(
			'sosmed_name' 		=> $sosmed_name,
			'sosmed_url' 		=> $sosmed_url,
			'sosmed_icon' 		=> $sosmed_icon,
			'own_user_id' 		=> $own_user_id
		);
		$this->db->insert('tb_sosmed', $object);
	}

	function update_user_info($id, $contents)
	{
		$object = array(
			'user_info' => $contents,
		);
		$this->db->where('id', $id);
		$this->db->update('tb_user', $object);
	}

	function update_password($id, $new_pass)
	{
		$object = array(
			'password' => $new_pass,
		);
		$this->db->where('id', $id);
		$this->db->update('tb_user', $object);
	}

	function update_personal($id, $full_name, $username, $email)
	{
		$object = array(
			'full_name' => $full_name,
			'username' => $username,
			'email' => $email,
		);
		$this->db->where('id', $id);
		$this->db->update('tb_user', $object);
	}

	function _upload_foto($id, $foto)
	{
		$object = array(
			'foto' => $foto
		);
		$this->db->where('id', $id);
		$this->db->update('tb_user', $object);
	}

	function _delete_foto($id)
	{
		$object = array(
			'foto' => ''
		);
		$this->db->where('id', $id);
		$this->db->update('tb_user', $object);
	}

	function _delete($id)
	{
		$this->db->where('id', $id);
		$this->db->delete('tb_user');
	}

	function lock($id)
	{
		$object = array(
			'status' => '0'
		);
		$this->db->where('id', $id);
		$this->db->update('tb_user', $object);
	}

	function unlock($id)
	{
		$object = array(
			'status' => '1'
		);
		$this->db->where('id', $id);
		$this->db->update('tb_user', $object);
	}
	
	function get_users_by_id($id)
	{
		$query = $this->db->query("SELECT * FROM tb_user WHERE id = '$id'");
		return $query;
	}
	
	function get_users()
	{
		$query = $this->db->query("SELECT * FROM tb_user");
		return $query;
	}

	public function cek_email($id, $email)
	{
		$query = $this->db->query("SELECT * FROM tb_user WHERE email = '$email' AND id != '$id'");
		return $query;
	}

	public function cek_username($id, $username)
	{
		$query = $this->db->query("SELECT * FROM tb_user WHERE username = '$username' AND id != '$id'");
		return $query;
	}
}