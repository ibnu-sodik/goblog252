<?php 
/**
 * Category_model
 */
class Category_model extends CI_Model
{
	
	function get_post_by_category($slug)
	{
		$this->db->select('tb_post.*, tb_category.*, tb_user.*');
		$this->db->from('tb_post');
		$this->db->join('tb_category', 'post_category_id = category_id', 'left');
		$this->db->join('tb_user', 'post_user_id = id', 'left');
		$this->db->where(array('category_slug' => $slug, 'post_published' => 1));
		$query = $this->db->get();
		return $query;
	}

	function get_category_post_perpage($limit, $offset, $category_id)
	{
		$this->db->select('tb_post.*, tb_category.*, tb_user.*');
		$this->db->from('tb_post');
		$this->db->join('tb_category', 'post_category_id = category_id', 'left');
		$this->db->join('tb_user', 'post_user_id = id', 'left');
		$this->db->where(array('category_id' => $category_id, 'post_published' => 1));
		$this->db->limit($limit, $offset);
		$query = $this->db->get();
		return $query;
	}
}