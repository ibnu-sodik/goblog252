<?php
/**
 * Result_model
 */
class Result_model extends CI_Model
{
	
	function hitung_jumlah_cari($query)
	{
		$query = $this->db->query("SELECT tb_post.*, tb_user.*, tb_category.* FROM tb_post
			LEFT JOIN tb_user ON tb_post.post_user_id = tb_user.id
			LEFT JOIN tb_category ON tb_post.post_category_id = tb_category.category_id
			WHERE post_title LIKE '%$query%' AND post_published = 1 OR category_name LIKE '%$query%' AND post_published = 1 OR post_tags LIKE '%$query%' AND post_published = 1");
		return $query;
	}

	function get_pencarian_perpage($limit, $offset, $query)
	{
		$query = $this->db->query("SELECT tb_post.*, tb_user.*, tb_category.* FROM tb_post
			LEFT JOIN tb_user ON tb_post.post_user_id = tb_user.id
			LEFT JOIN tb_category ON tb_post.post_category_id = tb_category.category_id
			WHERE post_title LIKE '%$query%' AND post_published = 1 OR category_name LIKE '%$query%' AND post_published = 1 OR post_tags LIKE '%$query%' AND post_published = 1 LIMIT $limit OFFSET $offset ");
		return $query;
	}


}