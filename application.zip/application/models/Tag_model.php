<?php 
/**
 * Tag_model
 */
class Tag_model extends CI_Model
{
	
	function get_post_by_tag($tag)
	{
		$this->db->select('tb_post.*, tb_category.*, tb_user.*');
		$this->db->from('tb_post');
		$this->db->join('tb_category', 'post_category_id = category_id', 'left');
		$this->db->join('tb_user', 'post_user_id = id', 'left');
		$this->db->where('post_published', 1);
		$this->db->like('post_tags', $tag, 'BOTH');
		$query = $this->db->get();
		return $query;
	}

	function get_tag_post_perpage($limit, $offset, $tag)
	{
		$this->db->select('tb_post.*, tb_category.*, tb_user.*');
		$this->db->from('tb_post');
		$this->db->join('tb_category', 'post_category_id = category_id', 'left');
		$this->db->join('tb_user', 'post_user_id = id', 'left');
		$this->db->where('post_published', 1);
		$this->db->like('post_tags', $tag, 'BOTH');
		$this->db->limit($limit, $offset);
		$query = $this->db->get();
		return $query;
	}
}