<?php 
/**
 * Site model
 */
class Site_model extends CI_Model
{
	
	function get_site_data()
	{
		$query = $this->db->get('tb_site', 1);
		return $query;
	}

	function delete_sosmed($sosmed_id)
	{
		$this->db->where('sosmed_id', $sosmed_id);
		$this->db->delete('tb_sosmed');
	}

	function update_sosmed($sosmed_name, $sosmed_url, $sosmed_icon, $sosmed_id)
	{
		$object = array(
			'sosmed_name' 		=> $sosmed_name,
			'sosmed_url' 		=> $sosmed_url,
			'sosmed_icon' 		=> $sosmed_icon
		);
		$this->db->where('sosmed_id', $sosmed_id);
		$this->db->update('tb_sosmed', $object);
	}

	function save_sosmed($sosmed_name, $sosmed_url, $sosmed_icon, $own_sosmed_id)
	{
		$object = array(
			'sosmed_name' 		=> $sosmed_name,
			'sosmed_url' 		=> $sosmed_url,
			'sosmed_icon' 		=> $sosmed_icon,
			'own_sosmed_id' 	=> $own_sosmed_id
		);
		$this->db->insert('tb_sosmed', $object);
	}

	function get_site_by_id($site_id){
		$result = $this->db->query("SELECT * FROM tb_site WHERE site_id='$site_id'");
		return $result;
	}

	function update_contact_page($site_id, $konten_kontak)
	{
		$this->db->set('konten_kontak', $konten_kontak);
		$this->db->where('site_id', $site_id);
		$this->db->update('tb_site');
	}

	function update_info($site_id, $site_title, $site_name, $site_keywords, $site_description)
	{
		$this->db->set('site_name', $site_name);
		$this->db->set('site_title', $site_title);
		$this->db->set('site_keywords', $site_keywords);
		$this->db->set('site_description', $site_description);
		$this->db->where('site_id', $site_id);
		$this->db->update('tb_site');
	}

	function update_limit($site_id, $limit_post, $limit_popular_post, $limit_recent_views, $limit_latest_post)
	{
		$this->db->set('limit_popular_post', $limit_popular_post);
		$this->db->set('limit_post', $limit_post);
		$this->db->set('limit_recent_views', $limit_recent_views);
		$this->db->set('limit_latest_post', $limit_latest_post);
		$this->db->where('site_id', $site_id);
		$this->db->update('tb_site');
	}

	function update_img($site_id, $site_favicon, $site_logo_header, $site_logo_footer)
	{
		$this->db->set('site_favicon', $site_favicon);
		$this->db->set('site_logo_header', $site_logo_header);
		$this->db->set('site_logo_footer', $site_logo_footer);
		$this->db->where('site_id', $site_id);
		$this->db->update('tb_site');
	}

	function update_img_tanpa_ikon($site_id, $site_logo_header, $site_logo_footer)
	{
		$this->db->set('site_logo_header', $site_logo_header);
		$this->db->set('site_logo_footer', $site_logo_footer);
		$this->db->where('site_id', $site_id);
		$this->db->update('tb_site');
	}

	function update_info_tanpa_header($site_id, $site_favicon, $site_logo_footer)
	{
		$this->db->set('site_favicon', $site_favicon);
		$this->db->set('site_logo_footer', $site_logo_footer);
		$this->db->where('site_id', $site_id);
		$this->db->update('tb_site');
	}

	function update_info_tanpa_footer($site_id, $site_favicon, $site_logo_header)
	{
		$this->db->set('site_favicon', $site_favicon);
		$this->db->set('site_logo_header', $site_logo_header);
		$this->db->where('site_id', $site_id);
		$this->db->update('tb_site');
	}

	function update_info_hanya_icon($site_id, $site_favicon)
	{
		$this->db->set('site_favicon', $site_favicon);
		$this->db->where('site_id', $site_id);
		$this->db->update('tb_site');
	}

	function update_info_hanya_header($site_id, $site_logo_header)
	{
		$this->db->set('site_logo_header', $site_logo_header);
		$this->db->where('site_id', $site_id);
		$this->db->update('tb_site');
	}

	function update_info_hanya_footer($site_id, $site_logo_footer)
	{
		$this->db->set('site_logo_footer', $site_logo_footer);
		$this->db->where('site_id', $site_id);
		$this->db->update('tb_site');
	}

	function get_sosmed_by_own($site_id)
	{
		$this->db->select('*');
		$this->db->from('tb_sosmed');
		$this->db->where('own_sosmed_id', $site_id);
		$query = $this->db->get();
		return $query;
	}

	function get_sosmed_by_author($user_id)
	{
		$this->db->select('*');
		$this->db->from('tb_sosmed');
		$this->db->where('own_user_id', $user_id);
		$query = $this->db->get();
		return $query;
	}

}