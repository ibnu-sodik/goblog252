<?php
defined('BASEPATH') OR exit('No direct script access allowed');

/**
 * Home model
 */
class Home_model extends CI_Model
{
	function get_post_header()
	{
		$this->db->select('tb_post.*, full_name, foto, tb_category.*');
		$this->db->from('tb_post');
		$this->db->join('tb_user', 'post_user_id = id', 'left');
		$this->db->join('tb_category', 'post_category_id = category_id', 'left');
		$this->db->where('post_published', 1);
		$this->db->order_by('post_id', 'desc');
		$this->db->limit(1);
		$query = $this->db->get();
		return $query;
	}

	function get_post_header2()
	{
		$this->db->select('tb_post.*, full_name, foto, tb_category.*');
		$this->db->from('tb_post');
		$this->db->join('tb_user', 'post_user_id = id', 'left');
		$this->db->join('tb_category', 'post_category_id = category_id', 'left');
		$this->db->where('post_published', 1);
		$this->db->order_by('post_views', 'desc');
		$this->db->limit(1);
		$query = $this->db->get();
		return $query;
	}

	function get_post_header3()
	{
		$this->db->select('tb_post.*, full_name, foto, tb_category.*');
		$this->db->from('tb_post');
		$this->db->join('tb_user', 'post_user_id = id', 'left');
		$this->db->join('tb_category', 'post_category_id = category_id', 'left');
		$this->db->where('post_published', 1);
		$this->db->order_by('post_recent_views', 'desc');
		$this->db->limit(1);
		$query = $this->db->get();
		return $query;
	}

	function get_latest_posts($limit_latest_posts)
	{
		$this->db->select('tb_post.*, full_name, foto, tb_category.*');
		$this->db->from('tb_post');
		$this->db->join('tb_user', 'post_user_id = id', 'left');
		$this->db->join('tb_category', 'post_category_id = category_id', 'left');
		$this->db->where('post_published', 1);
		$this->db->order_by('post_id', 'desc');
		$this->db->limit($limit_latest_posts);
		$query = $this->db->get();
		return $query;
	}

	function get_popular_posts($limit_popular_post)
	{		
		$this->db->select('tb_post.*');
		$this->db->from('tb_post');
		$this->db->order_by('post_views', 'desc');
		$this->db->where('post_published', 1);
		$this->db->limit($limit_popular_post);
		$query = $this->db->get();
		return $query;
	}

	function get_recent_views($limit_recent_views)
	{
		$this->db->select('tb_post.*');
		$this->db->from('tb_post');
		$this->db->order_by('post_recent_views', 'desc');
		$this->db->where('post_published', 1);
		$this->db->limit($limit_recent_views);
		$query = $this->db->get();
		return $query;
	}

	function get_popular_categories()
	{
		$query = $this->db->query("
			SELECT post_category_id, tb_post.*, tb_category.*, COUNT(*) AS jumlah FROM tb_post 
			LEFT JOIN tb_category ON post_category_id = category_id
			WHERE post_category_id = category_id AND post_published = '1' GROUP BY post_category_id ORDER BY COUNT(*) DESC LIMIT 5
			");
		return $query;
	}

}